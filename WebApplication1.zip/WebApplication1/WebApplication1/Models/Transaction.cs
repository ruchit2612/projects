using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    // Represents a money transfer between two users.
    public class Transaction
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int SenderId { get; set; }

        [Required]
        public int ReceiverId { get; set; }

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Amount { get; set; }

        [Required]
        public DateTime TransactionDate { get; set; }

        // "Success", "Failed", "Pending"
        [Required]
        [MaxLength(20)]
        public string Status { get; set; } = "Pending";

        // "Transfer" or "TopUp"
        [Required]
        [MaxLength(20)]
        public string Type { get; set; } = "Transfer";
    }
}

