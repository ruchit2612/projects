using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    // Represents a separate wallet entity (can be extended later).
    public class Wallet
    {
        [Key]
        public int Id { get; set; }

        // Simple association to a user; can be turned into a real FK later.
        [Required]
        public int UserId { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Balance { get; set; }
    }
}

