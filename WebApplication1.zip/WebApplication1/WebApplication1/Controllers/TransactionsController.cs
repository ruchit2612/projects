using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using WebApplication1.DTOs;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    // Handles money transfers and transaction history.
    [ApiController]
    [Route("api/[controller]")]
    public class TransactionsController : ControllerBase
    {
        private readonly WalletDbContext _context;

        public TransactionsController(WalletDbContext context)
        {
            _context = context;
        }

        // POST: /api/transactions/transfer
        [HttpPost("transfer")]
        public async Task<IActionResult> Transfer([FromBody] TransferRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (request.Amount <= 0)
            {
                await SaveFailedTransferAsync(request, "Amount must be greater than 0.");
                return BadRequest("Amount must be greater than 0.");
            }

            if (request.SenderId == request.ReceiverId)
            {
                await SaveFailedTransferAsync(request, "Sender and receiver must be different users.");
                return BadRequest("Sender and receiver must be different users.");
            }

            // For the in-memory database used in Development, we don't use explicit transactions.
            // EF Core will track the changes to both users and the transaction and save them together.

            var sender = await _context.Users.FirstOrDefaultAsync(u => u.Id == request.SenderId);
            if (sender == null)
            {
                await SaveFailedTransferAsync(request, $"Sender with id {request.SenderId} not found.");
                return NotFound($"Sender with id {request.SenderId} not found.");
            }

            var receiver = await _context.Users.FirstOrDefaultAsync(u => u.Id == request.ReceiverId);
            if (receiver == null)
            {
                await SaveFailedTransferAsync(request, $"Receiver with id {request.ReceiverId} not found.");
                return NotFound($"Receiver with id {request.ReceiverId} not found.");
            }

            if (sender.Balance < request.Amount)
            {
                await SaveFailedTransferAsync(request, "Sender does not have enough balance.");
                return BadRequest("Sender does not have enough balance.");
            }

            sender.Balance -= request.Amount;
            receiver.Balance += request.Amount;

            var transaction = new Transaction
            {
                SenderId = request.SenderId,
                ReceiverId = request.ReceiverId,
                Amount = request.Amount,
                TransactionDate = DateTime.UtcNow,
                Status = "Success",
                Type = "Transfer"
            };

            _context.Transactions.Add(transaction);

            await _context.SaveChangesAsync();

            return Ok(transaction);
        }

        private async Task SaveFailedTransferAsync(TransferRequest request, string _)
        {
            // We still record failed attempts for audit/history.
            var failed = new Transaction
            {
                SenderId = request.SenderId,
                ReceiverId = request.ReceiverId,
                Amount = request.Amount,
                TransactionDate = DateTime.UtcNow,
                Status = "Failed",
                Type = "Transfer"
            };

            _context.Transactions.Add(failed);
            await _context.SaveChangesAsync();
        }

        // GET: /api/transactions
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Transaction>>> GetAllTransactions()
        {
            var transactions = await _context.Transactions
                .AsNoTracking()
                .OrderByDescending(t => t.TransactionDate)
                .ToListAsync();

            return Ok(transactions);
        }

        // GET: /api/transactions/user/{id}
        [HttpGet("user/{id:int}")]
        public async Task<ActionResult<IEnumerable<Transaction>>> GetUserTransactions(int id)
        {
            var userExists = await _context.Users.AnyAsync(u => u.Id == id);
            if (!userExists)
            {
                return NotFound($"User with id {id} not found.");
            }

            var transactions = await _context.Transactions
                .AsNoTracking()
                .Where(t => t.SenderId == id || t.ReceiverId == id)
                .OrderByDescending(t => t.TransactionDate)
                .ToListAsync();

            return Ok(transactions);
        }
    }
}

