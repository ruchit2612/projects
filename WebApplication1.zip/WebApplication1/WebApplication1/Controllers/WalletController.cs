using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using WebApplication1.DTOs;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class WalletController : ControllerBase
    {
        private readonly WalletDbContext _context;

        public WalletController(WalletDbContext context)
        {
            _context = context;
        }

        // POST: /api/wallet/topup
        [HttpPost("topup")]
        public async Task<IActionResult> TopUp([FromBody] TopUpRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (request.Amount <= 0)
            {
                return BadRequest("Amount must be greater than 0.");
            }

            var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == request.UserId);
            if (user == null)
            {
                return NotFound($"User with id {request.UserId} not found.");
            }

            user.Balance += request.Amount;

            // For top-up, we treat it as "System -> User".
            var transaction = new Transaction
            {
                SenderId = 0,
                ReceiverId = request.UserId,
                Amount = request.Amount,
                TransactionDate = DateTime.UtcNow,
                Status = "Success",
                Type = "TopUp"
            };

            _context.Transactions.Add(transaction);
            await _context.SaveChangesAsync();

            return Ok(transaction);
        }

        // GET: /api/wallet/balance/{userId}
        [HttpGet("balance/{userId:int}")]
        public async Task<IActionResult> GetBalance(int userId)
        {
            var user = await _context.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == userId);
            if (user == null)
            {
                return NotFound($"User with id {userId} not found.");
            }

            return Ok(new { userId = user.Id, balance = user.Balance });
        }
    }
}

