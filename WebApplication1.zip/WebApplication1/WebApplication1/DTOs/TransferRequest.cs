using System.ComponentModel.DataAnnotations;

namespace WebApplication1.DTOs
{
    // DTO used for transfer requests between users.
    public class TransferRequest
    {
        [Required]
        public int SenderId { get; set; }

        [Required]
        public int ReceiverId { get; set; }

        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Amount must be greater than zero.")]
        public decimal Amount { get; set; }
    }
}

