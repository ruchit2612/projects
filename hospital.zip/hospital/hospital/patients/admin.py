from django.contrib import admin
from .models import Patient, Appointment

@admin.register(Patient)
class PatientAdmin(admin.ModelAdmin):
    list_display = ['user', 'phone', 'gender', 'blood_group', 'created_at']
    list_filter = ['gender', 'created_at']
    search_fields = ['user__username', 'user__email', 'user__first_name', 'user__last_name']
    ordering = ['user__first_name']

@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ['patient', 'doctor', 'appointment_date', 'appointment_time', 'status']
    list_filter = ['status', 'appointment_date', 'doctor__department']
    search_fields = ['patient__user__first_name', 'patient__user__last_name', 'doctor__name']
    ordering = ['-appointment_date', '-appointment_time']
    date_hierarchy = 'appointment_date'

# SymptomPrediction admin removed along with model
