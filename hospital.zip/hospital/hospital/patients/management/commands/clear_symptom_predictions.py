from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = 'SymptomPrediction model has been removed. This command is deprecated.'

    def handle(self, *args, **options):
        self.stdout.write(self.style.WARNING('SymptomPrediction model removed. Nothing to clear.'))


