from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Patient, Appointment
from doctors.serializers import DoctorSerializer
from doctors.models import Doctor

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name']

class PatientSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    gender_display = serializers.CharField(source='get_gender_display', read_only=True)
    
    class Meta:
        model = Patient
        fields = [
            'id', 'user', 'phone', 'address', 'date_of_birth', 'gender', 
            'gender_display', 'blood_group', 'emergency_contact', 
            'created_at', 'updated_at'
        ]
        read_only_fields = ['created_at', 'updated_at']

class AppointmentSerializer(serializers.ModelSerializer):
    patient = PatientSerializer(read_only=True)
    doctor = DoctorSerializer(read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    
    class Meta:
        model = Appointment
        fields = [
            'id', 'patient', 'doctor', 'appointment_date', 'appointment_time',
            'symptoms', 'status', 'status_display', 'notes', 'created_at', 'updated_at'
        ]
        read_only_fields = ['created_at', 'updated_at']

class AdminAppointmentSerializer(serializers.ModelSerializer):
    """Simplified serializer for admin view to avoid nested serializer issues"""
    patient_name = serializers.SerializerMethodField()
    doctor_name = serializers.SerializerMethodField()
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    
    class Meta:
        model = Appointment
        fields = [
            'id', 'patient_name', 'doctor_name', 'doctor', 'appointment_date', 'appointment_time',
            'symptoms', 'status', 'status_display', 'notes', 'created_at', 'updated_at'
        ]
        read_only_fields = ['created_at', 'updated_at']
    
    def get_patient_name(self, obj):
        try:
            return obj.patient.user.username if obj.patient and obj.patient.user else 'N/A'
        except:
            return 'N/A'
    
    def get_doctor_name(self, obj):
        try:
            return obj.doctor.name if obj.doctor else 'N/A'
        except:
            return 'N/A'

class AppointmentCreateSerializer(serializers.ModelSerializer):
    doctor = serializers.PrimaryKeyRelatedField(queryset=Doctor.objects.all())
    appointment_time = serializers.TimeField(input_formats=['%H:%M', '%H:%M:%S'])
    appointment_date = serializers.DateField(input_formats=['%Y-%m-%d'])
    
    class Meta:
        model = Appointment
        fields = ['doctor', 'appointment_date', 'appointment_time', 'symptoms']
    
    def validate(self, data):
        doctor = data['doctor']
        appointment_date = data['appointment_date']
        appointment_time = data['appointment_time']
        

        
        # Check if doctor already has an appointment at the same date and time
        existing_appointment = Appointment.objects.filter(
            doctor=doctor,
            appointment_date=appointment_date,
            appointment_time=appointment_time,
            status__in=['pending', 'confirmed']
        ).exists()
        
        if existing_appointment:
            raise serializers.ValidationError({
                'appointment_time': f"Dr. {doctor.name} is already booked at {appointment_time} on {appointment_date}. Please choose a different time or date."
            })
        
        # Check if the current user already has an appointment at the same date and time
        if self.context.get('request') and self.context['request'].user.is_authenticated:
            try:
                patient = Patient.objects.get(user=self.context['request'].user)
                existing_patient_appointment = Appointment.objects.filter(
                    patient=patient,
                    appointment_date=appointment_date,
                    appointment_time=appointment_time,
                    status__in=['pending', 'confirmed']
                ).exists()
                
                if existing_patient_appointment:
                    raise serializers.ValidationError({
                        'appointment_time': f"You already have an appointment at {appointment_time} on {appointment_date}. Please choose a different time or date."
                    })
            except Patient.DoesNotExist:
                pass
        
        # Check if the appointment is in the past
        from django.utils import timezone
        from datetime import datetime
        
        # Combine date and time for comparison
        appointment_datetime = datetime.combine(appointment_date, appointment_time)
        # Make it timezone-aware for comparison
        appointment_datetime = timezone.make_aware(appointment_datetime)
        current_datetime = timezone.now()
        
        if appointment_datetime < current_datetime:
            raise serializers.ValidationError({
                'appointment_date': "Cannot book appointments in the past. Please select a future date and time."
            })
        
        # Additional validation: Check if doctor is available
        if not doctor.available:
            raise serializers.ValidationError({
                'doctor': f"Dr. {doctor.name} is currently not available for appointments."
            })
        
        return data

# SymptomPrediction serializers removed along with model

class ForgotPasswordSerializer(serializers.Serializer):
    email = serializers.EmailField()

class OTPVerifySerializer(serializers.Serializer):
    email = serializers.EmailField()
    otp = serializers.CharField(max_length=6)

class ChangePasswordSerializer(serializers.Serializer):
    email = serializers.EmailField()
    otp = serializers.CharField(max_length=6)
    new_password = serializers.CharField(min_length=8, write_only=True) 