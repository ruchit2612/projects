from django.db import models
from django.contrib.auth.models import User
from doctors.models import Doctor
from django.utils import timezone
from datetime import timedelta

class Patient(models.Model):
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone = models.CharField(max_length=15)
    address = models.TextField()
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    blood_group = models.CharField(max_length=5, blank=True)
    emergency_contact = models.CharField(max_length=15, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.user.get_full_name()} - {self.user.email}"

class Appointment(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ]
    
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    appointment_date = models.DateField()
    appointment_time = models.TimeField()
    symptoms = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.patient.user.get_full_name()} - Dr. {self.doctor.name} - {self.appointment_date}"
    
    def save(self, *args, **kwargs):
        """Override save to check for duplicate appointments"""
        # Check for existing appointments at the same time slot
        if self.pk is None:  # Only check on creation, not update
            existing = Appointment.objects.filter(
                doctor=self.doctor,
                appointment_date=self.appointment_date,
                appointment_time=self.appointment_time,
                status__in=['pending', 'confirmed']
            ).exists()
            
            if existing:
                raise ValueError(
                    f"Dr. {self.doctor.name} is already booked at {self.appointment_time} on {self.appointment_date}"
                )
        
        super().save(*args, **kwargs)
    
    class Meta:
        ordering = ['-appointment_date', '-appointment_time']
        # Prevent duplicate appointments for the same doctor at the same date and time
        unique_together = ['doctor', 'appointment_date', 'appointment_time']

"""
The SymptomPrediction model has been removed.
Apply migrations to drop the corresponding table.
"""

class PasswordResetOTP(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    otp = models.CharField(max_length=6)
    created_at = models.DateTimeField(auto_now_add=True)
    is_used = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.user.email} - {self.otp} - {self.created_at}"
