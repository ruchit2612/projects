from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    PatientViewSet, AppointmentViewSet,
    RegisterView, LoginView, LogoutView,
    ForgotPasswordView, OTPVerifyView, ChangePasswordView,
    AvailableSymptomsView, IllnessClassesView, DoctorClassesView, PredictView
)

router = DefaultRouter()
router.register(r'patients', PatientViewSet, basename='patient')
router.register(r'appointments', AppointmentViewSet, basename='appointment')
# SymptomPrediction routes removed

urlpatterns = [
    path('', include(router.urls)),
    path('auth/register/', RegisterView.as_view(), name='register'),
    path('auth/login/', LoginView.as_view(), name='login'),
    path('auth/logout/', LogoutView.as_view(), name='logout'),
    path('auth/forgot-password/', ForgotPasswordView.as_view(), name='forgot-password'),
    path('auth/verify-otp/', OTPVerifyView.as_view(), name='verify-otp'),
    path('auth/change-password/', ChangePasswordView.as_view(), name='change-password'),
    # Lightweight prediction endpoints (no DB persistence)
    path('predictions/available_symptoms/', AvailableSymptomsView.as_view(), name='available-symptoms'),
    path('predictions/illness_classes/', IllnessClassesView.as_view(), name='illness-classes'),
    path('predictions/doctor_classes/', DoctorClassesView.as_view(), name='doctor-classes'),
    path('predictions/predict/', PredictView.as_view(), name='predict'),
] 