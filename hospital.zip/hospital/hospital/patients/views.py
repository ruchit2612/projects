from django.shortcuts import render
from rest_framework import viewsets, permissions, status, serializers
from rest_framework.decorators import action
from rest_framework.response import Response
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from .models import Patient, Appointment
from .serializers import (
    PatientSerializer, AppointmentSerializer, AppointmentCreateSerializer,
    AdminAppointmentSerializer
)
from ml_model.services import SymptomPredictionService
from .serializers import ForgotPasswordSerializer, OTPVerifySerializer, ChangePasswordSerializer
from .models import PasswordResetOTP
import random
from rest_framework.views import APIView
from rest_framework.authtoken.models import Token
from django.utils import timezone
from datetime import timedelta
from django.core.mail import send_mail
from django.conf import settings

# Create your views here.

class PatientViewSet(viewsets.ModelViewSet):
    queryset = Patient.objects.all()
    serializer_class = PatientSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        """Return only the current user's patient profile"""
        if self.request.user.is_authenticated:
            return Patient.objects.filter(user=self.request.user)
        return Patient.objects.none()

class AppointmentViewSet(viewsets.ModelViewSet):
    queryset = Appointment.objects.all()
    serializer_class = AppointmentSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        """Return appointments for the current user or all for admin actions"""
        if self.action in ['admin_list', 'admin_cancel', 'admin_accept', 'admin_reschedule', 'available_slots']:
            return Appointment.objects.all()
        
        if self.request.user.is_authenticated:
            try:
                patient = Patient.objects.get(user=self.request.user)
                return Appointment.objects.filter(patient=patient)
            except Patient.DoesNotExist:
                return Appointment.objects.none()
        return Appointment.objects.none()
    
    def get_serializer_class(self):
        if self.action == 'create':
            return AppointmentCreateSerializer
        return AppointmentSerializer
    
    def perform_create(self, serializer):
        """Create appointment for the current user"""
        if self.request.user.is_authenticated:
            try:
                patient = Patient.objects.get(user=self.request.user)
                serializer.save(patient=patient)
            except Patient.DoesNotExist:
                raise serializers.ValidationError("Patient profile not found")
    
    def create(self, request, *args, **kwargs):
        """Override create to ensure proper validation"""
        serializer = self.get_serializer(data=request.data)
        
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            self.perform_create(serializer)
            headers = self.get_success_headers(serializer.data)
            return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=False, methods=['get'])
    def check_availability(self, request):
        """Check if a specific time slot is available for a doctor"""
        doctor_id = request.query_params.get('doctor_id')
        appointment_date = request.query_params.get('appointment_date')
        appointment_time = request.query_params.get('appointment_time')
        
        if not all([doctor_id, appointment_date, appointment_time]):
            return Response({
                'error': 'doctor_id, appointment_date, and appointment_time are required'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            from datetime import datetime
            appointment_date = datetime.strptime(appointment_date, '%Y-%m-%d').date()
            appointment_time = datetime.strptime(appointment_time, '%H:%M').time()
        except ValueError:
            return Response({
                'error': 'Invalid date or time format. Use YYYY-MM-DD for date and HH:MM for time'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Check if appointment exists
        existing_appointment = Appointment.objects.filter(
            doctor_id=doctor_id,
            appointment_date=appointment_date,
            appointment_time=appointment_time,
            status__in=['pending', 'confirmed']
        ).exists()
        
        return Response({
            'available': not existing_appointment,
            'doctor_id': doctor_id,
            'appointment_date': appointment_date,
            'appointment_time': appointment_time
        })
    
    @action(detail=False, methods=['get'])
    def check_user_conflict(self, request):
        """Check if the current user has an appointment at a specific date and time"""
        appointment_date = request.query_params.get('appointment_date')
        appointment_time = request.query_params.get('appointment_time')
        
        if not all([appointment_date, appointment_time]):
            return Response({
                'error': 'appointment_date and appointment_time are required'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        if not request.user.is_authenticated:
            return Response({
                'error': 'User must be authenticated'
            }, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            from datetime import datetime
            appointment_date = datetime.strptime(appointment_date, '%Y-%m-%d').date()
            appointment_time = datetime.strptime(appointment_time, '%H:%M').time()
        except ValueError:
            return Response({
                'error': 'Invalid date or time format. Use YYYY-MM-DD for date and HH:MM for time'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            patient = Patient.objects.get(user=request.user)
            # Check if user has an appointment at this specific date and time
            existing_appointment = Appointment.objects.filter(
                patient=patient,
                appointment_date=appointment_date,
                appointment_time=appointment_time,
                status__in=['pending', 'confirmed']
            ).exists()
            
            return Response({
                'has_conflict': existing_appointment,
                'appointment_date': appointment_date,
                'appointment_time': appointment_time
            })
        except Patient.DoesNotExist:
            return Response({
                'error': 'Patient profile not found'
            }, status=status.HTTP_404_NOT_FOUND)

    @action(detail=False, methods=['get'])
    def available_slots(self, request):
        """Get available time slots for a doctor on a specific date"""
        doctor_id = request.query_params.get('doctor_id')
        appointment_date = request.query_params.get('appointment_date')
        
        if not all([doctor_id, appointment_date]):
            return Response({
                'error': 'doctor_id and appointment_date are required'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            from datetime import datetime
            appointment_date = datetime.strptime(appointment_date, '%Y-%m-%d').date()
        except ValueError:
            return Response({
                'error': 'Invalid date format. Use YYYY-MM-DD'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Get all booked time slots for this doctor on this date
        booked_slots = Appointment.objects.filter(
            doctor_id=doctor_id,
            appointment_date=appointment_date,
            status__in=['pending', 'confirmed']
        ).values_list('appointment_time', flat=True)
        
        # Define available time slots (9 AM to 5 PM, 1-hour intervals)
        from datetime import time
        all_slots = [
            time(9, 0), time(10, 0), time(11, 0), time(12, 0),
            time(13, 0), time(14, 0), time(15, 0), time(16, 0), time(17, 0)
        ]
        
        # Filter out booked slots
        available_slots = [slot for slot in all_slots if slot not in booked_slots]
        
        return Response({
            'doctor_id': doctor_id,
            'appointment_date': appointment_date,
            'available_slots': [slot.strftime('%H:%M') for slot in available_slots],
            'booked_slots': [slot.strftime('%H:%M') for slot in booked_slots]
        })
    
    @action(detail=False, methods=['get'])
    def admin_list(self, request):
        """Get all appointments for admin view"""
        try:
            appointments = Appointment.objects.all().select_related('patient__user', 'doctor')
            serializer = AdminAppointmentSerializer(appointments, many=True)
            return Response(serializer.data)
        except Exception as e:
            return Response({
                'error': f'Failed to load appointments: {str(e)}'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    @action(detail=True, methods=['patch', 'post'])
    def admin_cancel(self, request, pk=None):
        """Cancel appointment for admin"""
        try:
            # Get the cancellation reason from request data
            cancel_reason = request.data.get('cancel_reason', '').strip()
            if not cancel_reason:
                return Response({
                    'error': 'Cancellation reason is required'
                }, status=status.HTTP_400_BAD_REQUEST)
            
            appointment = self.get_object()
            appointment.status = 'cancelled'
            appointment.save()
            serializer = AdminAppointmentSerializer(appointment)
            
            # Notify patient via email with cancellation reason
            try:
                patient_email = appointment.patient.user.email if appointment.patient and appointment.patient.user else None
                if patient_email:
                    send_mail(
                        subject='Your appointment has been cancelled',
                        message=(
                            f"Hello {appointment.patient.user.get_full_name() or appointment.patient.user.username},\n\n"
                            f"Your appointment with Dr. {appointment.doctor.name} on {appointment.appointment_date} at "
                            f"{appointment.appointment_time} has been cancelled by the administrator.\n\n"
                            f"Reason for cancellation: {cancel_reason}\n\n"
                            f"We apologize for any inconvenience. Please book a new appointment or contact support if you have any questions."
                        ),
                        from_email=getattr(settings, 'DEFAULT_FROM_EMAIL', settings.EMAIL_HOST_USER),
                        recipient_list=[patient_email],
                        fail_silently=True,
                    )
            except Exception:
                # Do not fail the API if email sending fails
                pass
            return Response(serializer.data)
        except Exception as e:
            return Response({
                'error': f'Failed to cancel appointment: {str(e)}'
            }, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['patch', 'post'])
    def admin_reschedule(self, request, pk=None):
        """Reschedule appointment for admin"""
        try:
            # Get the reschedule data from request
            new_appointment_date = request.data.get('new_appointment_date')
            new_appointment_time = request.data.get('new_appointment_time')
            cancel_reason = request.data.get('cancel_reason', '')
            
            if not all([new_appointment_date, new_appointment_time]):
                return Response({
                    'error': 'New appointment date and time are required'
                }, status=status.HTTP_400_BAD_REQUEST)
            
            appointment = self.get_object()
            
            # Check if the new time slot is available
            from datetime import datetime
            try:
                new_date = datetime.strptime(new_appointment_date, '%Y-%m-%d').date()
                new_time = datetime.strptime(new_appointment_time, '%H:%M').time()
            except ValueError:
                return Response({
                    'error': 'Invalid date or time format'
                }, status=status.HTTP_400_BAD_REQUEST)
            
            # Check for conflicts
            conflicting_appointment = Appointment.objects.filter(
                doctor=appointment.doctor,
                appointment_date=new_date,
                appointment_time=new_time,
                status__in=['pending', 'confirmed']
            ).exclude(id=appointment.id).first()
            
            if conflicting_appointment:
                return Response({
                    'error': f'Dr. {appointment.doctor.name} is already booked at {new_time} on {new_date}'
                }, status=status.HTTP_400_BAD_REQUEST)
            
            # Update appointment with new date and time
            old_date = appointment.appointment_date
            old_time = appointment.appointment_time
            
            appointment.appointment_date = new_date
            appointment.appointment_time = new_time
            appointment.status = 'confirmed'  # Set to confirmed since admin is rescheduling
            appointment.save()
            
            serializer = AdminAppointmentSerializer(appointment)
            
            # Send email to patient with cancellation reason and new appointment details
            try:
                patient_email = appointment.patient.user.email if appointment.patient and appointment.patient.user else None
                if patient_email:
                    send_mail(
                        subject='Your appointment has been rescheduled',
                        message=(
                            f"Hello {appointment.patient.user.get_full_name() or appointment.patient.user.username},\n\n"
                            f"Your appointment with Dr. {appointment.doctor.name} has been rescheduled.\n\n"
                            f"Original appointment: {old_date} at {old_time}\n"
                            f"New appointment: {new_date} at {new_time}\n\n"
                            f"Reason for change: {cancel_reason}\n\n"
                            f"Your appointment is now confirmed for the new time. Please arrive 10 minutes early.\n\n"
                            f"If you have any questions, please contact support."
                        ),
                        from_email=getattr(settings, 'DEFAULT_FROM_EMAIL', settings.EMAIL_HOST_USER),
                        recipient_list=[patient_email],
                        fail_silently=True,
                    )
            except Exception:
                # Do not fail the API if email sending fails
                pass
            
            return Response(serializer.data)
        except Exception as e:
            return Response({
                'error': f'Failed to reschedule appointment: {str(e)}'
            }, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['patch', 'post'])
    def admin_accept(self, request, pk=None):
        """Accept/confirm appointment for admin"""
        try:
            appointment = self.get_object()
            if appointment.status in ['cancelled', 'completed']:
                return Response({'error': f"Cannot accept an appointment with status '{appointment.status}'."}, status=status.HTTP_400_BAD_REQUEST)
            appointment.status = 'confirmed'
            appointment.save()
            serializer = AdminAppointmentSerializer(appointment)
            # Notify patient via email
            try:
                patient_email = appointment.patient.user.email if appointment.patient and appointment.patient.user else None
                if patient_email:
                    send_mail(
                        subject='Your appointment has been confirmed',
                        message=(
                            f"Hello {appointment.patient.user.get_full_name() or appointment.patient.user.username},\n\n"
                            f"Good news! Your appointment with Dr. {appointment.doctor.name} on {appointment.appointment_date} at "
                            f"{appointment.appointment_time} has been confirmed.\n\n"
                            f"Please arrive 10 minutes early and bring any relevant documents."
                        ),
                        from_email=getattr(settings, 'DEFAULT_FROM_EMAIL', settings.EMAIL_HOST_USER),
                        recipient_list=[patient_email],
                        fail_silently=True,
                    )
            except Exception:
                # Do not fail the API if email sending fails
                pass
            return Response(serializer.data)
        except Exception as e:
            return Response({
                'error': f'Failed to accept appointment: {str(e)}'
            }, status=status.HTTP_400_BAD_REQUEST)
    
    def get_permissions(self):
        """Override permissions for admin actions"""
        if self.action in ['admin_list', 'admin_cancel', 'admin_accept', 'admin_reschedule', 'available_slots']:
            return [permissions.AllowAny()]
        return super().get_permissions()

# SymptomPrediction viewset and related endpoints removed

# Lightweight prediction API (no database persistence)
class AvailableSymptomsView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        service = SymptomPredictionService()
        return Response({'symptoms': service.get_available_symptoms()})


class IllnessClassesView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        service = SymptomPredictionService()
        return Response({'illnesses': service.get_illness_classes()})


class DoctorClassesView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        service = SymptomPredictionService()
        return Response({'doctors': service.get_doctor_classes()})


class PredictView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        symptoms = request.data.get('symptoms', '')
        try:
            age = int(request.data.get('age')) if request.data.get('age') is not None else None
        except (TypeError, ValueError):
            age = None
        gender = request.data.get('gender', '')

        if not symptoms or age is None or not gender:
            return Response({'error': 'Symptoms, age, and gender are required'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            service = SymptomPredictionService()
            prediction_result = service.predict_illness_and_doctor(symptoms, age, gender)

            recommended_doctors = service.recommend_all_doctors(prediction_result['doctor_type'])
            response_data = {
                'prediction': prediction_result,
                'recommended_doctors': []
            }

            if recommended_doctors.exists():
                response_data['recommended_doctors'] = [
                    {
                        'id': doctor.id,
                        'name': doctor.name,
                        'department': doctor.get_department_display(),
                        'experience': doctor.experience,
                        'specialization': doctor.specialization,
                        'consultation_fee': str(doctor.consultation_fee)
                    }
                    for doctor in recommended_doctors
                ]

            return Response(response_data)
        except Exception as e:
            return Response({'error': f'Prediction failed: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# Authentication views

class RegisterView(APIView):
    permission_classes = [permissions.AllowAny]
    
    def post(self, request):
        data = request.data
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')
        first_name = data.get('first_name', '')
        last_name = data.get('last_name', '')
        
        if User.objects.filter(username=username).exists():
            return Response({'error': 'Username already exists'}, status=status.HTTP_400_BAD_REQUEST)
        
        if User.objects.filter(email=email).exists():
            return Response({'error': 'Email already exists'}, status=status.HTTP_400_BAD_REQUEST)
        
        user = User.objects.create_user(
            username=username,
            email=email,
            password=password,
            first_name=first_name,
            last_name=last_name
        )
        
        # Create patient profile
        Patient.objects.create(
            user=user,
            phone=data.get('phone', ''),
            address=data.get('address', ''),
            date_of_birth=data.get('date_of_birth'),
            gender=data.get('gender', 'O'),
            blood_group=data.get('blood_group', ''),
            emergency_contact=data.get('emergency_contact', '')
        )
        
        token, created = Token.objects.get_or_create(user=user)
        return Response({
            'token': token.key,
            'user_id': user.id,
            'username': user.username
        }, status=status.HTTP_201_CREATED)

class LoginView(APIView):
    permission_classes = [permissions.AllowAny]
    
    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        
        user = authenticate(username=username, password=password)
        if user:
            login(request, user)
            token, created = Token.objects.get_or_create(user=user)
            return Response({
                'token': token.key,
                'user_id': user.id,
                'username': user.username
            })
        else:
            return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)

class LogoutView(APIView):
    permission_classes = [permissions.IsAuthenticated]
    
    def post(self, request):
        logout(request)
        return Response({'message': 'Logged out successfully'})

class ForgotPasswordView(APIView):
    permission_classes = [permissions.AllowAny]
    def post(self, request):
        serializer = ForgotPasswordSerializer(data=request.data)
        if serializer.is_valid():
            email = serializer.validated_data['email']
            try:
                user = User.objects.get(email=email)
            except User.DoesNotExist:
                return Response({'error': 'User with this email does not exist.'}, status=status.HTTP_404_NOT_FOUND)
            # Generate OTP
            otp = str(random.randint(100000, 999999))
            PasswordResetOTP.objects.create(user=user, otp=otp)
            # Send OTP via Django email
            try:
                send_mail(
                    'Password Reset OTP',
                    f'Your OTP for password reset is: {otp}',
                    'noreply@hospital.com',
                    [email],
                    fail_silently=False,
                )
                return Response({'message': 'OTP sent to your email.'})
            except Exception as e:
                return Response({'error': f'Failed to send OTP: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class OTPVerifyView(APIView):
    permission_classes = [permissions.AllowAny]
    def post(self, request):
        serializer = OTPVerifySerializer(data=request.data)
        if serializer.is_valid():
            email = serializer.validated_data['email']
            otp = serializer.validated_data['otp']
            try:
                user = User.objects.get(email=email)
                otp_obj = PasswordResetOTP.objects.filter(user=user, otp=otp, is_used=False).latest('created_at')
            except (User.DoesNotExist, PasswordResetOTP.DoesNotExist):
                return Response({'error': 'Invalid OTP or email.'}, status=status.HTTP_400_BAD_REQUEST)
            # Check OTP expiry (10 min)
            if timezone.now() - otp_obj.created_at > timedelta(minutes=10):
                return Response({'error': 'OTP expired.'}, status=status.HTTP_400_BAD_REQUEST)
            return Response({'message': 'OTP verified.'})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class ChangePasswordView(APIView):
    permission_classes = [permissions.AllowAny]
    def post(self, request):
        serializer = ChangePasswordSerializer(data=request.data)
        if serializer.is_valid():
            email = serializer.validated_data['email']
            otp = serializer.validated_data['otp']
            new_password = serializer.validated_data['new_password']
            try:
                user = User.objects.get(email=email)
                otp_obj = PasswordResetOTP.objects.filter(user=user, otp=otp, is_used=False).latest('created_at')
            except (User.DoesNotExist, PasswordResetOTP.DoesNotExist):
                return Response({'error': 'Invalid OTP or email.'}, status=status.HTTP_400_BAD_REQUEST)
            # Check OTP expiry (10 min)
            if timezone.now() - otp_obj.created_at > timedelta(minutes=10):
                return Response({'error': 'OTP expired.'}, status=status.HTTP_400_BAD_REQUEST)
            # Set new password
            user.set_password(new_password)
            user.save()
            otp_obj.is_used = True
            otp_obj.save()
            return Response({'message': 'Password changed successfully.'})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
