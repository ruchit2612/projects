# Hospital Management System

A comprehensive hospital management system built with React frontend and Django backend, featuring AI-powered symptom prediction and doctor recommendation.

## Features

### 🧑‍💻 User Side
- **User Registration/Login**: Secure authentication system
- **Doctor Browsing**: View doctors by department, experience, and specialization
- **Appointment Booking**: Easy appointment scheduling with available doctors
- **AI Symptom Checker**: Enter symptoms, age, gender → get illness prediction → recommended doctor
- **Appointment Management**: View, cancel, and track appointment status
- **Profile Management**: Update personal information and medical details

### 🩺 Admin Side
- **Doctor Management**: Add, update, delete doctor profiles
- **Appointment Overview**: View all appointments and their status
- **Prediction Analytics**: Track symptom prediction history and accuracy
- **Patient Management**: Access patient information and medical history

### 🏥 Departments
- General Physician
- Dentist
- Orthopedic
- Children Specialist
- Emergency Doctor

## Technology Stack

### Backend
- **Django 5.1.7**: Web framework
- **Django REST Framework**: API development
- **SQLite**: Database (can be changed to PostgreSQL/MySQL for production)
- **Scikit-learn**: Machine Learning for symptom prediction
- **Pillow**: Image handling for doctor profiles

### Frontend
- **React 18**: UI framework
- **Material-UI (MUI)**: Component library
- **React Router**: Navigation
- **Axios**: HTTP client
- **Day.js**: Date handling

## Installation & Setup

### Prerequisites
- Python 3.8+
- Node.js 16+
- npm or yarn

### Backend Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd hospital
   ```

2. **Create virtual environment**
   ```bash
   python -m venv venv
   # On Windows
   venv\Scripts\activate
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install Python dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run Django migrations**
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

5. **Create superuser (admin)**
   ```bash
   python manage.py createsuperuser
   ```

6. **Run Django development server**
   ```bash
   python manage.py runserver
   ```

The Django backend will be available at `http://localhost:8000`

### Frontend Setup

1. **Navigate to frontend directory**
   ```bash
   cd frontend
   ```

2. **Install Node.js dependencies**
   ```bash
   npm install
   ```

3. **Start React development server**
   ```bash
   npm start
   ```

The React frontend will be available at `http://localhost:3000`

## API Endpoints

### Authentication
- `POST /api/auth/register/` - User registration
- `POST /api/auth/login/` - User login
- `POST /api/auth/logout/` - User logout

### Doctors
- `GET /api/doctors/` - List all doctors
- `GET /api/doctors/{id}/` - Get doctor details
- `GET /api/doctors/by_department/` - Filter by department
- `GET /api/doctors/available/` - Get available doctors

### Appointments
- `GET /api/appointments/` - User's appointments
- `POST /api/appointments/` - Book new appointment
- `PATCH /api/appointments/{id}/` - Update appointment status

### Symptom Prediction
- `POST /api/predictions/` - Get illness prediction and doctor recommendation
- `GET /api/predictions/` - User's prediction history

### Patient Profile
- `GET /api/patients/` - Get user profile
- `PATCH /api/patients/{id}/` - Update profile

## ML Model Integration

The system includes a pre-trained machine learning model for symptom prediction:

- **Model Files**: Located in `ml_model/` directory
- **Prediction Service**: `ml_model/services.py`
- **Illness Mapping**: Maps predicted illnesses to appropriate doctor specialties
- **Fallback System**: Rule-based prediction when ML model is unavailable

### Illness to Doctor Mapping
```python
illness_to_specialty = {
    'flu': 'general_physician',
    'toothache': 'dentist',
    'fracture': 'orthopedic',
    'heart_attack': 'emergency',
    'childhood_fever': 'children_specialist',
    # ... more mappings
}
```

## Usage Guide

### For Patients

1. **Register/Login**: Create an account or sign in
2. **Browse Doctors**: View available doctors by department
3. **Symptom Checker**: Use AI to get preliminary diagnosis and doctor recommendation
4. **Book Appointment**: Schedule appointment with recommended or preferred doctor
5. **Manage Appointments**: View and cancel appointments as needed

### For Administrators

1. **Access Admin Panel**: Go to `http://localhost:8000/admin/`
2. **Manage Doctors**: Add, edit, or remove doctor profiles
3. **Monitor Appointments**: View all appointments and their status
4. **Analytics**: Track prediction accuracy and system usage

## Sample Data

After setting up the system, you can add sample doctors through the Django admin panel:

### Sample Doctor Data
```python
# General Physician
{
    'name': 'Dr. Sarah Johnson',
    'department': 'general_physician',
    'degree': 'MBBS, MD',
    'experience': 15,
    'specialization': 'Internal Medicine',
    'consultation_fee': 50.00
}

# Dentist
{
    'name': 'Dr. Michael Chen',
    'department': 'dentist',
    'degree': 'BDS, MDS',
    'experience': 12,
    'specialization': 'Orthodontics and General Dentistry',
    'consultation_fee': 75.00
}
```

## Development

### Adding New Features

1. **Backend**: Add models, views, and serializers in Django apps
2. **Frontend**: Create new React components and pages
3. **API Integration**: Update API endpoints and frontend calls
4. **Testing**: Test both backend and frontend functionality

### Customizing ML Model

1. **Data Preparation**: Prepare symptom-illness dataset
2. **Model Training**: Train new model using scikit-learn
3. **Model Export**: Save model as pickle files
4. **Integration**: Update `SymptomPredictionService` class

## Deployment

### Production Setup

1. **Environment Variables**: Set up production environment variables
2. **Database**: Use PostgreSQL or MySQL for production
3. **Static Files**: Configure static file serving
4. **Security**: Update Django settings for production
5. **Frontend Build**: Build React app for production

### Docker Deployment (Optional)

```dockerfile
# Backend Dockerfile
FROM python:3.9
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 8000
CMD ["python", "manage.py", "runserver", "0.0.0.0:8000"]
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Support

For support and questions, please open an issue in the repository.

---

**Note**: This is a demonstration project. For actual medical use, ensure compliance with healthcare regulations and data privacy laws (HIPAA, GDPR, etc.). 