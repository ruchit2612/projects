from django.db import models

# Create your models here.

class Doctor(models.Model):
    DEPARTMENT_CHOICES = [
        ('dentist', 'Dentist'),
        ('orthopedic', 'Orthopedic'),
        ('general_physician', 'General Physician'),
        ('children_specialist', 'Children Specialist'),
        ('emergency', 'Emergency Doctor'),
        ('dermatologist', 'Dermatologist'),
    ]
    
    name = models.CharField(max_length=100)
    department = models.CharField(max_length=20, choices=DEPARTMENT_CHOICES)
    degree = models.CharField(max_length=100)
    experience = models.PositiveIntegerField(help_text="Years of experience")
    specialization = models.CharField(max_length=200)
    available = models.BooleanField(default=True)
    image = models.ImageField(upload_to='doctors/', null=True, blank=True)
    bio = models.TextField(blank=True)
    consultation_fee = models.DecimalField(max_digits=8, decimal_places=2, default=0.00)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Dr. {self.name} - {self.get_department_display()}"
    
    class Meta:
        ordering = ['name']
