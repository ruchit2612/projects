from django.core.management.base import BaseCommand
from doctors.models import Doctor

class Command(BaseCommand):
    help = 'Add sample doctors to the database'

    def handle(self, *args, **options):
        doctors_data = [
            {
                'name': 'Dr. Sarah Johnson',
                'department': 'general_physician',
                'degree': 'MBBS, MD',
                'experience': 15,
                'specialization': 'Internal Medicine and Primary Care',
                'bio': 'Experienced general physician with expertise in preventive care and chronic disease management.',
                'consultation_fee': 50.00,
                'available': True,
            },
            {
                'name': 'Dr. Michael Chen',
                'department': 'dentist',
                'degree': 'BDS, MDS',
                'experience': 12,
                'specialization': 'Orthodontics and General Dentistry',
                'bio': 'Specialized in orthodontic treatments and general dental procedures with a gentle approach.',
                'consultation_fee': 75.00,
                'available': True,
            },
            {
                'name': 'Dr. Emily Rodriguez',
                'department': 'orthopedic',
                'degree': 'MBBS, MS Orthopedics',
                'experience': 18,
                'specialization': 'Joint Replacement and Sports Medicine',
                'bio': 'Expert in orthopedic surgery with focus on joint replacements and sports-related injuries.',
                'consultation_fee': 100.00,
                'available': True,
            },
            {
                'name': 'Dr. David Thompson',
                'department': 'children_specialist',
                'degree': 'MBBS, MD Pediatrics',
                'experience': 20,
                'specialization': 'Pediatric Care and Child Development',
                'bio': 'Dedicated pediatrician with extensive experience in child healthcare and development.',
                'consultation_fee': 60.00,
                'available': True,
            },
            {
                'name': 'Dr. Lisa Wang',
                'department': 'emergency',
                'degree': 'MBBS, MD Emergency Medicine',
                'experience': 14,
                'specialization': 'Emergency Medicine and Critical Care',
                'bio': 'Emergency medicine specialist providing 24/7 critical care and emergency treatment.',
                'consultation_fee': 120.00,
                'available': True,
            },
            {
                'name': 'Dr. James Wilson',
                'department': 'general_physician',
                'degree': 'MBBS, MD',
                'experience': 10,
                'specialization': 'Family Medicine and Preventive Care',
                'bio': 'Family medicine specialist focused on comprehensive healthcare for all age groups.',
                'consultation_fee': 45.00,
                'available': True,
            },
            {
                'name': 'Dr. Maria Garcia',
                'department': 'dentist',
                'degree': 'BDS, MDS',
                'experience': 8,
                'specialization': 'Cosmetic Dentistry and Oral Surgery',
                'bio': 'Specialized in cosmetic dental procedures and oral surgery with modern techniques.',
                'consultation_fee': 85.00,
                'available': True,
            },
            {
                'name': 'Dr. Robert Kim',
                'department': 'orthopedic',
                'degree': 'MBBS, MS Orthopedics',
                'experience': 16,
                'specialization': 'Spine Surgery and Trauma',
                'bio': 'Expert in spine surgery and orthopedic trauma with advanced surgical techniques.',
                'consultation_fee': 110.00,
                'available': True,
            },
            {
                'name': 'Dr. Priya Sharma',
                'department': 'dermatologist',
                'degree': 'MBBS, MD Dermatology',
                'experience': 8,
                'specialization': 'Skin, Hair, and Nail Disorders',
                'bio': 'Expert in treating skin allergies, acne, eczema, and cosmetic dermatology.'
            },
        ]

        created_count = 0
        for doctor_data in doctors_data:
            doctor, created = Doctor.objects.get_or_create(
                name=doctor_data['name'],
                defaults=doctor_data
            )
            if created:
                created_count += 1
                self.stdout.write(
                    self.style.SUCCESS(f'Created doctor: {doctor.name}')
                )
            else:
                self.stdout.write(
                    self.style.WARNING(f'Doctor already exists: {doctor.name}')
                )

        self.stdout.write(
            self.style.SUCCESS(f'Successfully added {created_count} new doctors')
        ) 