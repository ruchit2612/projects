from django.contrib import admin
from .models import Doctor

@admin.register(Doctor)
class DoctorAdmin(admin.ModelAdmin):
    list_display = ['name', 'department', 'degree', 'experience', 'available', 'consultation_fee']
    list_filter = ['department', 'available', 'experience']
    search_fields = ['name', 'specialization']
    list_editable = ['available', 'consultation_fee']
    ordering = ['name']
