from rest_framework import serializers
from .models import Doctor

class DoctorSerializer(serializers.ModelSerializer):
    department_display = serializers.CharField(source='get_department_display', read_only=True)
    
    class Meta:
        model = Doctor
        fields = [
            'id', 'name', 'department', 'department_display', 'degree', 
            'experience', 'specialization', 'available', 'image', 'bio', 
            'consultation_fee', 'created_at', 'updated_at'
        ]
        read_only_fields = ['created_at', 'updated_at'] 