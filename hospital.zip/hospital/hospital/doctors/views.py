from django.shortcuts import render
from rest_framework import viewsets, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Doctor
from .serializers import DoctorSerializer

# Create your views here.

class DoctorViewSet(viewsets.ModelViewSet):
    queryset = Doctor.objects.all()
    serializer_class = DoctorSerializer
    permission_classes = [permissions.AllowAny]  # Allow read access to all, write access controlled by frontend
    

    
    @action(detail=False, methods=['get'])
    def by_department(self, request):
        """Get doctors filtered by department"""
        department = request.query_params.get('department', '')
        if department:
            doctors = Doctor.objects.filter(department=department, available=True)
        else:
            doctors = Doctor.objects.filter(available=True)
        
        serializer = self.get_serializer(doctors, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def available(self, request):
        """Get only available doctors"""
        doctors = Doctor.objects.filter(available=True)
        serializer = self.get_serializer(doctors, many=True)
        return Response(serializer.data)
