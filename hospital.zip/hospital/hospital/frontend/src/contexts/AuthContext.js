import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  // Set up axios defaults
  axios.defaults.baseURL = process.env.REACT_APP_API_URL || 'http://127.0.0.1:8000';

  useEffect(() => {
    // Check if user is logged in on app start
    const token = localStorage.getItem('token');
    const adminToken = localStorage.getItem('adminToken');

    if (token) {
      axios.defaults.headers.common['Authorization'] = `Token ${token}`;
      setIsAuthenticated(true);
    }

    if (adminToken) {
      setIsAdmin(true);
      // Keep authenticated for admin protected pages
      setIsAuthenticated(true);
      setUser((current) => current || { username: 'health_nexus', isAdmin: true });
    }

    setLoading(false);
  }, []);

  const login = async (username, password) => {
    try {
      const response = await axios.post('/api/auth/login/', {
        username,
        password,
      });

      const { token, user_id, username: userUsername } = response.data;

      localStorage.setItem('token', token);
      axios.defaults.headers.common['Authorization'] = `Token ${token}`;

      setUser({ id: user_id, username: userUsername });
      setIsAuthenticated(true);

      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.error || 'Login failed'
      };
    }
  };

  const register = async (userData) => {
    try {
      const response = await axios.post('/api/auth/register/', userData);

      const { token, user_id, username } = response.data;

      localStorage.setItem('token', token);
      axios.defaults.headers.common['Authorization'] = `Token ${token}`;

      setUser({ id: user_id, username });
      setIsAuthenticated(true);

      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.error || 'Registration failed'
      };
    }
  };

  const logout = async () => {
    try {
      if (isAdmin) {
        // Admin logout - no API call needed
        localStorage.removeItem('adminToken');
        setIsAdmin(false);
        setIsAuthenticated(false);
        setUser(null);
      } else {
        await axios.post('/api/auth/logout/');
        localStorage.removeItem('token');
        delete axios.defaults.headers.common['Authorization'];
        setUser(null);
        setIsAuthenticated(false);
      }
    } catch (error) {
      // Even if API call fails, clear local state
      localStorage.removeItem('token');
      localStorage.removeItem('adminToken');
      delete axios.defaults.headers.common['Authorization'];
      setUser(null);
      setIsAuthenticated(false);
      setIsAdmin(false);
    }
  };

  const adminLogin = async (username, password) => {
    // Hardcoded admin credentials
    const ADMIN_USERNAME = 'health_nexus';
    const ADMIN_PASSWORD = 'health_nexus_123';

    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      localStorage.setItem('adminToken', 'admin_authenticated');
      setUser({ username: 'health_nexus', isAdmin: true });
      setIsAdmin(true);
      setIsAuthenticated(true); // Admin should be authenticated to access dashboard
      return { success: true };
    } else {
      return {
        success: false,
        error: 'Invalid admin credentials. Please enter correct username and password.'
      };
    }
  };

  const forgotPassword = async (email) => {
    try {
      const response = await axios.post('/api/auth/forgot-password/', { email });
      return { success: true, message: response.data.message };
    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.error || 'Failed to send OTP',
      };
    }
  };

  const verifyOtp = async (email, otp) => {
    try {
      const response = await axios.post('/api/auth/verify-otp/', { email, otp });
      return { success: true, message: response.data.message };
    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.error || 'OTP verification failed',
      };
    }
  };

  const changePassword = async (email, otp, newPassword) => {
    try {
      const response = await axios.post('/api/auth/change-password/', { email, otp, new_password: newPassword });
      return { success: true, message: response.data.message };
    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.error || 'Password change failed',
      };
    }
  };

  const value = {
    user,
    isAuthenticated,
    isAdmin,
    loading,
    login,
    register,
    logout,
    adminLogin,
    forgotPassword,
    verifyOtp,
    changePassword,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}; 