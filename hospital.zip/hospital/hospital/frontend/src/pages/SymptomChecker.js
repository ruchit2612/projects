import React, { useState, useEffect } from 'react';
import {
  Container,
  Paper,
  Typography,
  TextField,
  Button,
  Box,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Card,
  CardContent,
  Alert,
  CircularProgress,
  Chip,
  Divider,
  Autocomplete,
  FormHelperText,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Stepper,
  Step,
  StepLabel,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
} from '@mui/material';
import { Psychology, LocalHospital, BookOnline, Add, Remove, CreditCard, Receipt, CheckCircle, Schedule, Download } from '@mui/icons-material';
import axios from 'axios';
import jsPDF from 'jspdf';

const SymptomChecker = () => {
  const [formData, setFormData] = useState({
    age: '',
    gender: '',
  });
  const [symptoms, setSymptoms] = useState(['', '']); // Start with two symptoms, allow up to 3
  const [availableSymptoms, setAvailableSymptoms] = useState([]);
  const [prediction, setPrediction] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  // Payment and booking states
  const [bookingDialog, setBookingDialog] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const [bookingData, setBookingData] = useState({
    appointment_date: '',
    appointment_time: '',
    symptoms: '',
  });
  const [paymentData, setPaymentData] = useState({
    cardNumber: '',
    cardHolderName: '',
    expiryDate: '',
    cvv: '',
  });
  const [paymentErrors, setPaymentErrors] = useState({});
  const [bookingLoading, setBookingLoading] = useState(false);
  const [availableSlots, setAvailableSlots] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [invoice, setInvoice] = useState(null);
  const [selectedDoctor, setSelectedDoctor] = useState(null);

  const steps = ['Appointment Details', 'Payment', 'Confirmation'];

  // Load available symptoms on component mount
  useEffect(() => {
    loadAvailableSymptoms();
  }, []);

  const loadAvailableSymptoms = async () => {
    try {
      const response = await axios.get('/api/predictions/available_symptoms/');
      setAvailableSymptoms(response.data.symptoms || []);
    } catch (err) {
      // Silently ignore; list can remain empty
      // Optionally, set an error banner if desired
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSymptomChange = (index, newValue) => {
    const newSymptoms = [...symptoms];
    newSymptoms[index] = newValue;
    setSymptoms(newSymptoms);
  };

  const addSymptom = () => {
    if (symptoms.length < 3) {
      setSymptoms([...symptoms, '']);
    }
  };

  const removeSymptom = (index) => {
    if (symptoms.length > 2) {
      const newSymptoms = symptoms.filter((_, i) => i !== index);
      setSymptoms(newSymptoms);
    }
  };

  const getFilteredSymptoms = (currentIndex) => {
    // Filter out already selected symptoms from other fields
    return availableSymptoms.filter(symptom => 
      !symptoms.some((selectedSymptom, idx) => 
        idx !== currentIndex && selectedSymptom === symptom
      )
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setPrediction(null);
    setLoading(true);

    // Filter out empty symptoms
    const nonEmptySymptoms = symptoms.filter(symptom => symptom.trim() !== '');
    
    if (nonEmptySymptoms.length < 2) {
      setError('Please enter at least two symptoms for accurate prediction');
      setLoading(false);
      return;
    }

    if (nonEmptySymptoms.length > 3) {
      setError('Maximum 3 symptoms allowed');
      setLoading(false);
      return;
    }

    const requestData = {
      symptoms: nonEmptySymptoms.join(', '),
      age: formData.age,
      gender: formData.gender,
    };

    try {
      const response = await axios.post('/api/predictions/predict/', requestData);
      setPrediction(response.data);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to get prediction');
    } finally {
      setLoading(false);
    }
  };

  

  const handleBookAppointment = (doctor) => {
    setSelectedDoctor(doctor);
    setBookingData({
      appointment_date: '',
      appointment_time: '',
      symptoms: symptoms.filter(s => s.trim() !== '').join(', '),
    });
    setBookingDialog(true);
  };

  const isPastDateTime = () => {
    if (!bookingData.appointment_date || !bookingData.appointment_time) return false;
    
    const selectedDate = new Date(bookingData.appointment_date);
    const [hours, minutes] = bookingData.appointment_time.split(':').map(Number);
    selectedDate.setHours(hours, minutes, 0, 0);
    
    return selectedDate <= new Date();
  };

  const validateCardNumber = (cardNumber) => {
    // Remove spaces and dashes
    const cleanNumber = cardNumber.replace(/\s+/g, '').replace(/-/g, '');
    
    // Simple validation: exactly 16 digits, only numbers
    const cardPattern = /^[0-9]{16}$/;
    
    return cardPattern.test(cleanNumber);
  };

  const validateExpiryDate = (expiryDate) => {
    if (!expiryDate || expiryDate.length !== 5) return false;
    
    const [month, year] = expiryDate.split('/');
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear() % 100;
    const currentMonth = currentDate.getMonth() + 1;
    
    const expMonth = parseInt(month);
    const expYear = parseInt(year);
    
    if (expMonth < 1 || expMonth > 12) return false;
    if (expYear < currentYear || (expYear === currentYear && expMonth < currentMonth)) return false;
    
    return true;
  };

  const validateCVV = (cvv) => {
    return /^\d{3,4}$/.test(cvv);
  };

  const validatePaymentForm = () => {
    const errors = {};
    
    if (!paymentData.cardNumber || !validateCardNumber(paymentData.cardNumber)) {
      errors.cardNumber = 'Please enter a valid card number';
    }
    
    if (!paymentData.cardHolderName || paymentData.cardHolderName.trim().length < 3) {
      errors.cardHolderName = 'Please enter a valid cardholder name';
    }
    
    if (!paymentData.expiryDate || !validateExpiryDate(paymentData.expiryDate)) {
      errors.expiryDate = 'Please enter a valid expiry date (MM/YY)';
    }
    
    if (!paymentData.cvv || !validateCVV(paymentData.cvv)) {
      errors.cvv = 'Please enter a valid CVV (3-4 digits)';
    }
    
    setPaymentErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const formatCardNumber = (value) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || '';
    const parts = [];
    
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    
    if (parts.length) {
      return parts.join(' ');
    } else {
      return v;
    }
  };

  const formatExpiryDate = (value) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    if (v.length >= 2) {
      return v.substring(0, 2) + '/' + v.substring(2, 4);
    }
    return v;
  };

  const generateInvoice = () => {
    const invoiceNumber = 'INV-' + Date.now();
    const currentDate = new Date().toLocaleDateString();
    const appointmentDate = new Date(bookingData.appointment_date).toLocaleDateString();
    
    return {
      invoiceNumber,
      date: currentDate,
      doctorName: selectedDoctor.name,
      doctorDepartment: selectedDoctor.department,
      appointmentDate,
      appointmentTime: bookingData.appointment_time,
      consultationFee: selectedDoctor.consultation_fee,
      symptoms: bookingData.symptoms || 'Not specified',
      paymentMethod: 'Credit Card',
      cardLast4: paymentData.cardNumber.slice(-4),
    };
  };

  const downloadInvoicePDF = () => {
    if (!invoice) return;

    const doc = new jsPDF();
    
    // Header
    doc.setFontSize(20);
    doc.setFont('helvetica', 'bold');
    doc.text('HOSPITAL INVOICE', 105, 20, { align: 'center' });
    
    // Invoice details
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text(`Invoice Number: ${invoice.invoiceNumber}`, 20, 40);
    doc.text(`Date: ${invoice.date}`, 20, 50);
    
    // Doctor information
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Doctor Information:', 20, 70);
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text(`Name: ${invoice.doctorName}`, 20, 80);
    doc.text(`Department: ${invoice.doctorDepartment}`, 20, 90);
    
    // Appointment details
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Appointment Details:', 20, 110);
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text(`Date: ${invoice.appointmentDate}`, 20, 120);
    doc.text(`Time: ${invoice.appointmentTime}`, 20, 130);
    doc.text(`Symptoms: ${invoice.symptoms}`, 20, 140);
    
    // Payment information
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Payment Information:', 20, 160);
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text(`Payment Method: ${invoice.paymentMethod}`, 20, 170);
    doc.text(`Card: ****${invoice.cardLast4}`, 20, 180);
    
    // Amount
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text(`Total Amount: ₹${invoice.consultationFee}`, 20, 200);
    
    // Footer
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text('Thank you for choosing our hospital!', 105, 250, { align: 'center' });
    doc.text('This is a computer-generated invoice.', 105, 260, { align: 'center' });
    
    // Download the PDF
    doc.save(`invoice-${invoice.invoiceNumber}.pdf`);
  };

  const fetchAvailableSlots = async (date) => {
    if (!date) {
      setAvailableSlots([]);
      return;
    }

    setLoadingSlots(true);
    try {
      const response = await axios.get(`/api/appointments/available_slots/`, {
        params: {
          doctor_id: selectedDoctor.id,
          appointment_date: date
        }
      });
      setAvailableSlots(response.data.available_slots || []);
    } catch (err) {
      console.error('Failed to fetch available slots:', err);
      setAvailableSlots([]);
    } finally {
      setLoadingSlots(false);
    }
  };

  const formatTime = (timeString) => {
    const [hours, minutes] = timeString.split(':').map(Number);
    const date = new Date();
    date.setHours(hours, minutes);
    return date.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const checkUserAppointmentConflict = async (date, time) => {
    try {
      // Check if user already has an appointment at this date and time
      const response = await axios.get('/api/appointments/check_user_conflict/', {
        params: {
          appointment_date: date,
          appointment_time: time
        }
      });
      
      return response.data.has_conflict;
    } catch (err) {
      console.error('Failed to check user appointment conflict:', err);
      return false;
    }
  };

  const handleNext = async () => {
    if (activeStep === 0) {
      // Validate appointment details
      if (!bookingData.appointment_date || !bookingData.appointment_time || isPastDateTime()) {
        return;
      }
      
      // Check if the selected slot is actually available
      try {
        setLoadingSlots(true);
        const response = await axios.get(`/api/appointments/available_slots/`, {
          params: {
            doctor_id: selectedDoctor.id,
            appointment_date: bookingData.appointment_date
          }
        });
        
        const availableSlots = response.data.available_slots || [];
        const isSlotAvailable = availableSlots.includes(bookingData.appointment_time);
        
        if (!isSlotAvailable) {
          setError('This time slot is no longer available. Please select another time.');
          return;
        }
        
        // Check if user already has an appointment at this date and time
        const hasConflict = await checkUserAppointmentConflict(
          bookingData.appointment_date, 
          bookingData.appointment_time
        );
        
        if (hasConflict) {
          setError('You already have an appointment at this date and time. Please choose a different time or date.');
          return;
        }
        
        // Slot is available and no conflicts, proceed to payment
        setActiveStep(1);
      } catch (err) {
        console.error('Failed to check slot availability:', err);
        setError('Failed to verify slot availability. Please try again.');
        return;
      } finally {
        setLoadingSlots(false);
      }
    } else if (activeStep === 1) {
      // Validate payment and proceed to confirmation
      if (validatePaymentForm()) {
        const invoiceData = generateInvoice();
        setInvoice(invoiceData);
        setActiveStep(2);
      }
    }
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const handleBookingSubmit = async () => {
    setBookingLoading(true);
    setError('');
    
    try {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Book the appointment
      await axios.post('/api/appointments/', {
        ...bookingData,
        doctor: selectedDoctor.id,
      });
      
      setBookingDialog(false);
      setActiveStep(0);
      setBookingData({ appointment_date: '', appointment_time: '', symptoms: '' });
      setPaymentData({ cardNumber: '', cardHolderName: '', expiryDate: '', cvv: '' });
      setInvoice(null);
      setSelectedDoctor(null);
      
      // Navigate to appointments page
      window.location.href = '/appointments';
    } catch (err) {
      console.error('Booking error:', err.response?.data);
      
      if (err.response?.data) {
        const errorData = err.response.data;
        
        if (typeof errorData === 'object') {
          const errorMessages = Object.values(errorData).flat();
          setError(errorMessages.join(', '));
        } else if (typeof errorData === 'string') {
          setError(errorData);
        } else {
          setError('Failed to book appointment. Please try again.');
        }
      } else {
        setError('Failed to book appointment. Please check your connection and try again.');
      }
    } finally {
      setBookingLoading(false);
    }
  };

  const handleCloseDialog = () => {
    setBookingDialog(false);
    setActiveStep(0);
    setBookingData({ appointment_date: '', appointment_time: '', symptoms: '' });
    setPaymentData({ cardNumber: '', cardHolderName: '', expiryDate: '', cvv: '' });
    setAvailableSlots([]);
    setError('');
    setPaymentErrors({});
    setInvoice(null);
    setSelectedDoctor(null);
  };

  const isFormValid = () => {
    const nonEmptySymptoms = symptoms.filter(symptom => symptom.trim() !== '');
    return nonEmptySymptoms.length >= 2 && formData.age && formData.gender;
  };

  const renderStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Appointment Date"
                type="date"
                name="appointment_date"
                value={bookingData.appointment_date}
                onChange={(e) => {
                  const newDate = e.target.value;
                  setBookingData({...bookingData, appointment_date: newDate, appointment_time: ''});
                  setError(''); // Clear any previous errors
                  fetchAvailableSlots(newDate);
                }}
                InputLabelProps={{ shrink: true }}
                inputProps={{ 
                  min: new Date().toISOString().split('T')[0],
                  required: true 
                }}
                required
                helperText={isPastDateTime() ? "Cannot book appointments in the past" : ""}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Time</InputLabel>
                <Select
                  name="appointment_time"
                  value={bookingData.appointment_time}
                  label="Time"
                  onChange={(e) => {
                    setBookingData({...bookingData, appointment_time: e.target.value});
                    setError(''); // Clear any previous errors
                  }}
                  disabled={loadingSlots || availableSlots.length === 0}
                >
                  {loadingSlots ? (
                    <MenuItem disabled>
                      <CircularProgress size={16} sx={{ mr: 1 }} />
                      Loading available times...
                    </MenuItem>
                  ) : availableSlots.length === 0 ? (
                    <MenuItem disabled>
                      No available times for this date
                    </MenuItem>
                  ) : (
                    availableSlots.map((slot) => (
                      <MenuItem key={slot} value={slot}>
                        {formatTime(slot)}
                      </MenuItem>
                    ))
                  )}
                </Select>
                {!loadingSlots && bookingData.appointment_date && (
                  <FormHelperText>
                    {availableSlots.length > 0 
                      ? `${availableSlots.length} time slot(s) available` 
                      : 'No available time slots for this date'
                    }
                  </FormHelperText>
                )}
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                multiline
                rows={3}
                label="Symptoms (Optional)"
                name="symptoms"
                value={bookingData.symptoms}
                onChange={(e) => setBookingData({...bookingData, symptoms: e.target.value})}
                placeholder="Describe your symptoms or reason for visit..."
              />
            </Grid>
          </Grid>
        );
      
      case 1:
        return (
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <Typography variant="h6" gutterBottom>
                Payment Details
              </Typography>
              <Typography variant="body2" color="text.secondary" gutterBottom>
                Consultation Fee: ₹{selectedDoctor.consultation_fee}
              </Typography>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Card Number"
                value={paymentData.cardNumber}
                onChange={(e) => setPaymentData({
                  ...paymentData,
                  cardNumber: formatCardNumber(e.target.value)
                })}
                error={!!paymentErrors.cardNumber}
                helperText={paymentErrors.cardNumber}
                placeholder="1234 5678 9012 3456"
                inputProps={{ maxLength: 19 }}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Cardholder Name"
                value={paymentData.cardHolderName}
                onChange={(e) => setPaymentData({
                  ...paymentData,
                  cardHolderName: e.target.value
                })}
                error={!!paymentErrors.cardHolderName}
                helperText={paymentErrors.cardHolderName}
                placeholder="JOHN DOE"
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="Expiry Date"
                value={paymentData.expiryDate}
                onChange={(e) => setPaymentData({
                  ...paymentData,
                  expiryDate: formatExpiryDate(e.target.value)
                })}
                error={!!paymentErrors.expiryDate}
                helperText={paymentErrors.expiryDate}
                placeholder="MM/YY"
                inputProps={{ maxLength: 5 }}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="CVV"
                value={paymentData.cvv}
                onChange={(e) => setPaymentData({
                  ...paymentData,
                  cvv: e.target.value.replace(/\D/g, '')
                })}
                error={!!paymentErrors.cvv}
                helperText={paymentErrors.cvv}
                placeholder="123"
                inputProps={{ maxLength: 4 }}
              />
            </Grid>
          </Grid>
        );
      
      case 2:
        return (
          <Box>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <CheckCircle color="success" sx={{ mr: 1 }} />
              <Typography variant="h6">Payment Successful!</Typography>
            </Box>
            
            <Paper sx={{ p: 2, mb: 2 }}>
              <Typography variant="h6" gutterBottom>Invoice</Typography>
              <TableContainer>
                <Table size="small">
                  <TableBody>
                    <TableRow>
                      <TableCell><strong>Invoice Number:</strong></TableCell>
                      <TableCell>{invoice.invoiceNumber}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell><strong>Date:</strong></TableCell>
                      <TableCell>{invoice.date}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell><strong>Doctor:</strong></TableCell>
                      <TableCell>{invoice.doctorName}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell><strong>Department:</strong></TableCell>
                      <TableCell>{invoice.doctorDepartment}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell><strong>Appointment Date:</strong></TableCell>
                      <TableCell>{invoice.appointmentDate}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell><strong>Appointment Time:</strong></TableCell>
                      <TableCell>{invoice.appointmentTime}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell><strong>Symptoms:</strong></TableCell>
                      <TableCell>{invoice.symptoms}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell><strong>Payment Method:</strong></TableCell>
                      <TableCell>{invoice.paymentMethod} (****{invoice.cardLast4})</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell><strong>Amount:</strong></TableCell>
                      <TableCell>₹{invoice.consultationFee}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </TableContainer>
            </Paper>
            
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              Your appointment has been confirmed. You will receive a confirmation email shortly.
            </Typography>
            
            <Button
              variant="outlined"
              color="primary"
              startIcon={<Download />}
              onClick={downloadInvoicePDF}
              fullWidth
            >
              Download Invoice PDF
            </Button>
          </Box>
        );
      
      default:
        return null;
    }
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h3" component="h1" gutterBottom align="center">
        <Psychology sx={{ mr: 2, verticalAlign: 'middle' }} />
        AI Symptom Checker
      </Typography>
      
      <Typography variant="h6" color="text.secondary" align="center" paragraph>
        Select 2-3 symptoms and get AI-powered preliminary diagnosis with doctor recommendations
      </Typography>

      <Grid container spacing={4}>
        {/* Input Form */}
        <Grid item xs={12} md={5}>
          <Paper elevation={3} sx={{ p: 3 }}>
            <Typography variant="h5" gutterBottom>
              Enter Your Symptoms
            </Typography>
            
            {error && (
              <Alert severity="error" sx={{ mb: 2 }}>
                {error}
              </Alert>
            )}

            <Box component="form" onSubmit={handleSubmit}>
              {/* Symptoms Section */}
              <Typography variant="h6" gutterBottom sx={{ mt: 2, mb: 1 }}>
                Symptoms (Select 2-3)
              </Typography>
              
              {symptoms.map((symptom, index) => (
                <Box key={index} sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Autocomplete
                    freeSolo
                    options={getFilteredSymptoms(index)}
                    value={symptom}
                    onChange={(event, newValue) => handleSymptomChange(index, newValue || '')}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        fullWidth
                        label={`Symptom ${index + 1}`}
                        placeholder="Select or type a symptom..."
                        size="small"
                      />
                    )}
                    sx={{ flex: 1 }}
                  />
                  {symptoms.length > 2 && (
                    <Button
                      variant="outlined"
                      color="error"
                      size="small"
                      onClick={() => removeSymptom(index)}
                      sx={{ minWidth: 'auto', px: 1 }}
                    >
                      <Remove />
                    </Button>
                  )}
                </Box>
              ))}
              
              {symptoms.length < 3 && (
                <Button
                  variant="outlined"
                  color="primary"
                  startIcon={<Add />}
                  onClick={addSymptom}
                  sx={{ mt: 1 }}
                >
                  Add Another Symptom
                </Button>
              )}

              <FormHelperText sx={{ mb: 2 }}>
                Select at least 2 symptoms for better accuracy. Choose the most relevant symptoms.
                {(() => {
                  const nonEmptySymptoms = symptoms.filter(symptom => symptom.trim() !== '');
                  return nonEmptySymptoms.length > 0 && (
                    <span style={{ color: nonEmptySymptoms.length >= 2 ? 'green' : 'orange' }}>
                      {' '}({nonEmptySymptoms.length}/2 minimum)
                    </span>
                  );
                })()}
              </FormHelperText>

              <Divider sx={{ my: 2 }} />
              
              {/* Patient Information */}
              <Typography variant="h6" gutterBottom>
                Patient Information
              </Typography>
              
              <TextField
                margin="normal"
                required
                fullWidth
                name="age"
                label="Age"
                type="number"
                value={formData.age}
                onChange={handleChange}
                inputProps={{ min: 1, max: 120 }}
              />
              
              <FormControl fullWidth margin="normal" required>
                <InputLabel>Gender</InputLabel>
                <Select
                  name="gender"
                  value={formData.gender}
                  label="Gender"
                  onChange={handleChange}
                >
                  <MenuItem value="M">Male</MenuItem>
                  <MenuItem value="F">Female</MenuItem>
                  <MenuItem value="O">Other</MenuItem>
                </Select>
              </FormControl>
              
              <Button
                type="submit"
                fullWidth
                variant="contained"
                size="large"
                sx={{ mt: 3 }}
                disabled={loading || !isFormValid()}
                startIcon={loading ? <CircularProgress size={20} /> : <Psychology />}
              >
                {loading ? 'Analyzing...' : 'Check Symptoms'}
              </Button>
            </Box>
          </Paper>
        </Grid>

        {/* Results */}
        <Grid item xs={12} md={7}>
          <Paper elevation={3} sx={{ p: 3, minHeight: '500px' }}>
            <Typography variant="h5" gutterBottom>
              AI Analysis Results
            </Typography>
            
            {prediction ? (
              <Box>
                {/* Illness Prediction */}
                <Card sx={{ mb: 3 }}>
                  <CardContent>
                    <Typography variant="h6" gutterBottom color="primary">
                      Predicted Condition
                    </Typography>
                    <Typography variant="h4" color="primary" gutterBottom>
                      {prediction.prediction.illness}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Based on your symptoms, age, and gender, our AI model suggests this condition.
                      Please consult with a healthcare professional for accurate diagnosis.
                    </Typography>
                  </CardContent>
                </Card>

                {/* Doctor Type Prediction */}
                <Card sx={{ mb: 3 }}>
                  <CardContent>
                    <Typography variant="h6" gutterBottom color="secondary">
                      Recommended Doctor Type
                    </Typography>
                    <Typography variant="h5" color="secondary" gutterBottom>
                      {prediction.prediction.doctor_type}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      This type of specialist is best suited to treat your condition.
                    </Typography>
                  </CardContent>
                </Card>

                {/* Recommended Doctors */}
                {prediction.recommended_doctors && prediction.recommended_doctors.length > 0 && (
                  <Card sx={{ mb: 3 }}>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>
                        <LocalHospital sx={{ mr: 1, verticalAlign: 'middle' }} />
                        Available Doctors ({prediction.recommended_doctors.length})
                      </Typography>
                      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                        All {prediction.prediction.doctor_type} specialists available in our hospital:
                      </Typography>
                      
                      <Grid container spacing={2}>
                        {prediction.recommended_doctors.map((doctor, index) => (
                          <Grid item xs={12} sm={6} key={doctor.id}>
                            <Card variant="outlined" sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                              <CardContent sx={{ flexGrow: 1 }}>
                                <Typography variant="h6" gutterBottom>
                                  Dr. {doctor.name.replace(/^\s*Dr\.?\s*/i, '').trim()}
                                </Typography>
                                <Chip 
                                  label={doctor.department} 
                                  color="primary" 
                                  size="small"
                                  sx={{ mb: 1 }}
                                />
                                <Typography variant="body2" color="text.secondary" gutterBottom>
                                  {doctor.specialization}
                                </Typography>
                                <Typography variant="body2" color="text.secondary" gutterBottom>
                                  {doctor.experience} years of experience
                                </Typography>
                                <Typography variant="body2" color="success.main" gutterBottom sx={{ fontWeight: 600 }}>
                                  Consultation Fee: ₹{doctor.consultation_fee}
                                </Typography>
                                
                                <Button
                                  variant="contained"
                                  color="success"
                                  startIcon={<BookOnline />}
                                  onClick={() => handleBookAppointment(doctor)}
                                  sx={{ mt: 1 }}
                                  fullWidth
                                  size="small"
                                >
                                  Book Appointment
                                </Button>
                              </CardContent>
                            </Card>
                          </Grid>
                        ))}
                      </Grid>
                    </CardContent>
                  </Card>
                )}

                {(!prediction.recommended_doctors || prediction.recommended_doctors.length === 0) && (
                  <Card sx={{ mb: 3, bgcolor: 'warning.light' }}>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>
                        No Available Doctors
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Currently, no doctors are available in the {prediction.prediction.doctor_type} department. 
                        Please check back later or contact the hospital directly.
                      </Typography>
                    </CardContent>
                  </Card>
                )}
              </Box>
            ) : (
              <Box sx={{ 
                display: 'flex', 
                flexDirection: 'column', 
                alignItems: 'center', 
                justifyContent: 'center',
                height: '400px',
                textAlign: 'center'
              }}>
                <Psychology sx={{ fontSize: 60, color: 'text.secondary', mb: 2 }} />
                <Typography variant="h6" color="text.secondary" gutterBottom>
                  Select your symptoms to get started
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Choose 2-3 symptoms and our AI will analyze and recommend the most suitable doctor
                </Typography>
              </Box>
            )}
          </Paper>
        </Grid>
      </Grid>

      {/* Booking Dialog */}
      <Dialog open={bookingDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            {activeStep === 0 && <Schedule />}
            {activeStep === 1 && <CreditCard />}
            {activeStep === 2 && <Receipt />}
            Book Appointment with Dr. {selectedDoctor?.name.replace(/^\s*Dr\.?\s*/i, '').trim()}
          </Box>
        </DialogTitle>
        <DialogContent>
          {error && (
            <Alert 
              severity="error" 
              sx={{ mb: 2 }}
              action={
                <Button
                  color="inherit"
                  size="small"
                  variant="outlined"
                  sx={{ 
                    border: '1px solid rgba(255, 255, 255, 0.3)',
                    '&:hover': {
                      backgroundColor: 'rgba(255, 255, 255, 0.1)',
                      border: '1px solid rgba(255, 255, 255, 0.5)'
                    }
                  }}
                  onClick={() => {
                    setError('');
                    setActiveStep(0);
                    setBookingData({ appointment_date: '', appointment_time: '', symptoms: '' });
                    setAvailableSlots([]);
                    setPaymentData({ cardNumber: '', cardHolderName: '', expiryDate: '', cvv: '' });
                    setPaymentErrors({});
                    setInvoice(null);
                  }}
                >
                  Close
                </Button>
              }
            >
              {error}
            </Alert>
          )}
          
          <Stepper activeStep={activeStep} sx={{ mb: 3 }}>
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>
          
          {renderStepContent(activeStep)}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          {activeStep > 0 && (
            <Button onClick={handleBack}>Back</Button>
          )}
          {activeStep < steps.length - 1 ? (
            <Button 
              onClick={handleNext} 
              variant="contained"
              disabled={
                (activeStep === 0 && (!bookingData.appointment_date || !bookingData.appointment_time || isPastDateTime())) ||
                (activeStep === 1 && Object.keys(paymentErrors).length > 0) ||
                (activeStep === 0 && loadingSlots)
              }
            >
              {activeStep === 0 && loadingSlots ? <CircularProgress size={20} /> : 'Next'}
            </Button>
          ) : (
            <Button 
              onClick={handleBookingSubmit} 
              variant="contained"
              disabled={bookingLoading}
            >
              {bookingLoading ? <CircularProgress size={20} /> : 'Confirm Booking'}
            </Button>
          )}
        </DialogActions>
      </Dialog>

      {/* Disclaimer */}
      <Paper sx={{ mt: 4, p: 3, bgcolor: 'warning.light' }}>
        <Typography variant="h6" gutterBottom>
          ⚠️ Important Disclaimer
        </Typography>
        <Typography variant="body2">
          This symptom checker is for informational purposes only and should not be used as a substitute for professional medical advice, diagnosis, or treatment. 
          Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition. 
          The AI predictions are based on general patterns and may not be accurate for your specific situation.
        </Typography>
      </Paper>
    </Container>
  );
};

export default SymptomChecker; 