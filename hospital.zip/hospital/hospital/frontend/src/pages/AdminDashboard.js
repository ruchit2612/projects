import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Box,
  Tabs,
  Tab,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  IconButton,
  Chip,
  Grid,
  Card,
  CardContent,
  CircularProgress,
} from '@mui/material';
import {
  Delete,
  Add,
  Edit,
  AdminPanelSettings,
  LocalHospital,
  Event,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { isAdmin, logout } = useAuth();
  const [tabValue, setTabValue] = useState(0);
  const [appointments, setAppointments] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  // Doctor management states
  const [addDoctorDialog, setAddDoctorDialog] = useState(false);
  const [editDoctorDialog, setEditDoctorDialog] = useState(false);
  const [editingDoctor, setEditingDoctor] = useState(null);
  const [newDoctor, setNewDoctor] = useState({
    name: '',
    department: '',
    degree: '',
    experience: '',
    specialization: '',
    consultation_fee: '',
    bio: '',
  });

  // Cancel appointment states
  const [cancelDialog, setCancelDialog] = useState(false);
  const [cancelReason, setCancelReason] = useState('');
  const [appointmentToCancel, setAppointmentToCancel] = useState(null);

  // Reschedule appointment states
  const [rescheduleDialog, setRescheduleDialog] = useState(false);
  const [newAppointmentDate, setNewAppointmentDate] = useState('');
  const [newAppointmentTime, setNewAppointmentTime] = useState('');
  const [availableTimeSlots, setAvailableTimeSlots] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [success, setSuccess] = useState('');

  // Check if user is admin
  useEffect(() => {
    if (!isAdmin) {
      navigate('/admin-login');
    }
  }, [isAdmin, navigate]);

  // Load data
  useEffect(() => {
    if (isAdmin) {
      loadData();
    }
  }, [isAdmin]);

  const loadData = async () => {
    setLoading(true);
    setError('');
    
    try {
      // Load appointments
      const appointmentsResponse = await axios.get('/api/appointments/admin_list/');
      setAppointments(appointmentsResponse.data);
      
      // Load doctors
      const doctorsResponse = await axios.get('/api/doctors/');
      setDoctors(doctorsResponse.data);
    } catch (err) {
      console.error('Error loading data:', err);
      if (err.response) {
        setError(`Failed to load data: ${err.response.data?.error || err.response.statusText}`);
      } else if (err.request) {
        setError('Failed to connect to server. Please check your connection.');
      } else {
        setError(`Failed to load data: ${err.message}`);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleCancelAppointment = async (appointmentId) => {
    if (!cancelReason.trim()) {
      setError('Please provide a reason for cancellation');
      return;
    }
    
    try {
      await axios.patch(`/api/appointments/${appointmentId}/admin_cancel/`, {
        cancel_reason: cancelReason.trim()
      });
      setCancelDialog(false);
      setCancelReason('');
      setError(''); // Clear any previous errors
      // Open reschedule dialog instead of closing completely
      openRescheduleDialog(appointmentToCancel);
    } catch (err) {
      const message = err?.response?.data?.error || err?.message || 'Failed to cancel appointment';
      setError(message);
    }
  };

  const openCancelDialog = (appointment) => {
    setAppointmentToCancel(appointment);
    setCancelDialog(true);
  };

  const fetchAvailableTimeSlots = async (doctorId, date) => {
    if (!doctorId || !date) return;
    
    setLoadingSlots(true);
    try {
      const response = await axios.get(`/api/appointments/available_slots/?doctor_id=${doctorId}&appointment_date=${date}`);
      setAvailableTimeSlots(response.data.available_slots || []);
    } catch (err) {
      console.error('Error fetching available slots:', err);
      setError(`Failed to fetch available time slots: ${err.message}`);
      setAvailableTimeSlots([]);
    } finally {
      setLoadingSlots(false);
    }
  };

  const openRescheduleDialog = (appointment) => {
    setAppointmentToCancel(appointment);
    setNewAppointmentDate('');
    setNewAppointmentTime('');
    setAvailableTimeSlots([]);
    setRescheduleDialog(true);
  };

  const handleRescheduleAppointment = async () => {
    if (!newAppointmentDate || !newAppointmentTime) {
      setError('Please select both date and time for rescheduling');
      return;
    }
    
    try {
      await axios.post(`/api/appointments/${appointmentToCancel.id}/admin_reschedule/`, {
        new_appointment_date: newAppointmentDate,
        new_appointment_time: newAppointmentTime,
        cancel_reason: cancelReason
      });
      setRescheduleDialog(false);
      setNewAppointmentDate('');
      setNewAppointmentTime('');
      setCancelReason('');
      setAppointmentToCancel(null);
      setError(''); // Clear any previous errors
      setSuccess('Appointment rescheduled successfully! Patient has been notified via email.');
      loadData(); // Reload data
      
      // Clear success message after 5 seconds
      setTimeout(() => setSuccess(''), 5000);
    } catch (err) {
      const message = err?.response?.data?.error || err?.message || 'Failed to reschedule appointment';
      setError(message);
    }
  };

  const handleAcceptAppointment = async (appointmentId) => {
    try {
      await axios.patch(`/api/appointments/${appointmentId}/admin_accept/`, {});
      loadData(); // Reload data
    } catch (err) {
      const message = err?.response?.data?.error || err?.message || 'Failed to accept appointment';
      setError(message);
    }
  };

  const handleAddDoctor = async () => {
    try {
      await axios.post('/api/doctors/', newDoctor);
      setAddDoctorDialog(false);
      setNewDoctor({
        name: '',
        department: '',
        degree: '',
        experience: '',
        specialization: '',
        consultation_fee: '',
        bio: '',
      });
      loadData();
    } catch (err) {
      console.error('Error adding doctor:', err);
      setError('Failed to add doctor');
    }
  };

  const handleEditDoctor = async () => {
    try {
      await axios.patch(`/api/doctors/${editingDoctor.id}/`, editingDoctor);
      setEditDoctorDialog(false);
      setEditingDoctor(null);
      loadData();
    } catch (err) {
      console.error('Error updating doctor:', err);
      setError('Failed to update doctor');
    }
  };

  const openEditDialog = (doctor) => {
    setEditingDoctor({
      id: doctor.id,
      name: doctor.name,
      department: doctor.department,
      degree: doctor.degree,
      experience: doctor.experience,
      specialization: doctor.specialization,
      consultation_fee: doctor.consultation_fee,
      bio: doctor.bio || '',
    });
    setEditDoctorDialog(true);
  };

  const handleDeleteDoctor = async (doctorId) => {
    if (window.confirm('Are you sure you want to delete this doctor?')) {
      try {
        await axios.delete(`/api/doctors/${doctorId}/`);
        loadData(); // Reload data
      } catch (err) {
        setError('Failed to delete doctor');
      }
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'warning';
      case 'confirmed': return 'info';
      case 'completed': return 'success';
      case 'cancelled': return 'error';
      default: return 'default';
    }
  };

  if (loading) {
    return (
      <Container sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
        <CircularProgress />
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <AdminPanelSettings sx={{ fontSize: 40, color: 'primary.main' }} />
          <Typography variant="h4" component="h1">
            Admin Dashboard
          </Typography>
        </Box>
        <Button variant="outlined" color="error" onClick={handleLogout}>
          Logout
        </Button>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}
      
      {success && (
        <Alert severity="success" sx={{ mb: 2 }}>
          {success}
        </Alert>
      )}

      {/* Tabs */}
      <Paper sx={{ width: '100%', mb: 3 }}>
        <Tabs value={tabValue} onChange={handleTabChange}>
          <Tab icon={<Event />} label="Appointments" />
          <Tab icon={<LocalHospital />} label="Doctors" />
        </Tabs>
      </Paper>

      {/* Appointments Tab */}
      {tabValue === 0 && (
        <Paper>
          <Box sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              All Appointments
            </Typography>
            <TableContainer>
              <Table>
                                   <TableHead>
                     <TableRow>
                       <TableCell>Patient</TableCell>
                       <TableCell>Doctor</TableCell>
                       <TableCell>Date</TableCell>
                       <TableCell>Time</TableCell>
                       <TableCell>Status</TableCell>
                       <TableCell>Actions</TableCell>
                     </TableRow>
                   </TableHead>
                   <TableBody>
                     {appointments.map((appointment) => (
                       <TableRow key={appointment.id}>
                         <TableCell>{appointment.patient_name || 'N/A'}</TableCell>
                         <TableCell>Dr. {(appointment.doctor_name || 'N/A').replace(/^\s*Dr\.?\s*/i, '').trim()}</TableCell>
                         <TableCell>{appointment.appointment_date}</TableCell>
                         <TableCell>{appointment.appointment_time}</TableCell>
                         <TableCell>
                           <Chip 
                             label={appointment.status} 
                             color={getStatusColor(appointment.status)}
                             size="small"
                           />
                         </TableCell>
                         <TableCell>
                           {appointment.status === 'pending' && (
                             <Button
                               size="small"
                               color="success"
                               sx={{ mr: 1 }}
                               onClick={() => handleAcceptAppointment(appointment.id)}
                             >
                               Accept
                             </Button>
                           )}
                           {appointment.status !== 'cancelled' && appointment.status !== 'completed' && (
                             <Button
                               size="small"
                               color="error"
                               onClick={() => openCancelDialog(appointment)}
                             >
                               Cancel
                             </Button>
                           )}
                         </TableCell>
                       </TableRow>
                     ))}
                   </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Paper>
      )}

      {/* Doctors Tab */}
      {tabValue === 1 && (
        <Box>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="h6">
              Manage Doctors
            </Typography>
            <Button
              variant="contained"
              startIcon={<Add />}
              onClick={() => setAddDoctorDialog(true)}
            >
              Add Doctor
            </Button>
          </Box>

          <Grid container spacing={3}>
            {doctors.map((doctor) => (
              <Grid item xs={12} sm={6} md={4} key={doctor.id} sx={{ display: 'flex' }}>
                <Card sx={{ 
                  width: '300px',
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  borderRadius: 2,
                  transition: 'all 0.3s ease-in-out',
                  '&:hover': {
                    boxShadow: '0 8px 25px rgba(0, 0, 0, 0.1)',
                    transform: 'translateY(-2px)',
                  },
                }}>
                  <CardContent sx={{ 
                    flexGrow: 1, 
                    p: 3,
                    display: 'flex',
                    flexDirection: 'column',
                    height: '100%'
                  }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                      <Typography variant="h6" sx={{ fontWeight: 600 }}>
                        Dr. {doctor.name.replace(/^\s*Dr\.?\s*/i, '').trim()}
                      </Typography>
                      <Box sx={{ display: 'flex', gap: 1 }}>
                        <IconButton
                          color="primary"
                          size="small"
                          onClick={() => openEditDialog(doctor)}
                        >
                          <Edit />
                        </IconButton>
                        <IconButton
                          color="error"
                          size="small"
                          onClick={() => handleDeleteDoctor(doctor.id)}
                        >
                          <Delete />
                        </IconButton>
                      </Box>
                    </Box>
                    
                    <Chip 
                      label={doctor.department_display} 
                      size="small" 
                      sx={{ 
                        mb: 2,
                        alignSelf: 'flex-start',
                        backgroundColor: 'primary.light',
                        color: 'white',
                      }} 
                    />
                    
                    <Box sx={{ 
                      flexGrow: 1, 
                      mb: 2,
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'space-between'
                    }}>
                      <Box>
                        <Typography variant="body2" color="text.secondary" sx={{ 
                          mb: 1,
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          display: '-webkit-box',
                          WebkitLineClamp: 2,
                          WebkitBoxOrient: 'vertical',
                        }}>
                          {doctor.specialization}
                        </Typography>
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                          {doctor.experience} years experience
                        </Typography>
                      </Box>
                      
                      <Typography variant="body2" color="text.secondary" sx={{ 
                        fontWeight: 600, 
                        color: 'success.main',
                        mt: 'auto'
                      }}>
                        ₹{doctor.consultation_fee}
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Box>
      )}

      {/* Add Doctor Dialog */}
      <Dialog open={addDoctorDialog} onClose={() => setAddDoctorDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Add New Doctor</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Doctor Name"
                value={newDoctor.name}
                onChange={(e) => setNewDoctor({...newDoctor, name: e.target.value})}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth required>
                <InputLabel>Department</InputLabel>
                <Select
                  value={newDoctor.department}
                  label="Department"
                  onChange={(e) => setNewDoctor({...newDoctor, department: e.target.value})}
                >
                  <MenuItem value="dentist">Dentist</MenuItem>
                  <MenuItem value="orthopedic">Orthopedic</MenuItem>
                  <MenuItem value="general_physician">General Physician</MenuItem>
                  <MenuItem value="children_specialist">Children Specialist</MenuItem>
                  <MenuItem value="emergency">Emergency Doctor</MenuItem>
                  <MenuItem value="dermatologist">Dermatologist</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Degree"
                value={newDoctor.degree}
                onChange={(e) => setNewDoctor({...newDoctor, degree: e.target.value})}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Experience (years)"
                type="number"
                value={newDoctor.experience}
                onChange={(e) => setNewDoctor({...newDoctor, experience: e.target.value})}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Consultation Fee"
                type="number"
                value={newDoctor.consultation_fee}
                onChange={(e) => setNewDoctor({...newDoctor, consultation_fee: e.target.value})}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Specialization"
                value={newDoctor.specialization}
                onChange={(e) => setNewDoctor({...newDoctor, specialization: e.target.value})}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                multiline
                rows={3}
                label="Bio"
                value={newDoctor.bio}
                onChange={(e) => setNewDoctor({...newDoctor, bio: e.target.value})}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAddDoctorDialog(false)}>Cancel</Button>
          <Button onClick={handleAddDoctor} variant="contained">
            Add Doctor
          </Button>
        </DialogActions>
      </Dialog>

      {/* Edit Doctor Dialog */}
      <Dialog open={editDoctorDialog} onClose={() => setEditDoctorDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Edit Doctor Profile</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Doctor Name"
                value={editingDoctor?.name || ''}
                onChange={(e) => setEditingDoctor({...editingDoctor, name: e.target.value})}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth required>
                <InputLabel>Department</InputLabel>
                <Select
                  value={editingDoctor?.department || ''}
                  label="Department"
                  onChange={(e) => setEditingDoctor({...editingDoctor, department: e.target.value})}
                >
                  <MenuItem value="dentist">Dentist</MenuItem>
                  <MenuItem value="orthopedic">Orthopedic</MenuItem>
                  <MenuItem value="general_physician">General Physician</MenuItem>
                  <MenuItem value="children_specialist">Children Specialist</MenuItem>
                  <MenuItem value="emergency">Emergency Doctor</MenuItem>
                  <MenuItem value="dermatologist">Dermatologist</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Degree"
                value={editingDoctor?.degree || ''}
                onChange={(e) => setEditingDoctor({...editingDoctor, degree: e.target.value})}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Experience (years)"
                type="number"
                value={editingDoctor?.experience || ''}
                onChange={(e) => setEditingDoctor({...editingDoctor, experience: e.target.value})}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Consultation Fee"
                type="number"
                value={editingDoctor?.consultation_fee || ''}
                onChange={(e) => setEditingDoctor({...editingDoctor, consultation_fee: e.target.value})}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Specialization"
                value={editingDoctor?.specialization || ''}
                onChange={(e) => setEditingDoctor({...editingDoctor, specialization: e.target.value})}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                multiline
                rows={3}
                label="Bio"
                value={editingDoctor?.bio || ''}
                onChange={(e) => setEditingDoctor({...editingDoctor, bio: e.target.value})}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditDoctorDialog(false)}>Cancel</Button>
          <Button onClick={handleEditDoctor} variant="contained">
            Update Doctor
          </Button>
        </DialogActions>
      </Dialog>

      {/* Cancel Appointment Dialog */}
      <Dialog open={cancelDialog} onClose={() => {
        setCancelDialog(false);
        setCancelReason('');
        setAppointmentToCancel(null);
        setError('');
        setSuccess('');
      }} maxWidth="sm" fullWidth>
        <DialogTitle>Cancel Appointment</DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 2 }}>
            <Typography variant="body1" sx={{ mb: 2 }}>
              Are you sure you want to cancel the appointment for{' '}
              <strong>{appointmentToCancel?.patient_name}</strong> with{' '}
              <strong>Dr. {appointmentToCancel?.doctor_name}</strong> on{' '}
              <strong>{appointmentToCancel?.appointment_date}</strong> at{' '}
              <strong>{appointmentToCancel?.appointment_time}</strong>?
            </Typography>
            <TextField
              fullWidth
              multiline
              rows={3}
              label="Reason for cancellation"
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              placeholder="Please provide a reason for cancelling this appointment..."
              required
              helperText="This reason will be included in the email sent to the patient."
              error={!cancelReason.trim() && cancelReason !== ''}
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => {
            setCancelDialog(false);
            setCancelReason('');
            setAppointmentToCancel(null);
            setError('');
            setSuccess('');
          }}>
            Keep Appointment
          </Button>
          <Button 
            onClick={() => handleCancelAppointment(appointmentToCancel?.id)}
            variant="contained" 
            color="error"
            disabled={!cancelReason.trim()}
          >
            Cancel Appointment
          </Button>
        </DialogActions>
      </Dialog>

      {/* Reschedule Appointment Dialog */}
      <Dialog open={rescheduleDialog} onClose={() => {
        setRescheduleDialog(false);
        setNewAppointmentDate('');
        setNewAppointmentTime('');
        setCancelReason('');
        setAppointmentToCancel(null);
        setError('');
        setSuccess('');
      }} maxWidth="sm" fullWidth>
        <DialogTitle>Reschedule Appointment</DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 2 }}>
            <Typography variant="body1" sx={{ mb: 2 }}>
              Please select a new date and time for{' '}
              <strong>{appointmentToCancel?.patient_name}</strong> with{' '}
              <strong>Dr. {appointmentToCancel?.doctor_name}</strong>.
            </Typography>
            
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  type="date"
                  label="New Appointment Date"
                  value={newAppointmentDate}
                  onChange={(e) => {
                    setNewAppointmentDate(e.target.value);
                    if (e.target.value && appointmentToCancel?.doctor) {
                      fetchAvailableTimeSlots(appointmentToCancel.doctor, e.target.value);
                    }
                  }}
                  InputLabelProps={{ shrink: true }}
                  inputProps={{
                    min: new Date().toISOString().split('T')[0] // Prevent selecting past dates
                  }}
                  required
                />
              </Grid>
              
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  select
                  label="New Appointment Time"
                  value={newAppointmentTime}
                  onChange={(e) => setNewAppointmentTime(e.target.value)}
                  required
                  disabled={!newAppointmentDate || loadingSlots}
                  helperText={
                    loadingSlots 
                      ? 'Loading available slots...' 
                      : availableTimeSlots.length === 0 
                        ? 'No available slots for this date'
                        : `${availableTimeSlots.length} slots available`
                  }
                >
                  {availableTimeSlots.length === 0 && !loadingSlots ? (
                    <MenuItem disabled value="">
                      No available time slots
                    </MenuItem>
                  ) : (
                    availableTimeSlots.map((time) => (
                      <MenuItem key={time} value={time}>
                        {time}
                      </MenuItem>
                    ))
                  )}
                </TextField>
              </Grid>
            </Grid>
            
            <Box sx={{ mt: 2, p: 2, bgcolor: 'grey.50', borderRadius: 1 }}>
              <Typography variant="body2" color="text.secondary">
                <strong>Note:</strong> The patient will receive an email with the cancellation reason and the new appointment details.
              </Typography>
            </Box>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => {
            setRescheduleDialog(false);
            setNewAppointmentDate('');
            setNewAppointmentTime('');
            setCancelReason('');
            setAppointmentToCancel(null);
            setError('');
            setSuccess('');
          }}>
            Skip Rescheduling
          </Button>
          <Button 
            onClick={handleRescheduleAppointment}
            variant="contained" 
            color="primary"
            disabled={!newAppointmentDate || !newAppointmentTime}
          >
            Reschedule Appointment
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default AdminDashboard;
