import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Button,
  Box,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  CircularProgress,
  Alert,
  InputAdornment,
  Paper,
  Stack,
} from '@mui/material';
import {
  Search,
  FilterList,
  LocationOn,
  Work,
  School,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Doctors = () => {
  const publicBase = process.env.PUBLIC_URL || '';
  const doctorImages = [
    `${publicBase}/images/doc1.jpeg`,
    `${publicBase}/images/doc2.jpeg`,
    `${publicBase}/images/doc3.jpeg`,
    `${publicBase}/images/doc4.jpeg`,
    `${publicBase}/images/doc5.jpeg`,
    `${publicBase}/images/doc6.jpeg`,
    `${publicBase}/images/doc7.jpeg`,
    `${publicBase}/images/doc8.jpeg`,
    `${publicBase}/images/doc9.jpeg`,
  ];

  const getDoctorImage = (doctor) => {
    if (doctor.image) return doctor.image;
    const id = Number.isInteger(doctor.id) ? doctor.id : 1;
    const index = ((id - 1) % doctorImages.length + doctorImages.length) % doctorImages.length;
    return doctorImages[index];
  };

  const navigate = useNavigate();
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('');

  useEffect(() => {
    fetchDoctors();
  }, []);

  const fetchDoctors = async () => {
    try {
      const response = await axios.get('/api/doctors/');
      setDoctors(response.data);
    } catch (err) {
      setError('Failed to fetch doctors');
    } finally {
      setLoading(false);
    }
  };

  const filteredDoctors = doctors.filter(doctor => {
    const matchesSearch = doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doctor.specialization.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDepartment = !departmentFilter || doctor.department === departmentFilter;
    return matchesSearch && matchesDepartment;
  });

  const departments = [
    { value: 'general_physician', label: 'General Physician', icon: '🏥', color: '#3b82f6' },
    { value: 'dentist', label: 'Dentist', icon: '🦷', color: '#0ea5e9' },
    { value: 'orthopedic', label: 'Orthopedic', icon: '🦴', color: '#6366f1' },
    { value: 'children_specialist', label: 'Children Specialist', icon: '👶', color: '#f59e0b' },
    { value: 'emergency', label: 'Emergency Doctor', icon: '🚑', color: '#ef4444' },
    { value: 'dermatologist', label: 'Dermatologist', icon: '🔬', color: '#10b981' },
  ];

  if (loading) {
    return (
      <Box
        sx={{
          minHeight: '100vh',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          background: 'linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)',
        }}
      >
        <Box sx={{ textAlign: 'center' }}>
          <CircularProgress size={60} sx={{ color: 'primary.main', mb: 2 }} />
          <Typography variant="h6" color="text.secondary">
            Loading our expert doctors...
          </Typography>
        </Box>
      </Box>
    );
  }

  return (
    <Box sx={{ bgcolor: 'background.default', minHeight: '100vh' }}>
      {/* Hero Section */}
      <Box
        sx={{
          background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)',
          color: 'white',
          py: 6,
          mb: 4,
        }}
      >
        <Container maxWidth="lg">
          <Box sx={{ textAlign: 'center' }}>
            <Typography
              variant="h2"
              component="h1"
              sx={{
                fontWeight: 700,
                mb: 2,
                fontSize: { xs: '2.5rem', md: '3.5rem' },
              }}
            >
              Meet Our Expert Doctors
            </Typography>
            <Typography
              variant="h6"
              sx={{
                opacity: 0.9,
                maxWidth: 600,
                mx: 'auto',
                lineHeight: 1.6,
              }}
            >
              Highly qualified medical professionals dedicated to providing exceptional healthcare services
            </Typography>
          </Box>
        </Container>
      </Box>

      <Container maxWidth="lg" sx={{ mb: 6 }}>
        {error && (
          <Alert
            severity="error"
            sx={{
              mb: 4,
              borderRadius: 2,
              '& .MuiAlert-icon': {
                color: 'error.main',
              },
            }}
          >
            {error}
          </Alert>
        )}

        {/* Filters Section */}
        <Paper
          elevation={0}
          sx={{
            p: 3,
            mb: 4,
            borderRadius: 3,
            background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)',
            border: '1px solid rgba(226, 232, 240, 0.8)',
            boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
          }}
        >
          <Typography variant="h6" sx={{ mb: 3, color: 'primary.main', fontWeight: 600 }}>
            <FilterList sx={{ mr: 1, verticalAlign: 'middle' }} />
            Find Your Doctor
          </Typography>
          
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2}>
            <TextField
              label="Search doctors by name or specialization"
              variant="outlined"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search sx={{ color: 'primary.main' }} />
                  </InputAdornment>
                ),
              }}
              sx={{
                flexGrow: 1,
                '& .MuiOutlinedInput-root': {
                  borderRadius: 2,
                  '&:hover .MuiOutlinedInput-notchedOutline': {
                    borderColor: 'primary.light',
                  },
                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                    borderColor: 'primary.main',
                    borderWidth: 2,
                  },
                },
              }}
            />
            <FormControl sx={{ minWidth: 200 }}>
              <InputLabel>Department</InputLabel>
              <Select
                value={departmentFilter}
                label="Department"
                onChange={(e) => setDepartmentFilter(e.target.value)}
                sx={{
                  borderRadius: 2,
                  '&:hover .MuiOutlinedInput-notchedOutline': {
                    borderColor: 'primary.light',
                  },
                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                    borderColor: 'primary.main',
                    borderWidth: 2,
                  },
                }}
              >
                <MenuItem value="">All Departments</MenuItem>
                {departments.map((dept) => (
                  <MenuItem key={dept.value} value={dept.value}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <span style={{ fontSize: '1.2rem' }}>{dept.icon}</span>
                      {dept.label}
                    </Box>
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Stack>
        </Paper>

        {/* Results Count */}
        <Box sx={{ mb: 3 }}>
          <Typography variant="h6" color="text.secondary">
            Found {filteredDoctors.length} doctor{filteredDoctors.length !== 1 ? 's' : ''}
          </Typography>
        </Box>

        {/* Doctors Grid */}
        <Grid container spacing={3}>
          {filteredDoctors.map((doctor) => (
            <Grid item xs={12} sm={6} md={4} key={doctor.id} sx={{ display: 'flex' }}>
              <Card
                sx={{
                  width: '100%',
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  borderRadius: 3,
                  overflow: 'hidden',
                  background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)',
                  border: '1px solid rgba(226, 232, 240, 0.8)',
                  transition: 'all 0.3s ease-in-out',
                  '&:hover': {
                    transform: 'translateY(-8px)',
                    boxShadow: '0 25px 50px rgba(0, 0, 0, 0.15)',
                    borderColor: 'primary.light',
                  },
                }}
              >
                <Box sx={{ position: 'relative' }}>
                  <CardMedia
                    component="img"
                    height="220"
                    image={getDoctorImage(doctor)}
                    alt={doctor.name}
                    sx={{ objectFit: 'cover' }}
                  />
                </Box>
                
                <CardContent sx={{ 
                  flexGrow: 1, 
                  p: 3, 
                  display: 'flex', 
                  flexDirection: 'column',
                  height: '100%'
                }}>
                  <Typography gutterBottom variant="h5" component="h2" sx={{ fontWeight: 600, mb: 2 }}>
                    Dr. {doctor.name.replace(/^\s*Dr\.?\s*/i, '').trim()}
                  </Typography>
                  
                  <Chip
                    label={doctor.department_display}
                    size="small"
                    sx={{
                      mb: 2,
                      backgroundColor: 'primary.light',
                      color: 'white',
                      fontWeight: 600,
                    }}
                  />
                  
                  <Box sx={{ 
                    mb: 2, 
                    flexGrow: 1,
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-between'
                  }}>
                    <Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                        <School sx={{ fontSize: 18, color: 'primary.main', mr: 1 }} />
                        <Typography variant="body2" color="text.secondary">
                          {doctor.degree}
                        </Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                        <Work sx={{ fontSize: 18, color: 'primary.main', mr: 1 }} />
                        <Typography variant="body2" color="text.secondary">
                          {doctor.experience} years of experience
                        </Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                        <LocationOn sx={{ fontSize: 18, color: 'primary.main', mr: 1 }} />
                        <Typography variant="body2" color="text.secondary" sx={{
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          display: '-webkit-box',
                          WebkitLineClamp: 2,
                          WebkitBoxOrient: 'vertical',
                        }}>
                          {doctor.specialization}
                        </Typography>
                      </Box>
                    </Box>
                    
                    <Box sx={{ display: 'flex', alignItems: 'center', mt: 'auto' }}>
                      <Typography variant="h6" color="success.main" sx={{ fontWeight: 600 }}>
                        ₹{doctor.consultation_fee}
                      </Typography>
                    </Box>
                  </Box>
                  
                  <Button
                    variant="contained"
                    fullWidth
                    onClick={() => navigate(`/doctors/${doctor.id}`)}
                    sx={{
                      py: 1.5,
                      borderRadius: 2,
                      background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)',
                      '&:hover': {
                        background: 'linear-gradient(135deg, #1e40af 0%, #2563eb 100%)',
                        transform: 'translateY(-2px)',
                        boxShadow: '0 8px 25px rgba(30, 58, 138, 0.3)',
                      },
                      transition: 'all 0.3s ease-in-out',
                    }}
                  >
                    View Profile
                  </Button>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        {filteredDoctors.length === 0 && !loading && (
          <Paper
            elevation={0}
            sx={{
              p: 6,
              textAlign: 'center',
              borderRadius: 3,
              background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)',
              border: '1px solid rgba(226, 232, 240, 0.8)',
            }}
          >
            <Typography variant="h5" color="text.secondary" sx={{ mb: 2 }}>
              No doctors found matching your criteria
            </Typography>
            <Typography variant="body1" color="text.secondary">
              Try adjusting your search terms or department filter
            </Typography>
          </Paper>
        )}
      </Container>
    </Box>
  );
};

export default Doctors; 