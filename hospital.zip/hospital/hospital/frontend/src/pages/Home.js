import React from 'react';
import {
  Container,
  Typography,
  Button,
  Grid,
  Card,
  CardContent,
  Box,
  Paper,
  Chip,
  Stack,
} from '@mui/material';
import {
  LocalHospital,
  Schedule,
  Psychology,
  Person,
  ArrowForward,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
// Removed unused Carousel import

const Home = () => {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();

  const features = [
    {
      icon: <Person sx={{ fontSize: 48, color: '#ffffff' }} />,
      title: 'Expert Doctors',
      description: 'Access to qualified and experienced medical professionals across various specialties.',
      gradient: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)',
      stats: '500+ Specialists',
    },
    {
      icon: <Schedule sx={{ fontSize: 48, color: '#ffffff' }} />,
      title: 'Easy Appointments',
      description: 'Book appointments with your preferred doctors at your convenience.',
      gradient: 'linear-gradient(135deg, #0ea5e9 0%, #38bdf8 100%)',
      stats: '24/7 Booking',
    },
    {
      icon: <Psychology sx={{ fontSize: 48, color: '#ffffff' }} />,
      title: 'AI Symptom Checker',
      description: 'Get preliminary diagnosis and doctor recommendations based on your symptoms.',
      gradient: 'linear-gradient(135deg, #6366f1 0%, #818cf8 100%)',
      stats: '95% Accuracy',
    },
    {
      icon: <LocalHospital sx={{ fontSize: 48, color: '#ffffff' }} />,
      title: 'Comprehensive Care',
      description: 'From general physicians to specialists, we cover all your healthcare needs.',
      gradient: 'linear-gradient(135deg, #10b981 0%, #34d399 100%)',
      stats: '50+ Departments',
    },
  ];

  const departments = [
    { 
      name: 'General Physician', 
      description: 'Primary healthcare and general medical consultations',
      icon: '🏥',
      color: '#3b82f6'
    },
    { 
      name: 'Dentist', 
      description: 'Dental care, oral health, and dental procedures',
      icon: '🦷',
      color: '#0ea5e9'
    },
    { 
      name: 'Orthopedic', 
      description: 'Bone and joint care, fractures, and musculoskeletal issues',
      icon: '🦴',
      color: '#6366f1'
    },
    { 
      name: 'Children Specialist', 
      description: 'Pediatric care and child health services',
      icon: '👶',
      color: '#f59e0b'
    },
    { 
      name: 'Emergency Doctor', 
      description: '24/7 emergency medical care and critical care',
      icon: '🚑',
      color: '#ef4444'
    },
  ];

  const stats = [
    { number: '50,000+', label: 'Patients Served', icon: '👥' },
    { number: '500+', label: 'Expert Doctors', icon: '👨‍⚕️' },
    { number: '95%', label: 'Satisfaction Rate', icon: '⭐' },
    { number: '24/7', label: 'Emergency Care', icon: '🆘' },
  ];

  return (
    <Box sx={{ bgcolor: 'background.default' }}>
      {/* Hero Section */}
      <Paper
        sx={{
          position: 'relative',
          backgroundColor: 'grey.800',
          color: '#fff',
          mb: 6,
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat',
          backgroundPosition: 'center',
          backgroundImage: 'url(https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80)',
          minHeight: '70vh',
          display: 'flex',
          alignItems: 'center',
          borderRadius: 0,
        }}
      >
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            bottom: 0,
            right: 0,
            left: 0,
            background: 'linear-gradient(135deg, rgba(30, 58, 138, 0.8) 0%, rgba(59, 130, 246, 0.6) 100%)',
          }}
        />
        <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
          <Box sx={{ maxWidth: 800 }}>
            <Chip
              label="🏥 Trusted Healthcare Provider"
              sx={{
                backgroundColor: 'rgba(255, 255, 255, 0.2)',
                color: 'white',
                fontSize: '0.9rem',
                mb: 3,
                px: 2,
                py: 1,
              }}
            />
            <Typography 
              component="h1" 
              variant="h2" 
              color="inherit" 
              gutterBottom
              sx={{
                fontWeight: 800,
                fontSize: { xs: '2.5rem', md: '3.5rem' },
                lineHeight: 1.2,
                mb: 3,
              }}
            >
              Your Health, Our
              <Box component="span" sx={{ 
                background: 'linear-gradient(45deg, #ffffff 30%, #e0f2fe 90%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                display: 'block',
              }}>
                Priority
              </Box>
            </Typography>
            <Typography 
              variant="h5" 
              color="inherit" 
              paragraph
              sx={{
                opacity: 0.95,
                mb: 4,
                lineHeight: 1.6,
                maxWidth: 600,
              }}
            >
              Providing quality healthcare with advanced technology and compassionate care.
              Book appointments, check symptoms, and get expert medical advice.
            </Typography>
            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} sx={{ mb: 4 }}>
              {isAuthenticated ? (
                <Button
                  variant="contained"
                  size="large"
                  onClick={() => navigate('/doctors')}
                  endIcon={<ArrowForward />}
                  sx={{
                    py: 2,
                    px: 4,
                    fontSize: '1.1rem',
                    fontWeight: 600,
                    borderRadius: 3,
                    background: 'linear-gradient(135deg, #ffffff 0%, #f1f5f9 100%)',
                    color: '#1e3a8a',
                    '&:hover': {
                      background: 'linear-gradient(135deg, #ffffff 0%, #e2e8f0 100%)',
                      transform: 'translateY(-2px)',
                      boxShadow: '0 20px 40px rgba(0, 0, 0, 0.15)',
                    },
                    transition: 'all 0.3s ease-in-out',
                  }}
                >
                  Book Appointment
                </Button>
              ) : (
                <Button
                  variant="contained"
                  size="large"
                  onClick={() => navigate('/register')}
                  endIcon={<ArrowForward />}
                  sx={{
                    py: 2,
                    px: 4,
                    fontSize: '1.1rem',
                    fontWeight: 600,
                    borderRadius: 3,
                    background: 'linear-gradient(135deg, #ffffff 0%, #f1f5f9 100%)',
                    color: '#1e3a8a',
                    '&:hover': {
                      background: 'linear-gradient(135deg, #ffffff 0%, #e2e8f0 100%)',
                      transform: 'translateY(-2px)',
                      boxShadow: '0 20px 40px rgba(0, 0, 0, 0.15)',
                    },
                    transition: 'all 0.3s ease-in-out',
                  }}
                >
                  Get Started
                </Button>
              )}
              <Button
                variant="outlined"
                size="large"
                onClick={() => navigate('/doctors')}
                sx={{
                  py: 2,
                  px: 4,
                  fontSize: '1.1rem',
                  fontWeight: 600,
                  borderRadius: 3,
                  color: 'white',
                  borderColor: 'rgba(255, 255, 255, 0.5)',
                  borderWidth: 2,
                  '&:hover': {
                    backgroundColor: 'rgba(255, 255, 255, 0.1)',
                    borderColor: 'white',
                    transform: 'translateY(-2px)',
                  },
                  transition: 'all 0.3s ease-in-out',
                }}
              >
                View Doctors
              </Button>
            </Stack>
          </Box>
        </Container>
      </Paper>

      {/* Stats Section */}
      <Container maxWidth="lg" sx={{ mb: 8 }}>
        <Grid container spacing={4}>
          {stats.map((stat, index) => (
            <Grid item xs={6} md={3} key={index}>
              <Card
                sx={{
                  textAlign: 'center',
                  py: 3,
                  px: 2,
                  borderRadius: 4,
                  background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)',
                  border: '1px solid rgba(226, 232, 240, 0.8)',
                  '&:hover': {
                    transform: 'translateY(-4px)',
                    boxShadow: '0 20px 40px rgba(0, 0, 0, 0.1)',
                  },
                  transition: 'all 0.3s ease-in-out',
                }}
              >
                <Typography variant="h2" sx={{ fontSize: '2.5rem', mb: 1 }}>
                  {stat.icon}
                </Typography>
                <Typography variant="h4" sx={{ fontWeight: 700, color: '#1e3a8a', mb: 1 }}>
                  {stat.number}
                </Typography>
                <Typography variant="body2" sx={{ color: '#64748b', fontWeight: 500 }}>
                  {stat.label}
                </Typography>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* Features Section */}
      <Container maxWidth="lg" sx={{ py: 8 }}>
        <Box sx={{ textAlign: 'center', mb: 6 }}>
          <Chip
            label="✨ Our Services"
            sx={{
              backgroundColor: 'rgba(59, 130, 246, 0.1)',
              color: '#1e3a8a',
              fontSize: '0.9rem',
              mb: 2,
              px: 2,
              py: 1,
            }}
          />
          <Typography variant="h3" component="h2" gutterBottom sx={{ fontWeight: 700 }}>
            Comprehensive Healthcare Solutions
          </Typography>
          <Typography variant="h6" color="text.secondary" paragraph sx={{ maxWidth: 600, mx: 'auto' }}>
            Tailored healthcare services designed to meet your individual needs with cutting-edge technology
          </Typography>
        </Box>

        <Grid container spacing={4}>
          {features.map((feature, index) => (
            <Grid item xs={12} sm={6} md={3} key={index}>
              <Card
                sx={{
                  height: 320,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  textAlign: 'center',
                  borderRadius: 4,
                  background: feature.gradient,
                  color: '#fff',
                  position: 'relative',
                  overflow: 'hidden',
                  '&:hover': {
                    transform: 'translateY(-8px) scale(1.02)',
                    boxShadow: '0 25px 50px rgba(0, 0, 0, 0.2)',
                  },
                  transition: 'all 0.3s ease-in-out',
                  '&::before': {
                    content: '""',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    background: 'rgba(255, 255, 255, 0.1)',
                    opacity: 0,
                    transition: 'opacity 0.3s ease-in-out',
                  },
                  '&:hover::before': {
                    opacity: 1,
                  },
                }}
              >
                <CardContent sx={{ position: 'relative', zIndex: 1 }}>
                  <Box
                    sx={{
                      background: 'rgba(255, 255, 255, 0.2)',
                      borderRadius: '50%',
                      width: 80,
                      height: 80,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      mb: 3,
                      mx: 'auto',
                    }}
                  >
                    {feature.icon}
                  </Box>
                  <Typography gutterBottom variant="h5" sx={{ fontWeight: 700, mb: 2 }}>
                    {feature.title}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.95, mb: 2, lineHeight: 1.6 }}>
                    {feature.description}
                  </Typography>
                  <Chip
                    label={feature.stats}
                    sx={{
                      backgroundColor: 'rgba(255, 255, 255, 0.2)',
                      color: 'white',
                      fontWeight: 600,
                    }}
                  />
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* Departments Section */}
      <Box sx={{ bgcolor: 'background.light', py: 8 }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: 'center', mb: 6 }}>
            <Chip
              label="🏥 Departments"
              sx={{
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                color: '#1e3a8a',
                fontSize: '0.9rem',
                mb: 2,
                px: 2,
                py: 1,
              }}
            />
            <Typography variant="h3" component="h2" gutterBottom sx={{ fontWeight: 700 }}>
              Specialized Medical Departments
            </Typography>
            <Typography variant="h6" color="text.secondary" paragraph sx={{ maxWidth: 600, mx: 'auto' }}>
              Expert care across multiple medical specialties with state-of-the-art facilities
            </Typography>
          </Box>

                                           <Grid container spacing={3} sx={{ justifyContent: 'center' }}>
              {departments.map((dept, index) => (
                <Grid item xs={12} sm={6} md={4} key={index} sx={{ 
                  width: { md: 'calc(33.333% - 16px)', lg: 'calc(33.333% - 16px)' },
                  flexBasis: { md: 'calc(33.333% - 16px)', lg: 'calc(33.333% - 16px)' },
                  maxWidth: { md: 'calc(33.333% - 16px)', lg: 'calc(33.333% - 16px)' },
                  // Center the last two items (index 3 and 4) in the second row
                  ...(index >= 3 && {
                    width: { md: 'calc(33.333% - 16px)', lg: 'calc(33.333% - 16px)' },
                    flexBasis: { md: 'calc(33.333% - 16px)', lg: 'calc(33.333% - 16px)' },
                    maxWidth: { md: 'calc(33.333% - 16px)', lg: 'calc(33.333% - 16px)' }
                  })
                }}>
                <Card
                  sx={{
                    p: 3,
                    borderRadius: 3,
                    background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)',
                    border: '1px solid rgba(226, 232, 240, 0.8)',
                    '&:hover': {
                      transform: 'translateY(-4px)',
                      boxShadow: '0 20px 40px rgba(0, 0, 0, 0.1)',
                      borderColor: dept.color,
                    },
                    transition: 'all 0.3s ease-in-out',
                  }}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <Typography variant="h2" sx={{ fontSize: '2rem', mr: 2 }}>
                      {dept.icon}
                    </Typography>
                    <Typography variant="h6" component="h3" sx={{ fontWeight: 600, color: dept.color }}>
                      {dept.name}
                    </Typography>
                  </Box>
                  <Typography variant="body2" color="text.secondary" sx={{ lineHeight: 1.6 }}>
                    {dept.description}
                  </Typography>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* CTA Section */}
      {!isAuthenticated && (
      <Container maxWidth="lg" sx={{ py: 8 }}>
        <Card
          sx={{
            background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)',
            color: 'white',
            textAlign: 'center',
            py: 6,
            px: 4,
            borderRadius: 4,
            position: 'relative',
            overflow: 'hidden',
            '&::before': {
              content: '""',
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              background: 'url("data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%23ffffff" fill-opacity="0.05"%3E%3Ccircle cx="30" cy="30" r="2"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")',
            },
          }}
        >
          <Box sx={{ position: 'relative', zIndex: 1 }}>
            <Typography variant="h3" component="h2" gutterBottom sx={{ fontWeight: 700, mb: 2 }}>
              Ready to Get Started?
            </Typography>
            <Typography variant="h6" sx={{ opacity: 0.9, mb: 4, maxWidth: 600, mx: 'auto' }}>
              Join thousands of patients who trust us with their healthcare needs. 
              Book your first appointment today and experience the difference.
            </Typography>
            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} justifyContent="center">
              <Button
                variant="contained"
                size="large"
                onClick={() => navigate('/register')}
                endIcon={<ArrowForward />}
                sx={{
                  py: 2,
                  px: 4,
                  fontSize: '1.1rem',
                  fontWeight: 600,
                  borderRadius: 3,
                  background: 'rgba(255, 255, 255, 0.9)',
                  color: '#1e3a8a',
                  '&:hover': {
                    background: 'rgba(255, 255, 255, 1)',
                    transform: 'translateY(-2px)',
                    boxShadow: '0 20px 40px rgba(0, 0, 0, 0.2)',
                  },
                  transition: 'all 0.3s ease-in-out',
                }}
              >
                Get Started Now
              </Button>
              <Button
                variant="outlined"
                size="large"
                onClick={() => navigate('/doctors')}
                sx={{
                  py: 2,
                  px: 4,
                  fontSize: '1.1rem',
                  fontWeight: 600,
                  borderRadius: 3,
                  color: 'white',
                  borderColor: 'rgba(255, 255, 255, 0.5)',
                  borderWidth: 2,
                  '&:hover': {
                    backgroundColor: 'rgba(255, 255, 255, 0.1)',
                    borderColor: 'white',
                    transform: 'translateY(-2px)',
                  },
                  transition: 'all 0.3s ease-in-out',
                }}
              >
                View Doctors
              </Button>
            </Stack>
          </Box>
        </Card>
      </Container>
      )}
    </Box>
  );
};

export default Home;