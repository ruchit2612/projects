import pickle
import os
import numpy as np
import pandas as pd
from django.conf import settings
from doctors.models import Doctor

class SymptomPredictionService:
    def __init__(self):
        self.illness_model = None
        self.doctor_model = None
        self.scaler = None
        self.feature_columns = None
        self.illness_encoder = None
        self.doctor_encoder = None
        self.gender_encoder = None
        self.all_symptoms = None
        self.feature_selector = None
        self.load_models()
        
        # Illness to doctor specialty mapping for fallback
        self.illness_to_specialty = {
            'Cold': 'children_specialist',
            'Chickenpox': 'children_specialist',
            'Measles': 'children_specialist',
            'Fever in kids': 'children_specialist',
            'Tooth Decay': 'dentist',
            'Gum Infection': 'dentist',
            'Tooth Infection': 'dentist',
            'Dental Abscess': 'dentist',
            'Stroke': 'emergency',
            'Seizure': 'emergency',
            'Heart Attack': 'emergency',
            'Arthritis': 'orthopedic',
            'Fracture': 'orthopedic',
            'Joint Pain': 'orthopedic',
            'Psoriasis': 'dermatologist',
            'Eczema': 'dermatologist',
            'Acne': 'dermatologist',
            'Skin Infection': 'dermatologist',
            'Flu': 'general_physician',
            'Diabetes': 'general_physician',
            'Hypertension': 'general_physician',
            'Pneumonia': 'general_physician',
            'Common Cold': 'general_physician',
            'Gastroenteritis (Child)': 'children_specialist',
            'Ear Infection (Child)': 'children_specialist',
            'Strep Throat (Child)': 'children_specialist',
        }
    
    def load_models(self):
        """Load the trained ML models from pickle files"""
        try:
            base_path = os.path.join(settings.BASE_DIR, 'ml_model')
            
            # Load the trained models
            with open(os.path.join(base_path, 'illness_model.pkl'), 'rb') as f:
                self.illness_model = pickle.load(f)
            
            with open(os.path.join(base_path, 'doctor_model.pkl'), 'rb') as f:
                self.doctor_model = pickle.load(f)
            
            # Load scaler
            with open(os.path.join(base_path, 'scaler.pkl'), 'rb') as f:
                self.scaler = pickle.load(f)
            
            # Load feature columns
            with open(os.path.join(base_path, 'feature_columns.pkl'), 'rb') as f:
                self.feature_columns = pickle.load(f)
            
            # Load encoders
            with open(os.path.join(base_path, 'illness_encoder.pkl'), 'rb') as f:
                self.illness_encoder = pickle.load(f)
            
            with open(os.path.join(base_path, 'doctor_encoder.pkl'), 'rb') as f:
                self.doctor_encoder = pickle.load(f)
            
            with open(os.path.join(base_path, 'gender_encoder.pkl'), 'rb') as f:
                self.gender_encoder = pickle.load(f)
            
            # Load selected symptoms
            with open(os.path.join(base_path, 'all_symptoms.pkl'), 'rb') as f:
                self.all_symptoms = pickle.load(f)
            
            # Load feature selector
            with open(os.path.join(base_path, 'feature_selector.pkl'), 'rb') as f:
                self.feature_selector = pickle.load(f)
                
        except Exception as e:
            print(f"Error loading models: {e}")
            # Fallback to dummy model for development
            self.illness_model = None
            self.doctor_model = None
    
    def predict_illness_and_doctor(self, symptoms, age, gender):
        """Predict both illness and doctor type based on symptoms, age, and gender"""
        if self.illness_model is None or self.doctor_model is None:
            # Fallback prediction for development
            return self._fallback_prediction(symptoms, age, gender)
        
        try:
            # Preprocess input data
            input_data = self._preprocess_input(symptoms, age, gender)
            
            # Apply feature selection
            if self.feature_selector:
                input_data = self.feature_selector.transform(input_data)
            
            # Make predictions
            illness_prediction = self.illness_model.predict(input_data)
            doctor_prediction = self.doctor_model.predict(input_data)
            
            # Get confidence scores
            illness_confidence = self.illness_model.predict_proba(input_data).max()
            doctor_confidence = self.doctor_model.predict_proba(input_data).max()
            
            # Decode predictions
            predicted_illness = self.illness_encoder.inverse_transform(illness_prediction)[0]
            predicted_doctor = self.doctor_encoder.inverse_transform(doctor_prediction)[0]
            
            return {
                'illness': predicted_illness,
                'doctor_type': predicted_doctor,
                'illness_confidence': float(illness_confidence),
                'doctor_confidence': float(doctor_confidence)
            }
            
        except Exception as e:
            print(f"Error in prediction: {e}")
            return self._fallback_prediction(symptoms, age, gender)
    
    def predict_illness(self, symptoms, age, gender):
        """Predict illness based on symptoms, age, and gender"""
        result = self.predict_illness_and_doctor(symptoms, age, gender)
        return result['illness'], result['illness_confidence']
    
    def predict_doctor_type(self, symptoms, age, gender):
        """Predict doctor type based on symptoms, age, and gender"""
        result = self.predict_illness_and_doctor(symptoms, age, gender)
        return result['doctor_type'], result['doctor_confidence']
    
    def _preprocess_input(self, symptoms, age, gender):
        """Preprocess input data for the model"""
        # Create symptom feature vector using original symptoms list
        original_symptoms = self.feature_columns.get('original_symptoms', self.all_symptoms)
        symptom_features = [0] * len(original_symptoms)
        
        # Convert symptoms to lowercase for matching
        symptoms_lower = symptoms.lower()
        
        # Check each symptom against the input
        for i, symptom in enumerate(original_symptoms):
            if symptom.lower() in symptoms_lower:
                symptom_features[i] = 1
        
        # Encode gender - convert M/F to Male/Female for the encoder
        gender_mapping = {'M': 'Male', 'F': 'Female', 'O': 'Male', 'male': 'Male', 'female': 'Female'}  # Default 'O' to 'Male'
        gender_for_encoding = gender_mapping.get(gender, 'Male')
        gender_encoded = self.gender_encoder.transform([gender_for_encoding])[0]
        
        # Create feature vector
        features = symptom_features + [age, gender_encoded]
        
        # Convert to numpy array and reshape
        features_array = np.array(features).reshape(1, -1)
        
        # Scale features
        features_scaled = self.scaler.transform(features_array)
        
        return features_scaled
    
    def _fallback_prediction(self, symptoms, age, gender):
        """Fallback prediction when model is not available"""
        symptoms_lower = symptoms.lower()
        # Simple rule-based prediction
        if any(word in symptoms_lower for word in ['tooth', 'dental', 'gum', 'cavity', 'decay', 'infection']):
            illness = 'Tooth Decay'
            doctor = 'Dentist'
        elif any(word in symptoms_lower for word in ['bone', 'fracture', 'sprain', 'joint', 'arthritis', 'stiffness']):
            illness = 'Fracture'
            doctor = 'Orthopedic'
        elif any(word in symptoms_lower for word in ['chest', 'heart', 'short breath', 'attack']):
            illness = 'Heart Attack'
            doctor = 'Emergency Doctor'
        elif any(word in symptoms_lower for word in ['seizure', 'confusion', 'shaking', 'unconscious', 'stroke', 'fainting', 'paralysis']):
            illness = 'Stroke'
            doctor = 'Emergency Doctor'
        elif age < 18 and any(word in symptoms_lower for word in ['fever', 'cold', 'rash', 'vomiting', 'measles', 'chickenpox']):
            illness = 'Fever in kids'
            doctor = 'Children Specialist'
        elif any(word in symptoms_lower for word in ['fever', 'chills', 'body ache', 'flu', 'diabetes', 'hypertension']):
            illness = 'Flu'
            doctor = 'General Physician'
        elif any(word in symptoms_lower for word in ['cold', 'cough', 'runny nose', 'sneezing']):
            illness = 'Common Cold'
            doctor = 'General Physician'
        elif any(word in symptoms_lower for word in ['rash', 'acne', 'eczema', 'psoriasis', 'itching', 'skin', 'infection']):
            illness = 'Skin Infection'
            doctor = 'Dermatologist'
        else:
            illness = 'Flu'
            doctor = 'General Physician'
        return {
            'illness': illness,
            'doctor_type': doctor,
            'illness_confidence': 0.7,
            'doctor_confidence': 0.7
        }
    
    def recommend_doctor(self, predicted_doctor_type):
        """Recommend doctor based on predicted doctor type"""
        # Map doctor types to department names
        doctor_type_to_department = {
            'General Physician': 'general_physician',
            'Children Specialist': 'children_specialist',
            'Pediatric': 'children_specialist',
            'Dentist': 'dentist',
            'Orthopedic': 'orthopedic',
            'Emergency Doctor': 'emergency',
            'Dermatologist': 'dermatologist',
        }
        
        department = doctor_type_to_department.get(predicted_doctor_type, 'general_physician')
        
        # Find available doctors in the recommended specialty
        recommended_doctors = Doctor.objects.filter(
            department=department,
            available=True
        ).order_by('-experience')
        
        return recommended_doctors.first() if recommended_doctors.exists() else None
    
    def recommend_all_doctors(self, predicted_doctor_type):
        """Recommend all doctors based on predicted doctor type"""
        # Map doctor types to department names
        doctor_type_to_department = {
            'General Physician': 'general_physician',
            'Children Specialist': 'children_specialist',
            'Pediatric': 'children_specialist',
            'Dentist': 'dentist',
            'Orthopedic': 'orthopedic',
            'Emergency Doctor': 'emergency',
            'Dermatologist': 'dermatologist',
        }
        
        department = doctor_type_to_department.get(predicted_doctor_type, 'general_physician')
        
        # Find all available doctors in the recommended specialty
        recommended_doctors = Doctor.objects.filter(
            department=department,
            available=True
        ).order_by('-experience')
        
        return recommended_doctors
    
    def get_available_symptoms(self):
        """Get list of all available symptoms for the frontend"""
        return self.all_symptoms if self.all_symptoms else []
    
    def get_illness_classes(self):
        """Get list of all illness classes"""
        return self.illness_encoder.classes_.tolist() if self.illness_encoder else []
    
    def get_doctor_classes(self):
        """Get list of all doctor classes"""
        return self.doctor_encoder.classes_.tolist() if self.doctor_encoder else [] 