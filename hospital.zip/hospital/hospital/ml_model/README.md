# ML Model for Hospital Management System

This directory contains the machine learning models for predicting illnesses and doctor types based on patient symptoms, age, and gender.

## Overview

The ML system consists of two main models:
1. **Illness Prediction Model**: Predicts the most likely illness based on symptoms
2. **Doctor Type Prediction Model**: Predicts the most suitable doctor type for the condition

## Dataset

The models are trained on the `illness_doctor_dataset_10000_expanded.csv` dataset which contains:
- **10,000 records** with patient information
- **Features**: Gender, Age, Illness, DoctorType, Symptom1, Symptom2, Symptom3
- **11 Illness Types**: Bone Pain, Cavity, Cold, Diarrhea, Fever, Flu, Fracture, Heart Attack, High Fever, Seizure, Toothache
- **5 Doctor Types**: Children Specialist, Dentist, Emergency Doctor, General Physician, Orthopedic

## Model Performance

Both models achieve **100% accuracy** on the test set:
- **Illness Prediction Accuracy**: 100%
- **Doctor Type Prediction Accuracy**: 100%

## Files

### Core Files
- `train_model.py` - Script to train the ML models
- `services.py` - Service class for making predictions
- `test_model.py` - Test script to verify model functionality

### Trained Models (Pickle Files)
- `illness_model.pkl` - Trained illness prediction model
- `doctor_model.pkl` - Trained doctor type prediction model
- `scaler.pkl` - Feature scaler for normalization
- `feature_columns.pkl` - Feature column names
- `illness_encoder.pkl` - Label encoder for illness classes
- `doctor_encoder.pkl` - Label encoder for doctor types
- `gender_encoder.pkl` - Label encoder for gender
- `all_symptoms.pkl` - List of all available symptoms

### Dataset
- `illness_doctor_dataset_10000_expanded.csv` - Training dataset

## Usage

### Training the Models

```bash
cd ml_model
python train_model.py
```

This will:
1. Load and preprocess the dataset
2. Train both illness and doctor type prediction models
3. Save all models and encoders as pickle files
4. Display performance metrics

### Using the Prediction Service

```python
from ml_model.services import SymptomPredictionService

# Initialize the service
service = SymptomPredictionService()

# Make a prediction
result = service.predict_illness_and_doctor(
    symptoms="fever, chills, body ache",
    age=35,
    gender="F"
)

print(f"Predicted Illness: {result['illness']}")
print(f"Illness Confidence: {result['illness_confidence']}")
print(f"Predicted Doctor Type: {result['doctor_type']}")
print(f"Doctor Confidence: {result['doctor_confidence']}")
```

### API Endpoints

The system provides several API endpoints:

1. **Get Available Symptoms**
   ```
   GET /api/predictions/available_symptoms/
   ```

2. **Get Illness Classes**
   ```
   GET /api/predictions/illness_classes/
   ```

3. **Get Doctor Classes**
   ```
   GET /api/predictions/doctor_classes/
   ```

4. **Make Prediction**
   ```
   POST /api/predictions/predict/
   {
     "symptoms": "fever, headache",
     "age": 25,
     "gender": "M"
   }
   ```

5. **Save Prediction to Database**
   ```
   POST /api/predictions/
   {
     "symptoms": "fever, headache",
     "age": 25,
     "gender": "M"
   }
   ```

## Model Architecture

### Features
- **Symptom Features**: 29 binary features (one for each unique symptom)
- **Demographic Features**: Age (numeric), Gender (encoded)

### Algorithm
- **Model Type**: Random Forest Classifier
- **Number of Trees**: 100
- **Random State**: 42 (for reproducibility)

### Preprocessing
1. **Symptom Encoding**: Convert symptoms to binary features
2. **Label Encoding**: Encode categorical variables (gender, illness, doctor type)
3. **Feature Scaling**: StandardScaler for age and encoded features

## Available Symptoms

The model recognizes 29 different symptoms:
- cold, cough, bleeding gums, bone ache, bone fracture
- body ache, loose motion, short breath, sweating, chills
- confusion, shaking, unconscious, rash, high fever
- vomiting, runny nose, stomach ache, dehydration
- tooth pain, teeth sensitivity, bad breath, swelling
- immobility, joint pain, chest pain, headache, flu

## Illness Types

The model can predict 11 different illnesses:
1. **Bone Pain** → Orthopedic
2. **Cavity** → Dentist
3. **Cold** → Children Specialist
4. **Diarrhea** → General Physician
5. **Fever** → General Physician
6. **Flu** → General Physician
7. **Fracture** → Orthopedic
8. **Heart Attack** → Emergency Doctor
9. **High Fever** → Children Specialist
10. **Seizure** → Emergency Doctor
11. **Toothache** → Dentist

## Doctor Types

The model recommends 5 different doctor types:
1. **Children Specialist** - For pediatric conditions
2. **Dentist** - For dental and oral health issues
3. **Emergency Doctor** - For urgent and life-threatening conditions
4. **General Physician** - For general medical conditions
5. **Orthopedic** - For bone and joint issues

## Testing

Run the test script to verify model functionality:

```bash
cd ml_model
python test_model.py
```

This will test various symptom combinations and verify predictions match expected outcomes.

## Integration with Frontend

The frontend SymptomChecker component (`frontend/src/pages/SymptomChecker.js`) integrates with the ML system to provide:

1. **Autocomplete Symptoms**: Users can select from available symptoms
2. **Real-time Predictions**: Instant illness and doctor type predictions
3. **Confidence Scores**: Display confidence levels for both predictions
4. **Doctor Recommendations**: Show available doctors in the recommended specialty
5. **Appointment Booking**: Direct link to book appointments with recommended doctors

## Error Handling

The system includes robust error handling:
- **Model Loading Errors**: Falls back to rule-based predictions
- **Invalid Input**: Validates required fields (symptoms, age, gender)
- **Missing Doctors**: Handles cases where no doctors are available in a specialty

## Future Improvements

Potential enhancements for the ML system:
1. **More Training Data**: Expand dataset with more diverse cases
2. **Additional Features**: Include medical history, allergies, etc.
3. **Model Retraining**: Periodic retraining with new data
4. **Ensemble Methods**: Combine multiple algorithms for better accuracy
5. **Real-time Learning**: Learn from user feedback and corrections

## Dependencies

Required Python packages:
- scikit-learn >= 1.3.0
- pandas >= 2.0.0
- numpy >= 1.26.0
- Django >= 5.1.7

## License

This ML system is part of the Hospital Management System and follows the same licensing terms. 