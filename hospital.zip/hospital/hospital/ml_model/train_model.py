import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, VotingClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.feature_selection import SelectKBest, f_classif
import pickle
import os
import warnings
warnings.filterwarnings('ignore')

def train_models():
    """Train the illness and doctor prediction models with high accuracy"""
    print("=== Training ML Models with High Accuracy ===\n")
    
    # Load the dataset
    dataset_path = 'illness_doctor_dataset_2000_clean.csv'
    if not os.path.exists(dataset_path):
        print(f"❌ Dataset not found: {dataset_path}")
        print("Please ensure the dataset file is in the ml_model directory")
        return
    
    print("📊 Loading dataset...")
    df = pd.read_csv(dataset_path)
    print(f"Dataset shape: {df.shape}")
    print(f"Columns: {list(df.columns)}")
    
    # Data preprocessing
    print("\n🔧 Preprocessing data...")
    
    # Handle missing values
    df = df.dropna(subset=['Illness', 'DoctorType', 'Age', 'Gender'])
    
    # Combine symptoms into a single string
    df['symptoms'] = df.apply(lambda row: ', '.join(filter(None, [
        str(row['Symptom1']).strip() if pd.notna(row['Symptom1']) else '',
        str(row['Symptom2']).strip() if pd.notna(row['Symptom2']) else '',
        str(row['Symptom3']).strip() if pd.notna(row['Symptom3']) else ''
    ])), axis=1)
    
    # Clean up symptoms
    df['symptoms'] = df['symptoms'].str.replace(',,', ',').str.strip(',').str.strip()
    
    # Remove rows with no symptoms
    df = df[df['symptoms'] != '']
    
    print(f"Cleaned dataset shape: {df.shape}")
    
    # Extract all unique symptoms
    all_symptoms = []
    for symptoms_str in df['symptoms']:
        if isinstance(symptoms_str, str):
            symptoms = [s.strip().lower() for s in symptoms_str.split(',') if s.strip()]
            all_symptoms.extend(symptoms)
    
    unique_symptoms = sorted(list(set(all_symptoms)))
    print(f"Found {len(unique_symptoms)} unique symptoms")
    
    # Create symptom features
    symptom_features = []
    for symptoms_str in df['symptoms']:
        if isinstance(symptoms_str, str):
            symptoms = [s.strip().lower() for s in symptoms_str.split(',') if s.strip()]
            feature_vector = [1 if symptom in symptoms else 0 for symptom in unique_symptoms]
        else:
            feature_vector = [0] * len(unique_symptoms)
        symptom_features.append(feature_vector)
    
    # Create feature matrix
    X_symptoms = np.array(symptom_features)
    X_age = df['Age'].values.reshape(-1, 1)
    X_gender = df['Gender'].values.reshape(-1, 1)
    
    # Encode categorical variables
    gender_encoder = LabelEncoder()
    X_gender_encoded = gender_encoder.fit_transform(X_gender.ravel()).reshape(-1, 1)
    
    # Combine features
    X = np.hstack([X_symptoms, X_age, X_gender_encoded])
    
    # Prepare target variables
    illness_encoder = LabelEncoder()
    doctor_encoder = LabelEncoder()
    
    y_illness = illness_encoder.fit_transform(df['Illness'])
    y_doctor = doctor_encoder.fit_transform(df['DoctorType'])
    
    print(f"Unique illnesses: {len(illness_encoder.classes_)}")
    print(f"Unique doctor types: {len(doctor_encoder.classes_)}")
    
    # Feature selection for better performance
    print("\n🔍 Performing feature selection...")
    selector = SelectKBest(score_func=f_classif, k=min(50, X.shape[1]))
    X_selected = selector.fit_transform(X, y_illness)
    
    # Get selected feature indices
    selected_features = selector.get_support()
    selected_symptom_indices = [i for i, selected in enumerate(selected_features[:len(unique_symptoms)]) if selected]
    selected_symptoms = [unique_symptoms[i] for i in selected_symptom_indices]
    
    print(f"Selected {len(selected_symptoms)} most important symptoms")
    
    # Split the data
    X_train, X_test, y_illness_train, y_illness_test, y_doctor_train, y_doctor_test = train_test_split(
        X_selected, y_illness, y_doctor, test_size=0.2, random_state=42, stratify=y_illness
    )
    
    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    print(f"Training set size: {X_train.shape[0]}")
    print(f"Test set size: {X_test.shape[0]}")
    
    # Hyperparameter tuning for illness model
    print("\n🏥 Training illness prediction model with hyperparameter tuning...")
    
    # Grid search for Random Forest
    rf_param_grid = {
        'n_estimators': [100, 200, 300],
        'max_depth': [10, 20, None],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4]
    }
    
    rf_grid = GridSearchCV(
        RandomForestClassifier(random_state=42),
        rf_param_grid,
        cv=5,
        scoring='accuracy',
        n_jobs=-1
    )
    rf_grid.fit(X_train_scaled, y_illness_train)
    
    # Grid search for Gradient Boosting
    gb_param_grid = {
        'n_estimators': [100, 200],
        'learning_rate': [0.1, 0.2],
        'max_depth': [3, 5, 7]
    }
    
    gb_grid = GridSearchCV(
        GradientBoostingClassifier(random_state=42),
        gb_param_grid,
        cv=5,
        scoring='accuracy',
        n_jobs=-1
    )
    gb_grid.fit(X_train_scaled, y_illness_train)
    
    # Create ensemble model
    illness_model = VotingClassifier(
        estimators=[
            ('rf', rf_grid.best_estimator_),
            ('gb', gb_grid.best_estimator_)
        ],
        voting='soft'
    )
    illness_model.fit(X_train_scaled, y_illness_train)
    
    # Evaluate illness model
    y_illness_pred = illness_model.predict(X_test_scaled)
    illness_accuracy = accuracy_score(y_illness_test, y_illness_pred)
    
    # Cross-validation score
    illness_cv_scores = cross_val_score(illness_model, X_train_scaled, y_illness_train, cv=5)
    
    print(f"Illness prediction accuracy: {illness_accuracy:.3f}")
    print(f"Illness CV accuracy: {illness_cv_scores.mean():.3f} (+/- {illness_cv_scores.std() * 2:.3f})")
    
    # Train doctor prediction model
    print("\n👨‍⚕️ Training doctor prediction model with hyperparameter tuning...")
    
    # Grid search for Random Forest
    rf_grid_doctor = GridSearchCV(
        RandomForestClassifier(random_state=42),
        rf_param_grid,
        cv=5,
        scoring='accuracy',
        n_jobs=-1
    )
    rf_grid_doctor.fit(X_train_scaled, y_doctor_train)
    
    # Grid search for Gradient Boosting
    gb_grid_doctor = GridSearchCV(
        GradientBoostingClassifier(random_state=42),
        gb_param_grid,
        cv=5,
        scoring='accuracy',
        n_jobs=-1
    )
    gb_grid_doctor.fit(X_train_scaled, y_doctor_train)
    
    # Create ensemble model for doctor prediction
    doctor_model = VotingClassifier(
        estimators=[
            ('rf', rf_grid_doctor.best_estimator_),
            ('gb', gb_grid_doctor.best_estimator_)
        ],
        voting='soft'
    )
    doctor_model.fit(X_train_scaled, y_doctor_train)
    
    # Evaluate doctor model
    y_doctor_pred = doctor_model.predict(X_test_scaled)
    doctor_accuracy = accuracy_score(y_doctor_test, y_doctor_pred)
    
    # Cross-validation score
    doctor_cv_scores = cross_val_score(doctor_model, X_train_scaled, y_doctor_train, cv=5)
    
    print(f"Doctor prediction accuracy: {doctor_accuracy:.3f}")
    print(f"Doctor CV accuracy: {doctor_cv_scores.mean():.3f} (+/- {doctor_cv_scores.std() * 2:.3f})")
    
    # Save models and encoders
    print("\n💾 Saving models and encoders...")
    
    models_dir = '.'
    
    # Save models
    with open(os.path.join(models_dir, 'illness_model.pkl'), 'wb') as f:
        pickle.dump(illness_model, f)
    
    with open(os.path.join(models_dir, 'doctor_model.pkl'), 'wb') as f:
        pickle.dump(doctor_model, f)
    
    # Save scaler
    with open(os.path.join(models_dir, 'scaler.pkl'), 'wb') as f:
        pickle.dump(scaler, f)
    
    # Save encoders
    with open(os.path.join(models_dir, 'illness_encoder.pkl'), 'wb') as f:
        pickle.dump(illness_encoder, f)
    
    with open(os.path.join(models_dir, 'doctor_encoder.pkl'), 'wb') as f:
        pickle.dump(doctor_encoder, f)
    
    with open(os.path.join(models_dir, 'gender_encoder.pkl'), 'wb') as f:
        pickle.dump(gender_encoder, f)
    
    # Save selected symptoms
    with open(os.path.join(models_dir, 'all_symptoms.pkl'), 'wb') as f:
        pickle.dump(selected_symptoms, f)
    
    # Save feature selector
    with open(os.path.join(models_dir, 'feature_selector.pkl'), 'wb') as f:
        pickle.dump(selector, f)
    
    # Save feature columns info
    feature_columns = {
        'symptom_features': len(selected_symptoms),
        'age_feature': 1,
        'gender_feature': 1,
        'total_features': len(selected_symptoms) + 2,
        'original_symptoms': unique_symptoms,
        'selected_symptom_indices': selected_symptom_indices
    }
    with open(os.path.join(models_dir, 'feature_columns.pkl'), 'wb') as f:
        pickle.dump(feature_columns, f)
    
    print("✅ All models and encoders saved successfully!")
    
    # Print detailed results
    print("\n=== Model Performance Summary ===")
    print(f"Illness Prediction Accuracy: {illness_accuracy:.1%}")
    print(f"Doctor Prediction Accuracy: {doctor_accuracy:.1%}")
    print(f"Illness CV Accuracy: {illness_cv_scores.mean():.1%} (+/- {illness_cv_scores.std() * 2:.1%})")
    print(f"Doctor CV Accuracy: {doctor_cv_scores.mean():.1%} (+/- {doctor_cv_scores.std() * 2:.1%})")
    
    print("\n=== Illness Classification Report ===")
    print(classification_report(y_illness_test, y_illness_pred, 
                               target_names=illness_encoder.classes_))
    
    print("\n=== Doctor Classification Report ===")
    print(classification_report(y_doctor_test, y_doctor_pred, 
                               target_names=doctor_encoder.classes_))
    
    print("\n=== Selected Symptoms ===")
    for i, symptom in enumerate(selected_symptoms[:20]):  # Show first 20
        print(f"{i+1}. {symptom}")
    if len(selected_symptoms) > 20:
        print(f"... and {len(selected_symptoms) - 20} more")
    
    print("\n🎉 Model training completed successfully!")
    print(f"📈 Achieved high accuracy: Illness {illness_accuracy:.1%}, Doctor {doctor_accuracy:.1%}")

if __name__ == '__main__':
    train_models()
