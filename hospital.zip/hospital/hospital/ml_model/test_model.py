import pickle
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report
import os

def test_models():
    """Test the trained models with sample data"""
    print("=== Testing ML Models ===\n")
    
    # Load the dataset
    dataset_path = 'illness_doctor_dataset_2000_clean.csv'
    if not os.path.exists(dataset_path):
        print(f"❌ Dataset not found: {dataset_path}")
        return
    
    print("📊 Loading test dataset...")
    df = pd.read_csv(dataset_path)
    
    # Load trained models and components
    print("🔧 Loading trained models...")
    
    try:
        with open('illness_model.pkl', 'rb') as f:
            illness_model = pickle.load(f)
        
        with open('doctor_model.pkl', 'rb') as f:
            doctor_model = pickle.load(f)
        
        with open('scaler.pkl', 'rb') as f:
            scaler = pickle.load(f)
        
        with open('illness_encoder.pkl', 'rb') as f:
            illness_encoder = pickle.load(f)
        
        with open('doctor_encoder.pkl', 'rb') as f:
            doctor_encoder = pickle.load(f)
        
        with open('gender_encoder.pkl', 'rb') as f:
            gender_encoder = pickle.load(f)
        
        with open('feature_selector.pkl', 'rb') as f:
            feature_selector = pickle.load(f)
        
        with open('feature_columns.pkl', 'rb') as f:
            feature_columns = pickle.load(f)
        
        with open('all_symptoms.pkl', 'rb') as f:
            all_symptoms = pickle.load(f)
        
        print("✅ All models loaded successfully!")
        
    except Exception as e:
        print(f"❌ Error loading models: {e}")
        return
    
    # Preprocess test data (same as training)
    print("\n🔧 Preprocessing test data...")
    
    # Handle missing values
    df = df.dropna(subset=['Illness', 'DoctorType', 'Age', 'Gender'])
    
    # Combine symptoms into a single string
    df['symptoms'] = df.apply(lambda row: ', '.join(filter(None, [
        str(row['Symptom1']).strip() if pd.notna(row['Symptom1']) else '',
        str(row['Symptom2']).strip() if pd.notna(row['Symptom2']) else '',
        str(row['Symptom3']).strip() if pd.notna(row['Symptom3']) else ''
    ])), axis=1)
    
    # Clean up symptoms
    df['symptoms'] = df['symptoms'].str.replace(',,', ',').str.strip(',').str.strip()
    
    # Remove rows with no symptoms
    df = df[df['symptoms'] != '']
    
    # Extract all unique symptoms
    all_symptoms_original = []
    for symptoms_str in df['symptoms']:
        if isinstance(symptoms_str, str):
            symptoms = [s.strip().lower() for s in symptoms_str.split(',') if s.strip()]
            all_symptoms_original.extend(symptoms)
    
    unique_symptoms = sorted(list(set(all_symptoms_original)))
    
    # Create symptom features
    symptom_features = []
    for symptoms_str in df['symptoms']:
        if isinstance(symptoms_str, str):
            symptoms = [s.strip().lower() for s in symptoms_str.split(',') if s.strip()]
            feature_vector = [1 if symptom in symptoms else 0 for symptom in unique_symptoms]
        else:
            feature_vector = [0] * len(unique_symptoms)
        symptom_features.append(feature_vector)
    
    # Create feature matrix
    X_symptoms = np.array(symptom_features)
    X_age = df['Age'].values.reshape(-1, 1)
    X_gender = df['Gender'].values.reshape(-1, 1)
    
    # Encode categorical variables
    X_gender_encoded = gender_encoder.transform(X_gender.ravel()).reshape(-1, 1)
    
    # Combine features
    X = np.hstack([X_symptoms, X_age, X_gender_encoded])
    
    # Apply feature selection
    X_selected = feature_selector.transform(X)
    
    # Scale features
    X_scaled = scaler.transform(X_selected)
    
    # Prepare target variables
    y_illness = illness_encoder.transform(df['Illness'])
    y_doctor = doctor_encoder.transform(df['DoctorType'])
    
    print(f"Test dataset shape: {X_scaled.shape}")
    
    # Test illness prediction
    print("\n🏥 Testing illness prediction...")
    y_illness_pred = illness_model.predict(X_scaled)
    illness_accuracy = accuracy_score(y_illness, y_illness_pred)
    print(f"Illness prediction accuracy: {illness_accuracy:.3f}")
    
    # Test doctor prediction
    print("\n👨‍⚕️ Testing doctor prediction...")
    y_doctor_pred = doctor_model.predict(X_scaled)
    doctor_accuracy = accuracy_score(y_doctor, y_doctor_pred)
    print(f"Doctor prediction accuracy: {doctor_accuracy:.3f}")
    
    # Test individual predictions
    print("\n🧪 Testing individual predictions...")
    
    # Sample test cases
    test_cases = [
        {
            'symptoms': 'tooth pain, gum swelling',
            'age': 35,
            'gender': 'M',
            'expected_illness': 'Tooth Decay',
            'expected_doctor': 'Dentist'
        },
        {
            'symptoms': 'fever, cough, chest pain',
            'age': 45,
            'gender': 'F',
            'expected_illness': 'Pneumonia',
            'expected_doctor': 'General Physician'
        },
        {
            'symptoms': 'fever, sore throat, cough',
            'age': 25,
            'gender': 'F',
            'expected_illness': 'Flu',
            'expected_doctor': 'General Physician'
        },
        {
            'symptoms': 'stomach pain, vomiting, fever',
            'age': 5,
            'gender': 'M',
            'expected_illness': 'Gastroenteritis (Child)',
            'expected_doctor': 'Pediatric'
        }
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\nTest Case {i}:")
        print(f"  Symptoms: {test_case['symptoms']}")
        print(f"  Age: {test_case['age']}, Gender: {test_case['gender']}")
        
        # Create feature vector
        symptom_features_test = [0] * len(unique_symptoms)
        symptoms_lower = test_case['symptoms'].lower()
        
        for j, symptom in enumerate(unique_symptoms):
            if symptom.lower() in symptoms_lower:
                symptom_features_test[j] = 1
        
        # Encode gender
        gender_mapping = {'M': 'Male', 'F': 'Female'}
        gender_for_encoding = gender_mapping.get(test_case['gender'], 'Male')
        gender_encoded = gender_encoder.transform([gender_for_encoding])[0]
        
        # Create feature vector
        features = symptom_features_test + [test_case['age'], gender_encoded]
        features_array = np.array(features).reshape(1, -1)
        
        # Apply feature selection and scaling
        features_selected = feature_selector.transform(features_array)
        features_scaled = scaler.transform(features_selected)
        
        # Make predictions
        illness_pred = illness_model.predict(features_scaled)[0]
        doctor_pred = doctor_model.predict(features_scaled)[0]
        
        predicted_illness = illness_encoder.inverse_transform([illness_pred])[0]
        predicted_doctor = doctor_encoder.inverse_transform([doctor_pred])[0]
        
        print(f"  Predicted Illness: {predicted_illness}")
        print(f"  Expected Illness: {test_case['expected_illness']}")
        print(f"  Predicted Doctor: {predicted_doctor}")
        print(f"  Expected Doctor: {test_case['expected_doctor']}")
        
        illness_correct = predicted_illness == test_case['expected_illness']
        doctor_correct = predicted_doctor == test_case['expected_doctor']
        
        print(f"  Illness Correct: {'✅' if illness_correct else '❌'}")
        print(f"  Doctor Correct: {'✅' if doctor_correct else '❌'}")
    
    # Print detailed results
    print("\n=== Test Results Summary ===")
    print(f"Illness Prediction Accuracy: {illness_accuracy:.1%}")
    print(f"Doctor Prediction Accuracy: {doctor_accuracy:.1%}")
    
    print("\n=== Illness Classification Report ===")
    print(classification_report(y_illness, y_illness_pred, 
                               target_names=illness_encoder.classes_))
    
    print("\n=== Doctor Classification Report ===")
    print(classification_report(y_doctor, y_doctor_pred, 
                               target_names=doctor_encoder.classes_))
    
    print("\n🎉 Model testing completed successfully!")

if __name__ == '__main__':
    test_models()
