from django.db import models

# This file will contain ML-related models if needed
# Currently using the existing pickle files for predictions 