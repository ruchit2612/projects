# Log Analyzer - Core Security Attack Detection Tool

A specialized web-based log analysis tool designed to detect and analyze the 8 core types of security attacks in log data. Built with Django backend and React frontend, focusing exclusively on identifying and responding to the most critical security threats.

## 🚀 Features

- **Multi-Format Log Support**: Apache, Nginx, Django, Linux Syslog, and custom formats
- **Core Attack Detection**: Specialized detection for the 8 most critical security attack types
- **Real-time Processing**: Upload and analyze logs instantly
- **Focused Security Reports**: Targeted reports with specific actions for each attack type
- **User-Friendly Interface**: Modern React-based dashboard with Material-UI
- **API-First Design**: RESTful API for integration with other tools

## 📁 Project Structure

```
logs/
├── backend/                 # Django backend
│   ├── api/                # API views and serializers
│   ├── logs/               # Log processing models and parsers
│   ├── ml/                 # Machine learning and security analysis
│   ├── notifications/      # Notification system
│   └── log_analyzer/       # Django project settings
├── frontend/               # React frontend
│   └── log_analyser/       # React application
└── logs/                   # Sample log files
```

## 🛠️ Installation & Setup

### Prerequisites

- Python 3.8+
- Node.js 16+
- npm or yarn

### Backend Setup

1. **Navigate to backend directory**:
   ```bash
   cd backend
   ```

2. **Create virtual environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Run database migrations**:
   ```bash
   python manage.py migrate
   ```

5. **Create superuser** (optional):
   ```bash
   python manage.py createsuperuser
   ```

6. **Run the development server**:
   ```bash
   python manage.py runserver 8000
   ```

### Frontend Setup

1. **Navigate to frontend directory**:
   ```bash
   cd frontend/log_analyser
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Start the development server**:
   ```bash
   npm start
   ```

The frontend will be available at `http://localhost:3000`

## 🧪 Testing

Run the comprehensive test suite to verify all components work correctly:

```bash
cd backend
python test_project.py
```

## 📊 Supported Log Formats

### 1. Apache Access Logs
- Combined Log Format
- Common Log Format
- Custom formats

### 2. SQL Injection Attack Logs
- Detects various SQL injection patterns
- UNION-based attacks
- Boolean-based attacks
- Error-based attacks

### 3. Linux System Logs
- SSH authentication logs
- System service logs
- Kernel messages

## 🔍 Core Security Attack Detection

### The 8 Core Attack Types
1. **Brute Force Login**: Detects repeated failed authentication attempts
2. **SQL Injection (SQLi)**: Identifies database manipulation attempts
3. **Cross-Site Scripting (XSS)**: Detects client-side code injection
4. **Directory Traversal**: Identifies unauthorized file access attempts
5. **Command Injection**: Detects system command execution attempts
6. **High Request Rate (DoS)**: Identifies denial of service patterns
7. **Access to Hidden/Admin Areas**: Detects administrative endpoint scanning
8. **Suspicious HTTP Methods**: Identifies unusual HTTP method usage

### Specialized Detection
- **Pattern-Based Analysis**: Advanced regex and ML-based detection
- **Behavioral Analysis**: Identifies attack patterns across multiple requests
- **Risk Assessment**: Calculates threat severity and confidence levels
- **Immediate Actions**: Provides specific remediation steps for each attack type

### Risk Scoring
- **Attack-Specific Assessment**: Calculates risk scores based on the 8 core attack types
- **Severity Classification**: Categorizes threats as Low, Medium, High, or Critical
- **Confidence Scoring**: Provides confidence levels for each attack detection
- **Prioritized Response**: Focuses on the most critical attack patterns

## 🚀 Usage

### 1. Upload Log Files
- Navigate to the upload page
- Select your log file
- The system will automatically detect the log format
- Processing happens in real-time

### 2. View Analysis Results
- Dashboard shows overview statistics for the 8 core attack types
- Detailed analysis reports for each uploaded file
- Security events categorized by attack type
- Traffic patterns and IP analysis focused on attack detection

### 3. Generate Reports
- Export analysis results in various formats
- Customizable report parameters
- Include charts and recommendations

## 🔧 API Endpoints

### Authentication
- `POST /api/auth/login/` - User login
- `POST /api/auth/logout/` - User logout
- `POST /api/auth/register/` - User registration

### Log Files
- `GET /api/log-files/` - List log files
- `POST /api/upload/` - Upload log file
- `GET /api/log-files/{id}/` - Get log file details
- `GET /api/log-files/{id}/analysis_report/` - Get analysis report

### Log Entries
- `GET /api/log-entries/` - List log entries
- `GET /api/log-entries/search/` - Search log entries

### Dashboard
- `GET /api/dashboard/` - Get dashboard statistics

## 🛡️ Security Features

### Built-in Security
- CSRF protection
- Session-based authentication
- Input validation and sanitization
- SQL injection prevention
- XSS protection

### Analysis Capabilities
- Real-time threat detection
- Pattern-based analysis
- Behavioral analysis
- Risk assessment
- Alert generation

## 📈 Performance

- **Fast Processing**: Optimized parsers for quick log analysis
- **Scalable Architecture**: Designed to handle large log files
- **Efficient Storage**: Optimized database queries and indexing
- **Real-time Updates**: Live dashboard updates

## 🔧 Configuration

### Environment Variables
Create a `.env` file in the backend directory:

```env
SECRET_KEY=your-secret-key-here
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1
```

### Database Configuration
The project uses SQLite by default. For production, configure PostgreSQL or MySQL in `settings.py`.

## 🐛 Troubleshooting

### Common Issues

1. **Database Migration Errors**:
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

2. **Frontend Build Issues**:
   ```bash
   npm install
   npm start
   ```

3. **Port Conflicts**:
   - Backend: Change port in `python manage.py runserver 8001`
   - Frontend: Change port in `package.json` proxy setting

### Testing
Run the test suite to verify everything works:
```bash
python test_project.py
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Check the troubleshooting section
- Review the API documentation

## 🎯 Roadmap

- [ ] Enhanced detection patterns for the 8 core attack types
- [ ] Real-time log streaming with instant attack detection
- [ ] Advanced ML-based pattern recognition for core attacks
- [ ] Integration with SIEM systems for automated response
- [ ] Custom alert rules for specific attack types
- [ ] Multi-tenant support with attack type isolation
- [ ] Advanced reporting focused on core attack remediation

---

**Note**: This tool is designed for security analysis and should be used responsibly. Always ensure you have proper authorization to analyze logs from systems you don't own.
