# Core Attack Types - Project Focus

This document outlines the 8 core attack types that the Log Analyzer project now exclusively focuses on, and the changes made to streamline the security analysis.

## 🎯 The 8 Core Attack Types

### 1. **Brute Force Login**
- **Description**: Repeated failed authentication attempts
- **Detection**: Multiple failed login attempts from same IP
- **Severity**: High
- **Impact**: Account compromise, credential stuffing

### 2. **SQL Injection (SQLi)**
- **Description**: Database manipulation attempts
- **Detection**: SQL keywords in query parameters
- **Severity**: Critical
- **Impact**: Data breach, unauthorized database access

### 3. **Cross-Site Scripting (XSS)**
- **Description**: Client-side code injection
- **Detection**: Script tags and JavaScript code in inputs
- **Severity**: High
- **Impact**: User session hijacking, data theft

### 4. **Directory Traversal**
- **Description**: Unauthorized file access attempts
- **Detection**: Path manipulation patterns (../, ..\\)
- **Severity**: High
- **Impact**: File system access, sensitive data exposure

### 5. **Command Injection**
- **Description**: System command execution attempts
- **Detection**: Shell commands in user inputs
- **Severity**: Critical
- **Impact**: System compromise, unauthorized access

### 6. **High Request Rate (DoS)**
- **Description**: Denial of service attack patterns
- **Detection**: Excessive requests from single IP
- **Severity**: Medium
- **Impact**: Service unavailability, resource exhaustion

### 7. **Access to Hidden/Admin Areas**
- **Description**: Administrative endpoint scanning
- **Detection**: Requests to admin paths and hidden areas
- **Severity**: Medium
- **Impact**: Information disclosure, potential admin access

### 8. **Suspicious HTTP Methods**
- **Description**: Unusual HTTP method usage
- **Detection**: Non-standard HTTP methods (PUT, DELETE, TRACE)
- **Severity**: Low
- **Impact**: Server configuration probing, potential vulnerabilities

## 🔧 Changes Made to the Project

### Backend Changes (`backend/ml/security_analyzer.py`)

1. **Attack Patterns**: Updated to only include the 8 core attack types
2. **Suspicious Paths**: Focused on admin areas and sensitive endpoints
3. **Vulnerability Signatures**: Streamlined to core attack patterns
4. **Activity Checklist**: Reduced from 15+ items to 8 core items
5. **Event Actions**: Specific remediation steps for each attack type
6. **Recommendations**: Tailored to the core attack types
7. **Escalation Reasoning**: Focused on core attack impacts

### Frontend Changes

1. **Dashboard** (`frontend/log_analyser/src/pages/Dashboard.js`):
   - Updated chart labels to show only the 8 core attack types
   - Streamlined attack type visualization

2. **Analysis Page** (`frontend/log_analyser/src/pages/Analysis.js`):
   - Reorganized into 2 groups: Core Attack Types (1-4) and (5-8)
   - Removed non-core attack categories
   - Numbered attack types for clear identification
   - Focused on the most critical security threats

### Documentation Changes

1. **README.md**: Updated to reflect focus on core attack types
2. **Features**: Streamlined to emphasize core attack detection
3. **Security Analysis**: Detailed explanation of the 8 attack types
4. **Roadmap**: Future enhancements focused on core attack detection

## 🚀 Benefits of the Focused Approach

### **Improved Detection Accuracy**
- Concentrated on the most common and dangerous attacks
- Reduced false positives from less relevant patterns
- Better pattern recognition for core attack types

### **Streamlined Response**
- Specific remediation steps for each attack type
- Faster incident response and triage
- Clear escalation paths based on attack severity

### **Better Resource Utilization**
- Focused development efforts on core functionality
- Reduced complexity in analysis algorithms
- More efficient log processing and storage

### **Enhanced User Experience**
- Clearer attack categorization
- Simplified dashboard and reports
- Easier understanding of security threats

## 📊 Attack Type Mapping

| Attack Type | Backend ID | Frontend Display | Severity | Priority |
|-------------|------------|------------------|----------|----------|
| Brute Force Login | `brute_force_login` | 1. Brute Force Login | High | 1 |
| SQL Injection | `sql_injection` | 2. SQL Injection | Critical | 2 |
| XSS | `xss` | 3. Cross-Site Scripting | High | 3 |
| Directory Traversal | `directory_traversal` | 4. Directory Traversal | High | 4 |
| Command Injection | `command_injection` | 5. Command Injection | Critical | 5 |
| High Request Rate | `high_request_rate` | 6. High Request Rate | Medium | 6 |
| Access Admin Areas | `access_hidden_admin` | 7. Access to Admin Areas | Medium | 7 |
| Suspicious HTTP Methods | `suspicious_http_methods` | 8. Suspicious HTTP Methods | Low | 8 |

## 🔮 Future Enhancements

1. **Enhanced Detection Patterns**: More sophisticated regex and ML patterns for each attack type
2. **Attack Chain Detection**: Identify multi-stage attacks combining multiple types
3. **Automated Response**: Integration with firewalls and security tools
4. **Threat Intelligence**: Feed updates for emerging attack patterns
5. **Custom Rules**: User-defined detection rules for specific environments

## 📝 Usage Notes

- The system now focuses exclusively on these 8 attack types
- All other security events are filtered out
- Reports are streamlined to show only relevant information
- Dashboard provides clear overview of core attack statistics
- Analysis page shows numbered attack types for easy reference

This focused approach ensures that security teams can quickly identify and respond to the most critical threats while maintaining a clear understanding of the security landscape.
