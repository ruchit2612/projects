import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  CircularProgress,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
import {
  Assessment,
  Download,
  Description,
  PictureAsPdf,
  TableChart,
} from '@mui/icons-material';
import { reportsAPI, logFilesAPI } from '../services/api';

const Reports = () => {
  const [logFiles, setLogFiles] = useState([]);
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [generateDialog, setGenerateDialog] = useState(false);
  const [reportConfig, setReportConfig] = useState({
    log_file_id: '',
    report_type: 'csv',
  });

  useEffect(() => {
    fetchLogFiles();
    fetchReports();
  }, []);

  const fetchLogFiles = async () => {
    try {
      const response = await logFilesAPI.list();
      setLogFiles(response.data.results || response.data || []);
    } catch (err) {
      console.error('Error fetching log files:', err);
    }
  };

  const fetchReports = async () => {
    try {
      const response = await reportsAPI.list();
      setReports(response.data || []);
    } catch (err) {
      console.error('Error fetching reports:', err);
      setReports([]);
    }
  };

  const handleGenerateReport = async () => {
    try {
      setLoading(true);
      await reportsAPI.generate(reportConfig);
      setGenerateDialog(false);
      setReportConfig({
        log_file_id: '',
        report_type: 'csv',
      });
      // Refresh reports list
      fetchReports();
    } catch (err) {
      console.error('Error generating report:', err);
      setError('Failed to generate report');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async (reportId) => {
    try {
      const response = await reportsAPI.download(reportId);
      
      // Create a blob URL and trigger download
      const blob = new Blob([response.data]);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `report_${reportId}.${reports.find(r => r.id === reportId)?.report_type || 'pdf'}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (err) {
      console.error('Error downloading report:', err);
      setError('Failed to download report');
    }
  };

  const getReportTypeIcon = (type) => {
    switch (type) {
      case 'pdf':
        return <PictureAsPdf />;

      case 'csv':
        return <TableChart />;
      default:
        return <Description />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'success';
      case 'processing':
        return 'warning';
      case 'failed':
        return 'error';
      case 'pending':
        return 'info';
      default:
        return 'default';
    }
  };

  const formatFileSize = (bytes) => {
    if (!bytes || bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ color: 'text.primary', mb: 3 }}>
        Reports
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      <Grid container spacing={3}>
        {/* Generate Report Card */}
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" mb={2}>
                <Assessment sx={{ mr: 1, color: 'primary.main' }} />
                <Typography variant="h6">Generate Report</Typography>
              </Box>
              <Typography variant="body2" color="textSecondary" paragraph>
                Create comprehensive reports from your log analysis data.
              </Typography>
              <Button
                fullWidth
                variant="contained"
                startIcon={<Assessment />}
                onClick={() => setGenerateDialog(true)}
              >
                Generate New Report
              </Button>
            </CardContent>
          </Card>
        </Grid>

        {/* Report Statistics */}
        <Grid item xs={12} md={8}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Report Statistics
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={6} sm={3}>
                  <Box textAlign="center">
                    <Typography variant="h4" color="primary.main">
                      {reports.length}
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                      Total Reports
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={6} sm={3}>
                  <Box textAlign="center">
                    <Typography variant="h4" color="success.main">
                      {reports.filter(r => r.status === 'completed').length}
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                      Completed
                    </Typography>
                  </Box>
                </Grid>


              </Grid>
            </CardContent>
          </Card>
        </Grid>

        {/* Reports List */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Recent Reports
              </Typography>
              
              {reports.length === 0 ? (
                <Box textAlign="center" py={4}>
                  <Description sx={{ fontSize: 64, color: 'text.secondary', mb: 2 }} />
                  <Typography variant="h6" color="textSecondary" gutterBottom>
                    No Reports Generated
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    Generate your first report to get started.
                  </Typography>
                </Box>
              ) : (
                <List>
                  {reports.map((report) => (
                    <ListItem
                      key={report.id}
                      sx={{
                        border: '1px solid',
                        borderColor: 'divider',
                        borderRadius: 1,
                        mb: 1,
                      }}
                    >
                      <ListItemIcon>
                        {getReportTypeIcon(report.report_type)}
                      </ListItemIcon>
                      <ListItemText
                        primary={report.name}
                        secondary={`Generated on ${new Date(report.created_at).toLocaleString()} • ${formatFileSize(report.file_size)}`}
                      />
                      <Box display="flex" alignItems="center" gap={1}>
                        <Chip
                          label={report.status}
                          color={getStatusColor(report.status)}
                          size="small"
                        />
                        <Button
                          size="small"
                          variant="outlined"
                          startIcon={<Download />}
                          disabled={report.status !== 'completed'}
                          onClick={() => handleDownload(report.id)}
                        >
                          Download
                        </Button>
                      </Box>
                    </ListItem>
                  ))}
                </List>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Generate Report Dialog */}
      <Dialog open={generateDialog} onClose={() => setGenerateDialog(false)} maxWidth="md" fullWidth>
        <DialogTitle>
          Generate Report
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel>Log File</InputLabel>
                <Select
                  value={reportConfig.log_file_id}
                  onChange={(e) => setReportConfig(prev => ({ ...prev, log_file_id: e.target.value }))}
                  label="Log File"
                >
                  <MenuItem value="">All Log Files</MenuItem>
                  {logFiles.map((file) => (
                    <MenuItem key={file.id} value={file.id}>
                      {file.filename}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel>Report Type</InputLabel>
                <Select
                  value={reportConfig.report_type}
                  onChange={(e) => setReportConfig(prev => ({ ...prev, report_type: e.target.value }))}
                  label="Report Type"
                >
                  <MenuItem value="csv">CSV Report</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setGenerateDialog(false)}>
            Cancel
          </Button>
          <Button
            onClick={handleGenerateReport}
            variant="contained"
            disabled={loading}
            startIcon={loading ? <CircularProgress size={20} /> : <Assessment />}
          >
            {loading ? 'Generating...' : 'Generate Report'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Reports;
