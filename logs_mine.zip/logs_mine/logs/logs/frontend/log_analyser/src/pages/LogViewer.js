import React, { useState, useEffect, useCallback } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  TextField,
  Button,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  CircularProgress,
  Pagination,
} from '@mui/material';
import {
  FilterList,
} from '@mui/icons-material';
import { logEntriesAPI, formatDate } from '../services/api';

const LogViewer = () => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [filters, setFilters] = useState({
    ip_address: '',
    status_code: '',
    method: '',
    path: '',
    log_file_id: '',
  });
  const [pagination, setPagination] = useState({
    page: 1,
    page_size: 50,
    total: 0,
  });

  const fetchLogs = useCallback(async () => {
    try {
      setLoading(true);
      setError(''); // Clear any previous errors
      
      // Only include non-empty filters
      const params = {
        page: pagination.page,
        page_size: pagination.page_size,
      };
      
      // Add filters only if they have values
      Object.keys(filters).forEach(key => {
        if (filters[key] && filters[key].toString().trim() !== '') {
          params[key] = filters[key];
        }
      });
      
      const response = await logEntriesAPI.search(params);
      
      if (response.data && response.data.results) {
        setLogs(response.data.results);
        setPagination(prev => ({
          ...prev,
          total: response.data.total || 0,
        }));
      } else {
        setLogs([]);
        setPagination(prev => ({
          ...prev,
          total: 0,
        }));
      }
    } catch (err) {
      console.error('Error fetching logs:', err);
      setError(`Failed to load logs: ${err.response?.data?.detail || err.message || 'Unknown error'}`);
      setLogs([]);
      setPagination(prev => ({
        ...prev,
        total: 0,
      }));
    } finally {
      setLoading(false);
    }
  }, [filters, pagination.page, pagination.page_size]);

  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  const handleFilterChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value }));
    setPagination(prev => ({ ...prev, page: 1 }));
  };



  const handlePageChange = (event, page) => {
    setPagination(prev => ({ ...prev, page }));
  };

  const clearFilters = () => {
    setFilters({
      ip_address: '',
      status_code: '',
      method: '',
      path: '',
      log_file_id: '',
    });
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const getStatusColor = (statusCode) => {
    if (statusCode >= 500) return 'error';
    if (statusCode >= 400) return 'warning';
    if (statusCode >= 300) return 'info';
    return 'success';
  };

  const getMethodColor = (method) => {
    switch (method?.toUpperCase()) {
      case 'GET': return 'success';
      case 'POST': return 'warning';
      case 'PUT': return 'info';
      case 'DELETE': return 'error';
      default: return 'default';
    }
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ color: 'text.primary', mb: 3 }}>
        Log Viewer
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      {/* Filters */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Box display="flex" alignItems="center" mb={2}>
            <FilterList sx={{ mr: 1 }} />
            <Typography variant="h6">Filters</Typography>
          </Box>
          
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6} md={2}>
              <TextField
                fullWidth
                label="IP Address"
                value={filters.ip_address}
                onChange={(e) => handleFilterChange('ip_address', e.target.value)}
                size="small"
                placeholder="Search IP..."
              />
            </Grid>
            <Grid item xs={12} sm={6} md={2}>
              <TextField
                fullWidth
                label="Status Code"
                value={filters.status_code}
                onChange={(e) => handleFilterChange('status_code', e.target.value)}
                size="small"
                placeholder="Search status..."
              />
            </Grid>
            <Grid item xs={12} sm={6} md={2}>
              <FormControl fullWidth size="small">
                <InputLabel>Method</InputLabel>
                <Select
                  value={filters.method}
                  onChange={(e) => handleFilterChange('method', e.target.value)}
                  label="Method"
                >
                  <MenuItem value="">All</MenuItem>
                  <MenuItem value="GET">GET</MenuItem>
                  <MenuItem value="POST">POST</MenuItem>
                  <MenuItem value="PUT">PUT</MenuItem>
                  <MenuItem value="DELETE">DELETE</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <TextField
                fullWidth
                label="Path"
                value={filters.path}
                onChange={(e) => handleFilterChange('path', e.target.value)}
                size="small"
                placeholder="Search path..."
              />
            </Grid>
            <Grid item xs={12} sm={6} md={2}>
              <Button
                fullWidth
                variant="outlined"
                onClick={clearFilters}
                size="small"
              >
                Clear
              </Button>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Logs Table */}
      <Card>
        <CardContent>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
            <Typography variant="h6">Log Entries</Typography>
            <Typography variant="body2" color="textSecondary">
              Total: {pagination.total} entries
            </Typography>
          </Box>

          {loading ? (
            <Box display="flex" justifyContent="center" p={3}>
              <CircularProgress />
            </Box>
          ) : logs.length > 0 ? (
            <>
              <TableContainer component={Paper} sx={{ maxHeight: 600 }}>
                <Table stickyHeader>
                  <TableHead>
                    <TableRow>
                      <TableCell>File Name</TableCell>
                      <TableCell>Timestamp</TableCell>
                      <TableCell>IP Address</TableCell>
                      <TableCell>Method</TableCell>
                      <TableCell>Path</TableCell>
                      <TableCell>Status</TableCell>
                      <TableCell>Size</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {logs.map((log) => (
                      <TableRow key={log.id} hover>
                        <TableCell>
                          <Typography variant="body2" sx={{ fontWeight: 'medium' }}>
                            {log.filename || 'Unknown'}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2">
                            {formatDate(log.timestamp)}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" fontFamily="monospace">
                            {log.ip_address}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={log.method}
                            color={getMethodColor(log.method)}
                            size="small"
                          />
                        </TableCell>
                        <TableCell>
                          <Typography
                            variant="body2"
                            sx={{
                              maxWidth: 200,
                              overflow: 'hidden',
                              textOverflow: 'ellipsis',
                              whiteSpace: 'nowrap',
                            }}
                          >
                            {log.path}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={log.status_code}
                            color={getStatusColor(log.status_code)}
                            size="small"
                          />
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2">
                            {log.response_size?.toLocaleString() || '-'}
                          </Typography>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>

              {/* Pagination */}
              {pagination.total > pagination.page_size && (
                <Box display="flex" justifyContent="center" mt={2}>
                  <Pagination
                    count={Math.ceil(pagination.total / pagination.page_size)}
                    page={pagination.page}
                    onChange={handlePageChange}
                    color="primary"
                  />
                </Box>
              )}
            </>
          ) : (
            <Box display="flex" justifyContent="center" p={3}>
              <Typography variant="body1" color="textSecondary">
                {Object.values(filters).some(f => f && f.toString().trim() !== '') 
                  ? 'No logs found matching your search criteria.' 
                  : 'No logs available. Upload a log file to get started.'}
              </Typography>
            </Box>
          )}
        </CardContent>
      </Card>

      {/* Log Details Modal would go here */}
    </Box>
  );
};

export default LogViewer;
