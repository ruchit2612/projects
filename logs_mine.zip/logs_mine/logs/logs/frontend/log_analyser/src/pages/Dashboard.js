import React, { useState, useEffect } from 'react';
import {
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  Alert,
  CircularProgress,
  Button,
} from '@mui/material';
import {
  Warning,
  Security,
  Visibility,
} from '@mui/icons-material';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { dashboardAPI } from '../services/api';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const Dashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    fetchDashboardStats();
  }, []);

  const fetchDashboardStats = async () => {
    try {
      setLoading(true);
      const response = await dashboardAPI.getStats();
      setStats(response.data);
    } catch (err) {
      console.error('Error fetching dashboard stats:', err);
      setError('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAll = async () => {
    setError('');
    console.log('🗑️ Delete All button clicked');
    
    try {
      setDeleting(true);
      console.log('🔄 Making API call to delete all logs...');
      
      const resp = await dashboardAPI.deleteAll();
      console.log('📡 API Response:', resp);
      
      if (resp && resp.status >= 200 && resp.status < 300) {
        console.log('✅ Delete successful, updating local state...');
        // Reset local stats to zero
        setStats({
          total_log_files: 0,
          total_entries: 0,
          suspicious_activities: 0,
          risk_score_avg: 0,
          top_ips: [],
          top_paths: [],
          status_code_distribution: {},
          recent_activities: [],
          attack_types_stats: {
            brute_force_login: 0,
            sql_injection: 0,
            xss: 0,
            directory_traversal: 0,
            command_injection: 0,
            high_request_rate: 0,
            access_hidden_admin: 0,
            suspicious_http_methods: 0
          }
        });
        console.log('✅ Local state updated successfully');
      } else {
        console.error('❌ Delete failed with status:', resp?.status);
        setError('Failed to delete data');
      }
    } catch (err) {
      console.error('❌ Error deleting all data:', err);
      console.error('❌ Error details:', {
        message: err.message,
        stack: err.stack,
        response: err.response
      });
      
      // Attempt a refresh to reflect server state if it did delete
      try {
        console.log('🔄 Attempting to refresh dashboard stats...');
        await fetchDashboardStats();
      } catch (refreshErr) {
        console.error('❌ Failed to refresh stats:', refreshErr);
      }
      setError(`Failed to delete data: ${err.message}`);
    } finally {
      setDeleting(false);
      console.log('🏁 Delete operation completed');
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box>
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
        <Button onClick={fetchDashboardStats} variant="contained">
          Retry
        </Button>
      </Box>
    );
  }

  // Use real data or fallback to sample data
  const dashboardStats = stats || {
    total_log_files: 0,
    total_entries: 0,
    suspicious_activities: 0,
    risk_score_avg: 0,
    top_ips: [],
    top_paths: [],
    status_code_distribution: {},
    recent_activities: [],
    attack_types_stats: {
      brute_force_login: 0,
      sql_injection: 0,
      xss: 0,
      directory_traversal: 0,
      command_injection: 0,
      high_request_rate: 0,
      access_hidden_admin: 0,
      suspicious_http_methods: 0
    }
  };

  const statsCards = [
    {
      title: 'Total Log Files',
      value: dashboardStats.total_log_files?.toLocaleString() || '0',
      icon: <Visibility />,
      color: '#90caf9',
    },
    {
      title: 'Total Entries',
      value: dashboardStats.total_entries?.toLocaleString() || '0',
      icon: <Visibility />,
      color: '#90caf9',
    },
    {
      title: 'Suspicious Activities',
      value: dashboardStats.suspicious_activities?.toString() || '0',
      icon: <Warning />,
      color: '#f48fb1',
    },
    {
      title: 'Avg Risk Score',
      value: `${(dashboardStats.risk_score_avg * 100).toFixed(1) || '0'}%`,
      icon: <Security />,
      color: '#ff9800',
    },
  ];

  const barChartData = {
    labels: ['Brute Force Login', 'SQL Injection', 'XSS', 'Directory Traversal', 'Command Injection', 'High Request Rate', 'Access Admin Areas', 'Suspicious HTTP Methods'],
    datasets: [
      {
        label: 'Attack Types Detected',
        data: [
          dashboardStats.attack_types_stats?.brute_force_login || 0,
          dashboardStats.attack_types_stats?.sql_injection || 0,
          dashboardStats.attack_types_stats?.xss || 0,
          dashboardStats.attack_types_stats?.directory_traversal || 0,
          dashboardStats.attack_types_stats?.command_injection || 0,
          dashboardStats.attack_types_stats?.high_request_rate || 0,
          dashboardStats.attack_types_stats?.access_hidden_admin || 0,
          dashboardStats.attack_types_stats?.suspicious_http_methods || 0,
        ],
        backgroundColor: [
          '#ff9800', // Brute Force - Orange
          '#f44336', // SQL Injection - Red
          '#9c27b0', // XSS - Purple
          '#2196f3', // Directory Traversal - Blue
          '#4caf50', // Command Injection - Green
          '#ff5722', // High Request Rate - Deep Orange
          '#795548', // Access Admin Areas - Brown
          '#607d8b', // Suspicious HTTP Methods - Blue Grey
        ],
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        labels: {
          color: '#ffffff',
        },
      },
    },
    scales: {
      x: {
        ticks: {
          color: '#b0b0b0',
        },
        grid: {
          color: '#333',
        },
      },
      y: {
        ticks: {
          color: '#b0b0b0',
        },
        grid: {
          color: '#333',
        },
      },
    },
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ color: 'text.primary', mb: 3 }}>
        Dashboard
      </Typography>

      <Box sx={{ mb: 2 }}>
        <Button
          variant="outlined"
          color="error"
          onClick={handleDeleteAll}
          disabled={deleting}
        >
          {deleting ? 'Deleting…' : 'Delete All Logs'}
        </Button>
      </Box>

      {/* Stats Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {statsCards.map((stat, index) => (
          <Grid item xs={12} sm={6} md={3} key={index}>
            <Card>
              <CardContent>
                <Box display="flex" alignItems="center" justifyContent="space-between">
                  <Box>
                    <Typography color="textSecondary" gutterBottom variant="body2">
                      {stat.title}
                    </Typography>
                    <Typography variant="h4" component="div" sx={{ color: stat.color }}>
                      {stat.value}
                    </Typography>
                  </Box>
                  <Box sx={{ color: stat.color }}>
                    {stat.icon}
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>



      {/* Attack Types Chart */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ color: 'text.primary' }}>
                Attack Types Analysis
              </Typography>
              <Bar data={barChartData} options={chartOptions} />
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Recent Alerts */}
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ color: 'text.primary' }}>
                Recent Alerts
              </Typography>
              <Box sx={{ mt: 2 }}>
                {dashboardStats.recent_activities?.length > 0 ? (
                  dashboardStats.recent_activities.map((activity, index) => (
                    <Alert key={index} severity="warning" sx={{ mb: 2 }}>
                      {activity.description}
                    </Alert>
                  ))
                ) : (
                  <Alert severity="info">
                    No recent suspicious activities detected
                  </Alert>
                )}
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard;
