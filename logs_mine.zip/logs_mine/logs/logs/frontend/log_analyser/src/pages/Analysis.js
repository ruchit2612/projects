import React, { useState, useEffect, useCallback } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  Chip,
  Alert,
  CircularProgress,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@mui/material';
import {
  Warning,
  Error,
  Info,
  Security,
  CheckCircle,
  Timeline,
  Assessment,
  TrendingUp,
  Shield,
  Code,
  DataUsage,
  Router,
} from '@mui/icons-material';
import { logFilesAPI } from '../services/api';

const Analysis = () => {
  const [logFiles, setLogFiles] = useState([]);
  const [selectedFileId, setSelectedFileId] = useState('');
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchLogFiles = useCallback(async () => {
    try {
      setLoading(true);
      const response = await logFilesAPI.list();
      const files = response.data.results || response.data || [];
      console.log('Fetched log files:', files);
      setLogFiles(files);
    } catch (err) {
      console.error('Error fetching log files:', err);
      setError('Failed to load log files');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchLogFiles();
  }, [fetchLogFiles]);

  // Set initial file selection when log files are loaded
  useEffect(() => {
    console.log('logFiles changed:', logFiles);
    console.log('selectedFileId:', selectedFileId);
    if (logFiles.length > 0 && !selectedFileId) {
      console.log('Setting initial file selection to:', logFiles[0].id);
      setSelectedFileId(String(logFiles[0].id));
    }
  }, [logFiles, selectedFileId]);

  useEffect(() => {
    if (selectedFileId) {
      fetchReport(selectedFileId);
    } else {
      setReport(null);
    }
  }, [selectedFileId]);

  const fetchReport = async (fileId) => {
    try {
      setLoading(true);
      setError('');
      const response = await logFilesAPI.analysisReport(fileId);
      setReport(response.data);
    } catch (err) {
      console.error('Error fetching analysis report:', err);
      setError('Failed to load analysis report');
      setReport(null);
    } finally {
      setLoading(false);
    }
  };



  const formatNumber = (num) => {
    return new Intl.NumberFormat().format(num);
  };

  if (loading && !report) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom sx={{ color: 'text.primary', mb: 3, display: 'flex', alignItems: 'center' }}>
        <Assessment sx={{ mr: 2 }} />
        Security Analysis Results
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      {/* File selector */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
            <Code sx={{ mr: 1 }} />
            Select Log File ({logFiles.length} files available)
          </Typography>
          <select
            value={selectedFileId}
            onChange={(e) => {
              console.log('File selection changed to:', e.target.value);
              setSelectedFileId(String(e.target.value));
            }}
            disabled={logFiles.length === 0}
            style={{ width: '100%', padding: '12px', border: '1px solid #ccc', borderRadius: '4px' }}
          >
            <option value="">Choose a log file to analyze</option>
            {logFiles.map((file) => (
              <option key={file.id} value={String(file.id)}>
                {file.filename} ({file.log_type}) - {file.processed_lines} lines
              </option>
            ))}
          </select>
        </CardContent>
      </Card>

      {report && (
        <>
          {/* Executive Summary Card */}
          <Card sx={{ mb: 3, background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', color: 'white' }}>
            <CardContent>
              <Typography variant="h5" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
                <CheckCircle sx={{ mr: 2 }} />
                ✅ Log Analysis Test Results
              </Typography>
              <Typography variant="body1" sx={{ mb: 2, opacity: 0.9 }}>
                {report.summary || 'Comprehensive security analysis completed successfully.'}
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6} md={3}>
                  <Box textAlign="center">
                    <Typography variant="h6">{report.highest_severity || 'LOW'}</Typography>
                    <Typography variant="caption">Highest Severity</Typography>
                  </Box>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Box textAlign="center">
                    <Typography variant="h6">
                      {report.requires_immediate_attention ? '✅ YES' : '❌ NO'}
                    </Typography>
                    <Typography variant="caption">Immediate Attention</Typography>
                  </Box>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Box textAlign="center">
                    <Typography variant="h6">{((report.risk_score || 0) * 100).toFixed(2)}%</Typography>
                    <Typography variant="caption">Risk Score</Typography>
                  </Box>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Box textAlign="center">
                    <Typography variant="h6">{formatNumber(report.total_entries || 0)}</Typography>
                    <Typography variant="caption">Total Requests</Typography>
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Critical Security Threats */}
          <Card sx={{ mb: 3, border: '2px solid #f44336' }}>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', color: '#f44336' }}>
                <Error sx={{ mr: 1 }} />
                🔴 Critical Security Threats
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <Box>
                    <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
                      {report.security_events?.length || 0} Critical Security Event(s)
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Detected across {report.total_entries || 0} log entries
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Box>
                    <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
                      Highest Severity: {report.highest_severity || 'LOW'}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Requires Immediate Attention: {report.requires_immediate_attention ? '✅ YES' : '❌ NO'}
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Comprehensive Attack Detection */}
          <Card sx={{ mb: 3, border: '2px solid #d32f2f' }}>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', color: '#d32f2f' }}>
                <Security sx={{ mr: 1 }} />
                🎯 Comprehensive Attack Detection
              </Typography>
              
              {/* Attack Categories */}
              <Grid container spacing={3} sx={{ mt: 2 }}>
                {/* Core Attack Types - Group 1 */}
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#d32f2f', mb: 2 }}>
                    🔴 Core Attack Types (1-4)
                  </Typography>
                  <List dense>
                    {(report.security_events || []).some(e => e.type?.toLowerCase().includes('brute_force')) && (
                      <ListItem sx={{ pl: 0 }}>
                        <ListItemIcon>
                          <Warning color="warning" />
                        </ListItemIcon>
                        <ListItemText 
                          primary={`1. Brute Force Login (${(report.security_events || []).filter(e => e.type?.toLowerCase().includes('brute_force')).length})`}
                          secondary="Credential stuffing attempts"
                        />
                      </ListItem>
                    )}
                    {(report.security_events || []).some(e => e.type?.toLowerCase().includes('sql')) && (
                      <ListItem sx={{ pl: 0 }}>
                        <ListItemIcon>
                          <Error color="error" />
                        </ListItemIcon>
                        <ListItemText 
                          primary={`2. SQL Injection (${(report.security_events || []).filter(e => e.type?.toLowerCase().includes('sql')).length})`}
                          secondary="Database manipulation attempts"
                        />
                      </ListItem>
                    )}
                    {(report.security_events || []).some(e => e.type?.toLowerCase().includes('xss')) && (
                      <ListItem sx={{ pl: 0 }}>
                        <ListItemIcon>
                          <Error color="error" />
                        </ListItemIcon>
                        <ListItemText 
                          primary={`3. Cross-Site Scripting (${(report.security_events || []).filter(e => e.type?.toLowerCase().includes('xss')).length})`}
                          secondary="Client-side code injection"
                        />
                      </ListItem>
                    )}
                    {(report.security_events || []).some(e => e.type?.toLowerCase().includes('directory')) && (
                      <ListItem sx={{ pl: 0 }}>
                        <ListItemIcon>
                          <Warning color="warning" />
                        </ListItemIcon>
                        <ListItemText 
                          primary={`4. Directory Traversal (${(report.security_events || []).filter(e => e.type?.toLowerCase().includes('directory')).length})`}
                          secondary="Unauthorized file access attempts"
                        />
                      </ListItem>
                    )}
                  </List>
                </Grid>

                {/* Core Attack Types - Group 2 */}
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#f57c00', mb: 2 }}>
                    🟠 Core Attack Types (5-8)
                  </Typography>
                  <List dense>
                    {(report.security_events || []).some(e => e.type?.toLowerCase().includes('command')) && (
                      <ListItem sx={{ pl: 0 }}>
                        <ListItemIcon>
                          <Error color="error" />
                        </ListItemIcon>
                        <ListItemText 
                          primary={`5. Command Injection (${(report.security_events || []).filter(e => e.type?.toLowerCase().includes('command')).length})`}
                          secondary="System command execution attempts"
                        />
                      </ListItem>
                    )}
                    {(report.security_events || []).some(e => e.type?.toLowerCase().includes('high_request')) && (
                      <ListItem sx={{ pl: 0 }}>
                        <ListItemIcon>
                          <Warning color="warning" />
                        </ListItemIcon>
                        <ListItemText 
                          primary={`6. High Request Rate (${(report.security_events || []).filter(e => e.type?.toLowerCase().includes('high_request')).length})`}
                          secondary="DoS/DDoS attack patterns"
                        />
                      </ListItem>
                    )}
                    {(report.security_events || []).some(e => e.type?.toLowerCase().includes('access_hidden')) && (
                      <ListItem sx={{ pl: 0 }}>
                        <ListItemIcon>
                          <Info color="info" />
                        </ListItemIcon>
                        <ListItemText 
                          primary={`7. Access to Admin Areas (${(report.security_events || []).filter(e => e.type?.toLowerCase().includes('access_hidden')).length})`}
                          secondary="Admin endpoint scanning"
                        />
                      </ListItem>
                    )}
                    {(report.security_events || []).some(e => e.type?.toLowerCase().includes('suspicious_http')) && (
                      <ListItem sx={{ pl: 0 }}>
                        <ListItemIcon>
                          <Info color="info" />
                        </ListItemIcon>
                        <ListItemText 
                          primary={`8. Suspicious HTTP Methods (${(report.security_events || []).filter(e => e.type?.toLowerCase().includes('suspicious_http')).length})`}
                          secondary="Unusual HTTP method usage"
                        />
                      </ListItem>
                    )}
                  </List>
                </Grid>


              </Grid>

              {/* Attack Summary */}
              <Box sx={{ mt: 3, p: 2, bgcolor: 'grey.50', borderRadius: 1 }}>
                <Typography variant="subtitle2" sx={{ fontWeight: 'bold', mb: 1 }}>
                  📊 Attack Summary
                </Typography>
                <Grid container spacing={2}>
                  <Grid item xs={6} md={3}>
                    <Typography variant="body2" color="text.secondary">
                      Total Attacks Detected
                    </Typography>
                    <Typography variant="h6" color="error">
                      {report.security_events?.length || 0}
                    </Typography>
                  </Grid>
                  <Grid item xs={6} md={3}>
                    <Typography variant="body2" color="text.secondary">
                      Critical Severity
                    </Typography>
                    <Typography variant="h6" color="error">
                      {(report.security_events || []).filter(e => e.severity === 'critical').length || 0}
                    </Typography>
                  </Grid>
                  <Grid item xs={6} md={3}>
                    <Typography variant="body2" color="text.secondary">
                      High Severity
                    </Typography>
                    <Typography variant="h6" color="warning.main">
                      {(report.security_events || []).filter(e => e.severity === 'high').length || 0}
                    </Typography>
                  </Grid>
                  <Grid item xs={6} md={3}>
                    <Typography variant="body2" color="text.secondary">
                      Medium Severity
                    </Typography>
                    <Typography variant="h6" color="info.main">
                      {(report.security_events || []).filter(e => e.severity === 'medium').length || 0}
                    </Typography>
                  </Grid>
                </Grid>
              </Box>
            </CardContent>
          </Card>

          {/* Attack Analysis */}
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
                <Security sx={{ mr: 1 }} />
                🎯 Attack Analysis
              </Typography>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
                    IP Analysis
                  </Typography>
                  <List dense>
                    <ListItem>
                      <ListItemIcon>
                        <Router />
                      </ListItemIcon>
                      <ListItemText 
                        primary={`${(report.key_observations || []).find(obs => obs.includes('Unique IPs'))?.split(':')[1]?.trim() || 'Unknown'} Unique IPs involved`}
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemIcon>
                        <Warning />
                      </ListItemIcon>
                      <ListItemText 
                        primary={`${report.suspicious_ips?.length || 0} Suspicious IPs flagged`}
                      />
                    </ListItem>
                  </List>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
                    Traffic Analysis
                  </Typography>
                  <List dense>
                    <ListItem>
                      <ListItemIcon>
                        <TrendingUp />
                      </ListItemIcon>
                      <ListItemText 
                        primary={`${report.traffic_patterns?.length || 0} Different endpoints targeted`}
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemIcon>
                        <Error />
                      </ListItemIcon>
                      <ListItemText 
                        primary={`${(report.key_observations || []).find(obs => obs.includes('error'))?.split(':')[1]?.trim() || '0'} Error Rate`}
                      />
                    </ListItem>
                  </List>
                </Grid>
              </Grid>
            </CardContent>
          </Card>



          {/* Traffic Patterns */}
          {report.traffic_patterns && Array.isArray(report.traffic_patterns) && report.traffic_patterns.length > 0 && (
            <Card sx={{ mb: 3 }}>
              <CardContent>
                <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
                  <Timeline sx={{ mr: 1 }} />
                  📈 Traffic Patterns
                </Typography>
                <TableContainer component={Paper} sx={{ maxHeight: 400 }}>
                  <Table stickyHeader size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Method</TableCell>
                        <TableCell>Path</TableCell>
                        <TableCell>Hits</TableCell>
                        <TableCell>Status Codes</TableCell>
                        <TableCell>Suspicious</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {(report.traffic_patterns || []).map((pattern, index) => (
                        <TableRow key={index} hover>
                          <TableCell>
                            <Chip 
                              label={pattern.method} 
                              size="small" 
                              color={pattern.method === 'GET' ? 'primary' : 'secondary'}
                            />
                          </TableCell>
                          <TableCell>{pattern.path}</TableCell>
                          <TableCell>{pattern.hits}</TableCell>
                          <TableCell>
                            {Array.isArray(pattern.status_codes) ? pattern.status_codes.join(', ') : 'N/A'}
                          </TableCell>
                          <TableCell>
                            <Chip 
                              label={pattern.is_suspicious ? 'Yes' : 'No'} 
                              size="small" 
                              color={pattern.is_suspicious ? 'error' : 'success'}
                            />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </CardContent>
            </Card>
          )}

          {/* Security Recommendations */}
          <Card sx={{ mb: 3, border: '2px solid #4caf50' }}>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', color: '#4caf50' }}>
                <Shield sx={{ mr: 1 }} />
                🚨 Security Recommendations
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mb: 1 }}>
                    Immediate Actions:
                  </Typography>
                  <List dense>
                    {report.immediate_actions && Array.isArray(report.immediate_actions) && report.immediate_actions.length > 0 ? (
                      report.immediate_actions.map((action, index) => (
                        <ListItem key={index}>
                          <ListItemIcon>
                            <CheckCircle color="success" />
                          </ListItemIcon>
                          <ListItemText primary={action} />
                        </ListItem>
                      ))
                    ) : (
                      <ListItem>
                        <ListItemIcon>
                          <Info color="info" />
                        </ListItemIcon>
                        <ListItemText primary="No immediate actions required" />
                      </ListItem>
                    )}
                  </List>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mb: 1 }}>
                    Long-term Recommendations:
                  </Typography>
                  <List dense>
                    {report.long_term_recommendations && Array.isArray(report.long_term_recommendations) && report.long_term_recommendations.length > 0 ? (
                      report.long_term_recommendations.map((rec, index) => (
                        <ListItem key={index}>
                          <ListItemIcon>
                            <Assessment color="primary" />
                          </ListItemIcon>
                          <ListItemText primary={rec} />
                        </ListItem>
                      ))
                    ) : (
                      <ListItem>
                        <ListItemIcon>
                          <Info color="info" />
                        </ListItemIcon>
                        <ListItemText primary="Implement WAF and monitoring" />
                      </ListItem>
                    )}
                  </List>
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Related Log Entries */}
          {report.related_log_entries && Array.isArray(report.related_log_entries) && report.related_log_entries.length > 0 && (
            <Card sx={{ mb: 3 }}>
              <CardContent>
                <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
                  <DataUsage sx={{ mr: 1 }} />
                  📋 Related Log Entries
                </Typography>
                <TableContainer component={Paper} sx={{ maxHeight: 400 }}>
                  <Table stickyHeader size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Timestamp</TableCell>
                        <TableCell>IP Address</TableCell>
                        <TableCell>Method</TableCell>
                        <TableCell>Path</TableCell>
                        <TableCell>Status</TableCell>
                        <TableCell>Size</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {(report.related_log_entries || []).slice(0, 10).map((entry, index) => (
                        <TableRow key={index} hover>
                          <TableCell>{entry.timestamp}</TableCell>
                          <TableCell>{entry.ip_address}</TableCell>
                          <TableCell>
                            <Chip 
                              label={entry.method} 
                              size="small" 
                              color={entry.method === 'GET' ? 'primary' : 'secondary'}
                            />
                          </TableCell>
                          <TableCell sx={{ maxWidth: 200, wordBreak: 'break-word' }}>
                            {entry.path}
                          </TableCell>
                          <TableCell>
                            <Chip 
                              label={entry.status_code} 
                              size="small" 
                              color={entry.status_code >= 400 ? 'error' : 'success'}
                            />
                          </TableCell>
                          <TableCell>{formatNumber(entry.response_size)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </CardContent>
            </Card>
          )}
        </>
      )}

      {!report && !loading && selectedFileId && (
        <Card>
          <CardContent>
            <Typography variant="h6" color="text.secondary" textAlign="center">
              No analysis data available for the selected file
            </Typography>
          </CardContent>
        </Card>
      )}
    </Box>
  );
};

export default Analysis;
