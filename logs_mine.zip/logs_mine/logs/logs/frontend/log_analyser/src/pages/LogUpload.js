import React, { useState, useCallback } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  LinearProgress,
  Alert,
  Chip,
  Grid,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Paper,
  IconButton,
  CircularProgress,
} from '@mui/material';
import {
  CloudUpload,
  Description,
  CheckCircle,
  Error,
  Upload,
  Delete,
} from '@mui/icons-material';
import { useDropzone } from 'react-dropzone';
import { logFilesAPI, formatFileSize } from '../services/api';

const LogUpload = () => {
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState('');

  const onDrop = useCallback(async (acceptedFiles) => {
    setError('');
    setIsUploading(true);

    for (const file of acceptedFiles) {
      const fileId = Math.random().toString(36).substr(2, 9);
      const newFile = {
        id: fileId,
        name: file.name,
        size: file.size,
        type: file.type,
        status: 'uploading',
        progress: 0,
        file: file,
      };

      setUploadedFiles((prev) => [...prev, newFile]);

      try {
        // Upload file to backend (this also processes and analyzes the file)
        const response = await logFilesAPI.upload(file);
        
        setUploadedFiles((prev) =>
          prev.map((f) =>
            f.id === fileId
              ? {
                  ...f,
                  status: 'completed',
                  progress: 100,
                  logFileId: response.data.log_file_id,
                  analysisResult: {
                    risk_score: response.data.risk_score,
                    suspicious_activities_count: response.data.suspicious_activities_count,
                    processed_lines: response.data.processed_lines,
                  },
                }
              : f
          )
        );
      } catch (err) {
        console.error('Upload error:', err);
        // Fallback: check if the file actually got created server-side
        try {
          const listResp = await logFilesAPI.list();
          const items = Array.isArray(listResp.data) ? listResp.data : (listResp.data?.results || []);
          const found = items.find((lf) => lf.filename === file.name);
          if (found) {
            setUploadedFiles((prev) =>
              prev.map((f) =>
                f.id === fileId
                  ? {
                      ...f,
                      status: 'completed',
                      progress: 100,
                      logFileId: found.id,
                    }
                  : f
              )
            );
            continue; // Skip setting error below
          }
        } catch (_) {}

        setUploadedFiles((prev) =>
          prev.map((f) =>
            f.id === fileId
              ? { ...f, status: 'error', progress: 0 }
              : f
          )
        );
        setError('Failed to upload file. Please try again.');
      }
    }

    setIsUploading(false);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/plain': ['.log'],
      'application/json': ['.json'],
      'text/csv': ['.csv'],
    },
    multiple: true,
  });

  const removeFile = (fileId) => {
    setUploadedFiles((prev) => prev.filter((file) => file.id !== fileId));
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'success';
      case 'error':
        return 'error';
      case 'analyzing':
        return 'warning';
      default:
        return 'warning';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle />;
      case 'error':
        return <Error />;
      case 'analyzing':
        return <CircularProgress size={16} />;
      default:
        return <Upload />;
    }
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ color: 'text.primary', mb: 3 }}>
        Upload Log Files
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ color: 'text.primary' }}>
                Upload Log Files
              </Typography>
              
              <Paper
                {...getRootProps()}
                sx={{
                  border: '2px dashed',
                  borderColor: isDragActive ? 'primary.main' : 'divider',
                  borderRadius: 2,
                  p: 4,
                  textAlign: 'center',
                  cursor: 'pointer',
                  backgroundColor: isDragActive ? 'action.hover' : 'background.paper',
                  transition: 'all 0.2s ease',
                  '&:hover': {
                    borderColor: 'primary.main',
                    backgroundColor: 'action.hover',
                  },
                }}
              >
                <input {...getInputProps()} />
                <CloudUpload sx={{ fontSize: 48, color: 'primary.main', mb: 2 }} />
                <Typography variant="h6" gutterBottom sx={{ color: 'text.primary' }}>
                  {isDragActive
                    ? 'Drop the files here...'
                    : 'Drag & drop log files here, or click to select'}
                </Typography>
                <Typography variant="body2" color="textSecondary">
                  Supported formats: .log, .json, .csv
                </Typography>
                <Button
                  variant="contained"
                  sx={{ mt: 2 }}
                  onClick={(e) => e.stopPropagation()}
                  disabled={isUploading}
                >
                  Browse Files
                </Button>
              </Paper>

              <Alert severity="info" sx={{ mt: 2 }}>
                <Typography variant="body2">
                  <strong>Supported log formats:</strong> Apache, Nginx, Django, and custom log formats.
                  Files will be automatically analyzed for suspicious activities.
                </Typography>
              </Alert>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ color: 'text.primary' }}>
                Upload Statistics
              </Typography>
              
              <Box sx={{ mt: 2 }}>
                <Box display="flex" justifyContent="space-between" mb={1}>
                  <Typography variant="body2">Total Files</Typography>
                  <Typography variant="body2">{uploadedFiles.length}</Typography>
                </Box>
                <Box display="flex" justifyContent="space-between" mb={1}>
                  <Typography variant="body2">Completed</Typography>
                  <Typography variant="body2">
                    {uploadedFiles.filter((f) => f.status === 'completed').length}
                  </Typography>
                </Box>
                <Box display="flex" justifyContent="space-between" mb={1}>
                  <Typography variant="body2">Failed</Typography>
                  <Typography variant="body2">
                    {uploadedFiles.filter((f) => f.status === 'error').length}
                  </Typography>
                </Box>
                <Box display="flex" justifyContent="space-between">
                  <Typography variant="body2">In Progress</Typography>
                  <Typography variant="body2">
                    {uploadedFiles.filter((f) => f.status === 'uploading' || f.status === 'analyzing').length}
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Uploaded Files List */}
      {uploadedFiles.length > 0 && (
        <Card sx={{ mt: 3 }}>
          <CardContent>
            <Typography variant="h6" gutterBottom sx={{ color: 'text.primary' }}>
              Uploaded Files
            </Typography>
            
            <List>
              {uploadedFiles.map((file) => (
                <ListItem
                  key={file.id}
                  sx={{
                    border: '1px solid',
                    borderColor: 'divider',
                    borderRadius: 1,
                    mb: 1,
                  }}
                >
                  <ListItemIcon>
                    <Description />
                  </ListItemIcon>
                  <ListItemText
                    primary={file.name}
                    secondary={`${formatFileSize(file.size)} • ${file.type}`}
                  />
                  <Box display="flex" alignItems="center" gap={1}>
                    <Chip
                      label={file.status}
                      color={getStatusColor(file.status)}
                      size="small"
                      icon={getStatusIcon(file.status)}
                    />
                    {file.analysisResult && (
                      <Chip
                        label={`Risk: ${(file.analysisResult.risk_score * 100).toFixed(1)}%`}
                        color={file.analysisResult.risk_score > 0.5 ? 'error' : 'success'}
                        size="small"
                      />
                    )}
                    <IconButton
                      size="small"
                      onClick={() => removeFile(file.id)}
                      color="error"
                    >
                      <Delete />
                    </IconButton>
                  </Box>
                </ListItem>
              ))}
            </List>

            {uploadedFiles.some((f) => f.status === 'uploading' || f.status === 'analyzing') && (
              <Box sx={{ mt: 2 }}>
                <Typography variant="body2" gutterBottom>
                  Upload Progress
                </Typography>
                {uploadedFiles
                  .filter((f) => f.status === 'uploading' || f.status === 'analyzing')
                  .map((file) => (
                    <Box key={file.id} sx={{ mb: 1 }}>
                      <Box display="flex" justifyContent="space-between" mb={0.5}>
                        <Typography variant="body2">{file.name}</Typography>
                        <Typography variant="body2">{Math.round(file.progress)}%</Typography>
                      </Box>
                      <LinearProgress variant="determinate" value={file.progress} />
                    </Box>
                  ))}
              </Box>
            )}
          </CardContent>
        </Card>
      )}
    </Box>
  );
};

export default LogUpload;
