import axios from 'axios';

// Create axios instance with base configuration
const api = axios.create({
  baseURL: 'http://localhost:8000/api',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true,
});

// Basic response passthrough
api.interceptors.response.use(
  (response) => response,
  (error) => Promise.reject(error)
);

// Removed authentication APIs (login/logout/profile/register)

// Log Files API
export const logFilesAPI = {
  list: (params) => api.get('/log-files/', { params }),
  upload: (file, logType) => {
    const formData = new FormData();
    formData.append('file', file);
    if (logType) {
      formData.append('log_type', logType);
    }
    return api.post('/upload/', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      withCredentials: true,
    });
  },

  get: (id) => api.get(`/log-files/${id}/`),
  analysisReport: (id) => api.get(`/log-files/${id}/analysis_report/`),
  delete: (id) => api.delete(`/log-files/${id}/`),
};

// Log Entries API
export const logEntriesAPI = {
  list: (params) => api.get('/log-entries/', { params }),
  search: (params) => api.get('/log-entries/search/', { params }),
  get: (id) => api.get(`/log-entries/${id}/`),
};

// Dashboard API
export const dashboardAPI = {
  getStats: () => api.get('/dashboard/'),
  deleteAll: () => api.delete('/log-files/delete-all/?delete_from_db=false'),
};

// Suspicious Activities API
export const suspiciousActivitiesAPI = {
  list: (params) => api.get('/suspicious-activities/', { params }),
  get: (id) => api.get(`/suspicious-activities/${id}/`),
  resolve: (id, notes) => api.post(`/suspicious-activities/${id}/resolve/`, { notes }),
};



// Reports API
export const reportsAPI = {
  list: () => api.get('/reports/'),
  generate: (params) => api.post('/reports/', params),
  download: (id) => api.get(`/reports/${id}/download/`, { responseType: 'blob' }),
};



// Utility functions
export const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export const formatDate = (dateString) => {
  return new Date(dateString).toLocaleString();
};

export const getStatusColor = (status) => {
  switch (status) {
    case 'completed':
      return 'success';
    case 'processing':
      return 'warning';
    case 'error':
      return 'error';
    default:
      return 'default';
  }
};

export default api;
