from celery import shared_task
from django.utils import timezone
import os
import time
from django.db.models import Q

from logs.models import LogFile, LogEntry, SuspiciousActivity
from logs.parsers import LogParserFactory
from ml.security_analyzer import SecurityAnalyzer




@shared_task
def process_log_file(log_file_id):
    """Process uploaded log file asynchronously"""
    try:
        log_file = LogFile.objects.get(id=log_file_id)
        log_file.status = 'processing'
        log_file.save()
        
        start_time = time.time()
        
        # Read file content
        with open(log_file.file.path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # Auto-detect log type if not specified
        if log_file.log_type == 'unknown':
            parser_factory = LogParserFactory()
            detected_type = parser_factory.detect_log_type(content)
            log_file.log_type = detected_type
            log_file.save()
        
        # Parse log entries
        parser_factory = LogParserFactory()
        parser = parser_factory.get_parser(log_file.log_type)
        
        if not parser:
            log_file.status = 'failed'
            log_file.save()
            return False
        
        # Stream and process up to a fixed cap of 10,000 lines
        processed_count = 0
        error_count = 0
        max_lines_to_process = 10000

        with open(log_file.file.path, 'r', encoding='utf-8', errors='ignore') as fin:
            for line_index, line in enumerate(fin, start=1):
                if line_index > max_lines_to_process:
                    break
                if line.strip():
                    try:
                        parsed_entry = parser.parse_line(line)
                        if parsed_entry:
                            LogEntry.objects.create(
                                log_file=log_file,
                                timestamp=parsed_entry.timestamp,
                                ip_address=parsed_entry.ip_address,
                                method=parsed_entry.method,
                                path=parsed_entry.path,
                                status_code=parsed_entry.status_code,
                                response_size=parsed_entry.response_size,
                                user_agent=parsed_entry.user_agent,
                                referer=parsed_entry.referer,
                                raw_log=parsed_entry.raw_log
                            )
                            processed_count += 1
                        else:
                            error_count += 1
                    except Exception as e:
                        error_count += 1
                        print(f"Error processing line: {e}")

                # Periodically persist progress
                if line_index % 1000 == 0:
                    log_file.processed_lines = processed_count
                    log_file.error_lines = error_count
                    log_file.save()

        # Set total_lines to the cap processed during this run
        log_file.total_lines = processed_count + error_count
        log_file.save()
        
        # Mark as processed
        log_file.status = 'processed'
        log_file.processed_at = timezone.now()
        log_file.save()
        
        # Trigger analysis
        analyze_log_file.delay(log_file_id)
        
        processing_time = time.time() - start_time
        print(f"Processed {processed_count} entries in {processing_time:.2f} seconds")
        
        return True
        
    except Exception as e:
        print(f"Error processing log file {log_file_id}: {e}")
        try:
            log_file = LogFile.objects.get(id=log_file_id)
            log_file.status = 'failed'
            log_file.save()
        except:
            pass
        return False


@shared_task
def analyze_log_file(log_file_id):
    """Analyze log file for suspicious activities"""
    try:
        log_file = LogFile.objects.get(id=log_file_id)
        
        # Get log entries
        entries = log_file.entries.all()
        if not entries.exists():
            return False
        
        # Convert to dict format for analyzer
        entries_data = []
        for entry in entries:
            entries_data.append({
                'ip_address': entry.ip_address,
                'method': entry.method,
                'path': entry.path,
                'status_code': entry.status_code,
                'response_size': entry.response_size,
                'user_agent': entry.user_agent,
                'referer': entry.referer,
                'timestamp': entry.timestamp.isoformat(),
            })
        
        # Analyze logs
        analyzer = SecurityAnalyzer()
        analysis_result = analyzer.analyze_logs(entries_data, str(log_file.id))
        
        # Create suspicious activities
        for pattern in analysis_result.suspicious_activities:
            # Find related log entries
            related_entries = entries.filter(
                Q(path__icontains=pattern.pattern_type) |
                Q(user_agent__icontains=pattern.pattern_type)
            )[:10]  # Limit to 10 entries
            
            suspicious_activity = SuspiciousActivity.objects.create(
                log_file=log_file,
                activity_type=pattern.pattern_type,
                severity=pattern.severity,
                description=pattern.description,
                confidence_score=pattern.confidence,
                detection_method='pattern_matching',
                patterns_found=pattern.evidence,
                affected_ips=list(set(entries_data[i]['ip_address'] for i in range(len(entries_data)) if pattern.pattern_type in str(entries_data[i]))),
                affected_paths=list(set(entries_data[i]['path'] for i in range(len(entries_data)) if pattern.pattern_type in entries_data[i]['path'])),
            )
            
            # Add related log entries
            suspicious_activity.log_entries.set(related_entries)
        
        # Update log file stats
        log_file.suspicious_activities_count = len(analysis_result.suspicious_activities)
        log_file.risk_score = analysis_result.risk_score
        log_file.save()
        

        
        return True
        
    except Exception as e:
        print(f"Error analyzing log file {log_file_id}: {e}")
        return False





@shared_task
def cleanup_old_files():
    """Clean up old log files and entries"""
    try:
        # Delete log files older than 30 days
        cutoff_date = timezone.now() - timezone.timedelta(days=30)
        old_files = LogFile.objects.filter(uploaded_at__lt=cutoff_date)
        
        for log_file in old_files:
            # Delete associated entries
            log_file.entries.all().delete()
            
            # Delete the file
            if os.path.exists(log_file.file.path):
                os.remove(log_file.file.path)
            
            # Delete the database record
            log_file.delete()
        
        print(f"Cleaned up {old_files.count()} old log files")
        return True
        
    except Exception as e:
        print(f"Error in cleanup task: {e}")
        return False


@shared_task
def generate_report(report_data):
    """Generate analysis report"""
    try:
        # This would generate PDF/CSV reports
        # For now, just return success
        return True
        
    except Exception as e:
        print(f"Error generating report: {e}")
        return False



