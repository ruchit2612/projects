from rest_framework import serializers
from django.contrib.auth.models import User
from logs.models import LogFile, LogEntry, AnalysisResult, SuspiciousActivity, Report


class UserSerializer(serializers.ModelSerializer):
    """Serializer for User model"""
    
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'date_joined']
        read_only_fields = ['id', 'date_joined']


class LogEntrySerializer(serializers.ModelSerializer):
    """Serializer for LogEntry model"""
    filename = serializers.CharField(source='log_file.filename', read_only=True)
    
    class Meta:
        model = LogEntry
        fields = [
            'id', 'timestamp', 'ip_address', 'method', 'path', 'status_code',
            'response_size', 'user_agent', 'referer', 'country', 'city',
            'latitude', 'longitude', 'is_suspicious', 'risk_score',
            'suspicious_patterns', 'raw_log', 'filename'
        ]
        read_only_fields = ['id', 'is_suspicious', 'risk_score', 'suspicious_patterns', 'filename']


class LogFileSerializer(serializers.ModelSerializer):
    """Serializer for LogFile model"""
    entries_count = serializers.SerializerMethodField()
    file_size_mb = serializers.SerializerMethodField()
    user = UserSerializer(read_only=True)
    
    class Meta:
        model = LogFile
        fields = [
            'id', 'user', 'file', 'filename', 'file_size', 'file_size_mb',
            'log_type', 'status', 'total_lines', 'processed_lines', 'error_lines',
            'uploaded_at', 'processed_at', 'suspicious_activities_count',
            'risk_score', 'entries_count', 'file_content'
        ]
        read_only_fields = [
            'id', 'filename', 'file_size', 'total_lines', 'processed_lines',
            'error_lines', 'uploaded_at', 'processed_at', 'suspicious_activities_count',
            'risk_score', 'entries_count', 'file_content'
        ]
    
    def get_entries_count(self, obj):
        """Get count of log entries"""
        return obj.entries.count()
    
    def get_file_size_mb(self, obj):
        """Get file size in MB"""
        return obj.get_file_size_mb()


class AnalysisResultSerializer(serializers.ModelSerializer):
    """Serializer for AnalysisResult model"""
    
    class Meta:
        model = AnalysisResult
        fields = [
            'id', 'log_file', 'analysis_type', 'results', 'confidence_score',
            'model_used', 'created_at', 'processing_time'
        ]
        read_only_fields = ['id', 'created_at']


class SuspiciousActivitySerializer(serializers.ModelSerializer):
    """Serializer for SuspiciousActivity model"""
    log_entries = LogEntrySerializer(many=True, read_only=True)
    
    class Meta:
        model = SuspiciousActivity
        fields = [
            'id', 'log_file', 'log_entries', 'activity_type', 'severity',
            'description', 'confidence_score', 'detection_method', 'patterns_found',
            'affected_ips', 'affected_paths', 'first_detected', 'last_updated',
            'is_resolved', 'resolved_at', 'resolution_notes'
        ]
        read_only_fields = ['id', 'first_detected', 'last_updated']





class LogUploadSerializer(serializers.Serializer):
    """Serializer for log file upload"""
    file = serializers.FileField()
    log_type = serializers.ChoiceField(
        choices=LogFile.LOG_TYPES,
        required=False,
        help_text="Auto-detected if not provided"
    )


class LogAnalysisSerializer(serializers.Serializer):
    """Serializer for log analysis request"""
    log_file_id = serializers.IntegerField()
    analysis_type = serializers.ChoiceField(
        choices=AnalysisResult.ANALYSIS_TYPES,
        required=False
    )


class DashboardStatsSerializer(serializers.Serializer):
    """Serializer for dashboard statistics"""
    total_log_files = serializers.IntegerField()
    total_entries = serializers.IntegerField()
    suspicious_activities = serializers.IntegerField()
    risk_score_avg = serializers.FloatField()
    top_ips = serializers.ListField()
    top_paths = serializers.ListField()
    status_code_distribution = serializers.DictField()
    recent_activities = serializers.ListField()


class SearchFilterSerializer(serializers.Serializer):
    """Serializer for search and filter parameters"""
    ip_address = serializers.CharField(required=False)
    status_code = serializers.CharField(required=False)
    method = serializers.CharField(required=False)
    path = serializers.CharField(required=False)
    date_from = serializers.DateTimeField(required=False)
    date_to = serializers.DateTimeField(required=False)
    is_suspicious = serializers.BooleanField(required=False)
    log_file_id = serializers.IntegerField(required=False)
    page = serializers.IntegerField(default=1)
    page_size = serializers.IntegerField(default=50)


class ReportGenerationSerializer(serializers.Serializer):
    """Serializer for report generation"""
    log_file_id = serializers.IntegerField(required=False)
    date_from = serializers.DateTimeField(required=False)
    date_to = serializers.DateTimeField(required=False)
    report_type = serializers.ChoiceField(
        choices=[('pdf', 'PDF'), ('csv', 'CSV')],
        default='pdf'
    )
    include_charts = serializers.BooleanField(default=True)
    include_recommendations = serializers.BooleanField(default=True)


class ReportSerializer(serializers.ModelSerializer):
    """Serializer for Report model"""
    
    class Meta:
        model = Report
        fields = [
            'id', 'name', 'report_type', 'status', 'log_file', 'date_from', 'date_to',
            'include_charts', 'include_recommendations', 'report_file', 'file_size',
            'created_at', 'completed_at', 'processing_time', 'total_entries',
            'suspicious_activities_count', 'risk_score_avg'
        ]
        read_only_fields = [
            'id', 'created_at', 'completed_at', 'processing_time', 'file_size',
            'total_entries', 'suspicious_activities_count', 'risk_score_avg'
        ]



