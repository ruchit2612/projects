from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    LogFileViewSet, LogEntryViewSet, SuspiciousActivityViewSet,
    DashboardView, ReportView, ReportDownloadView, LogUploadView,
    DeleteAllLogsView,
)

router = DefaultRouter()
router.register(r'log-files', LogFileViewSet, basename='log-files')
router.register(r'log-entries', LogEntryViewSet, basename='log-entries')
router.register(r'suspicious-activities', SuspiciousActivityViewSet, basename='suspicious-activities')


urlpatterns = [
    # Put explicit paths BEFORE router include to avoid conflicts with detail routes
    path('upload/', LogUploadView.as_view(), name='upload'),
    path('log-files/delete-all/', DeleteAllLogsView.as_view(), name='delete_all_logs'),
    path('dashboard/', DashboardView.as_view(), name='dashboard'),
    path('reports/', ReportView.as_view(), name='reports'),
    path('reports/<int:pk>/', ReportView.as_view(), name='report_detail'),
    path('reports/<int:pk>/download/', ReportDownloadView.as_view(), name='report_download'),

    

    
    path('', include(router.urls)),
]
