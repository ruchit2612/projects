from django.contrib.auth.models import User
from django.contrib.auth import get_user
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.conf import settings

class DemoAuthMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # For demo purposes, auto-authenticate as admin user
        if not request.user.is_authenticated:
            try:
                admin_user = User.objects.get(username='admin')
                request.user = admin_user
            except User.DoesNotExist:
                # Create admin user if it doesn't exist
                admin_user = User.objects.create_user(
                    username='admin',
                    email='admin@example.com',
                    password='admin'
                )
                request.user = admin_user
        
        # Handle file uploads and POST requests
        if request.method == 'POST' and 'multipart/form-data' in request.content_type:
            # Ensure user is authenticated for file uploads
            if not request.user.is_authenticated:
                try:
                    admin_user = User.objects.get(username='admin')
                    request.user = admin_user
                except User.DoesNotExist:
                    admin_user = User.objects.create_user(
                        username='admin',
                        email='admin@example.com',
                        password='admin'
                    )
                    request.user = admin_user
        
        response = self.get_response(request)
        return response


class CSRFExemptMiddleware:
    """Middleware to exempt certain URLs from CSRF protection"""
    
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Check if the URL should be exempt from CSRF
        if hasattr(settings, 'CSRF_EXEMPT_URLS'):
            for exempt_url in settings.CSRF_EXEMPT_URLS:
                if request.path.startswith(exempt_url):
                    setattr(request, '_dont_enforce_csrf_checks', True)
                    break
        
        response = self.get_response(request)
        return response
