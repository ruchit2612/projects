from rest_framework import viewsets, status, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView
 
from django.contrib.auth.models import User
from django.db.models import Q, Count, Avg
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from datetime import datetime, timedelta
import json
import os

from .serializers import (
    LogFileSerializer, LogEntrySerializer, AnalysisResultSerializer,
    SuspiciousActivitySerializer, LogUploadSerializer,
    LogAnalysisSerializer, DashboardStatsSerializer, SearchFilterSerializer,
    ReportGenerationSerializer, ReportSerializer
)
from logs.models import LogFile, LogEntry, AnalysisResult, SuspiciousActivity, Report
from logs.parsers import LogParserFactory
from ml.security_analyzer import SecurityAnalyzer



class AllowAnyPermission(permissions.BasePermission):
    """Custom permission class that allows any request"""
    def has_permission(self, request, view):
        return True


@method_decorator(csrf_exempt, name='dispatch')
class LogUploadView(APIView):
    """Custom upload view that bypasses CSRF"""
    permission_classes = [AllowAnyPermission]
    
    def post(self, request):
        """Upload and process log file"""
        # Ensure user is authenticated
        if not request.user.is_authenticated:
            try:
                admin_user = User.objects.get(username='admin')
                request.user = admin_user
            except User.DoesNotExist:
                admin_user = User.objects.create_user(
                    username='admin',
                    email='admin@example.com',
                    password='admin'
                )
                request.user = admin_user
        
        serializer = LogUploadSerializer(data=request.data)
        if serializer.is_valid():
            uploaded_file = serializer.validated_data['file']
            log_type = serializer.validated_data.get('log_type')
            
            # Create LogFile instance
            log_file = LogFile.objects.create(
                user=request.user,
                file=uploaded_file,
                filename=uploaded_file.name,
                file_size=uploaded_file.size,
                log_type=log_type or 'unknown'
            )
            
            # Process the file immediately (synchronous processing for demo)
            try:
                self.process_log_file(log_file)
                return Response(
                    {
                        'message': 'File uploaded and processed successfully', 
                        'log_file_id': log_file.id,
                        'status': log_file.status,
                        'processed_lines': log_file.processed_lines,
                        'suspicious_activities_count': log_file.suspicious_activities_count,
                        'risk_score': log_file.risk_score
                    },
                    status=status.HTTP_201_CREATED
                )
            except Exception as e:
                log_file.status = 'failed'
                log_file.save()
                return Response(
                    {'error': f'Failed to process file: {str(e)}'},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def process_log_file(self, log_file):
        """Process uploaded log file"""
        log_file.status = 'processing'
        log_file.save()
        
        # Read file content
        with open(log_file.file.path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # Save file content to database
        log_file.file_content = content
        log_file.save()
        
        # Auto-detect log type if not specified
        if log_file.log_type == 'unknown':
            parser_factory = LogParserFactory()
            detected_type = parser_factory.detect_log_type(content)
            log_file.log_type = detected_type
            log_file.save()
        
        # Parse log entries
        parser_factory = LogParserFactory()
        parser = parser_factory.get_parser(log_file.log_type)
        
        if not parser:
            log_file.status = 'failed'
            log_file.save()
            raise Exception(f"Unsupported log type: {log_file.log_type}")
        
        # Parse all lines
        lines = content.split('\n')
        log_file.total_lines = len(lines)
        log_file.save()
        
        processed_count = 0
        error_count = 0
        
        # Process lines
        for line in lines:
            if line.strip():
                try:
                    parsed_entry = parser.parse_line(line)
                    if parsed_entry:
                        # Create LogEntry
                        LogEntry.objects.create(
                            log_file=log_file,
                            timestamp=parsed_entry.timestamp,
                            ip_address=parsed_entry.ip_address,
                            method=parsed_entry.method,
                            path=parsed_entry.path,
                            status_code=parsed_entry.status_code,
                            response_size=parsed_entry.response_size,
                            user_agent=parsed_entry.user_agent,
                            referer=parsed_entry.referer,
                            raw_log=parsed_entry.raw_log
                        )
                        processed_count += 1
                    else:
                        error_count += 1
                except Exception as e:
                    error_count += 1
                    print(f"Error processing line: {e}")
        
        # Update progress
        log_file.processed_lines = processed_count
        log_file.error_lines = error_count
        log_file.status = 'processed'
        log_file.processed_at = timezone.now()
        log_file.save()
        
        # Analyze the log file
        self.analyze_log_file(log_file)
        
        return True
    
    def analyze_log_file(self, log_file):
        """Analyze log file for suspicious activities"""
        # Get log entries
        entries = log_file.entries.all()
        if not entries.exists():
            return False
        
        # Convert to dict format for analyzer
        entries_data = []
        for entry in entries:
            entries_data.append({
                'ip_address': entry.ip_address,
                'method': entry.method,
                'path': entry.path,
                'status_code': entry.status_code,
                'response_size': entry.response_size,
                'user_agent': entry.user_agent,
                'referer': entry.referer,
                'timestamp': entry.timestamp.isoformat(),
            })
        
        # Analyze logs
        analyzer = SecurityAnalyzer()
        analysis_result = analyzer.analyze_logs(entries_data, str(log_file.id))
        
        # Create suspicious activities from security events
        for event in analysis_result.security_events:
            # Find related log entries
            related_entries = entries.filter(
                Q(path__icontains=event.type) |
                Q(user_agent__icontains=event.type)
            )[:10]  # Limit to 10 entries
            
            # Find affected IPs and paths for this event
            affected_ips = event.source_ips
            affected_paths = event.affected_paths
            
            suspicious_activity = SuspiciousActivity.objects.create(
                log_file=log_file,
                activity_type=event.type,
                severity=event.severity,
                description=event.description,
                confidence_score=event.confidence,
                detection_method=event.detection_method,
                patterns_found=event.evidence,
                affected_ips=affected_ips,
                affected_paths=affected_paths,
            )
            
            # Add related log entries
            suspicious_activity.log_entries.set(related_entries)
        
        # Save analysis result
        AnalysisResult.objects.create(
            log_file=log_file,
            analysis_type='suspicious_activity',
            results={
                'security_events': [
                    {
                        'type': event.type,
                        'description': event.description,
                        'severity': event.severity,
                        'confidence': event.confidence,
                        'evidence': event.evidence
                    } for event in analysis_result.security_events
                ],
                'attack_patterns': analysis_result.attack_patterns_detected,
                'suspicious_ips': analysis_result.suspicious_ips,
                'recommendations': analysis_result.long_term_recommendations
            },
            confidence_score=analysis_result.risk_score,
            model_used='SecurityAnalyzer'
        )
        
        # Update log file stats
        log_file.suspicious_activities_count = len(analysis_result.security_events)
        log_file.risk_score = analysis_result.risk_score
        log_file.save()
        
        return True


 


class LogFileViewSet(viewsets.ModelViewSet):
    """ViewSet for LogFile model"""
    serializer_class = LogFileSerializer
    permission_classes = [AllowAnyPermission]  # Allow any request for demo
    
    def get_queryset(self):
        """Filter queryset by current user and exclude deleted files"""
        if self.request.user.is_authenticated:
            return LogFile.objects.filter(user=self.request.user).exclude(status='deleted')
        else:
            # For demo purposes, return all log files if user is not authenticated
            return LogFile.objects.all().exclude(status='deleted')
    
    @method_decorator(csrf_exempt)
    def destroy(self, request, *args, **kwargs):
        """Delete a log file from filesystem but keep database record"""
        try:
            # Get the object including deleted files for deletion
            pk = self.kwargs.get('pk')
            # For testing purposes, allow access to any file if user is not authenticated
            if self.request.user.is_authenticated:
                log_file = LogFile.objects.filter(user=self.request.user, id=pk).first()
            else:
                # For demo/testing, allow access to any file
                log_file = LogFile.objects.filter(id=pk).first()
            
            if not log_file:
                return Response({'error': 'Log file not found'}, status=status.HTTP_404_NOT_FOUND)
            
            log_file_id = log_file.id
            
            # Delete file from filesystem only
            if log_file.file and hasattr(log_file.file, 'path'):
                try:
                    if os.path.exists(log_file.file.path):
                        os.remove(log_file.file.path)
                        print(f"Deleted file from filesystem: {log_file.file.path}")
                except Exception as e:
                    print(f"Warning: Could not delete file {log_file.file.path}: {e}")
            
            # Keep database record but mark as deleted
            log_file.status = 'deleted'
            log_file.save()
            
            return Response({
                'message': f'Successfully deleted file from filesystem. Database record preserved.',
                'log_file_id': log_file_id,
                'database_record_preserved': True
            }, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': f'Failed to delete log file: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    @method_decorator(csrf_exempt)
    @action(detail=False, methods=['post'])
    def upload(self, request):
        """Upload and process log file"""
        # Ensure user is authenticated
        if not request.user.is_authenticated:
            try:
                admin_user = User.objects.get(username='admin')
                request.user = admin_user
            except User.DoesNotExist:
                admin_user = User.objects.create_user(
                    username='admin',
                    email='admin@example.com',
                    password='admin'
                )
                request.user = admin_user
        
        serializer = LogUploadSerializer(data=request.data)
        if serializer.is_valid():
            uploaded_file = serializer.validated_data['file']
            log_type = serializer.validated_data.get('log_type')
            
            # Create LogFile instance
            log_file = LogFile.objects.create(
                user=request.user,
                file=uploaded_file,
                filename=uploaded_file.name,
                file_size=uploaded_file.size,
                log_type=log_type or 'unknown'
            )
            
            # Process the file immediately (synchronous processing for demo)
            try:
                self.process_log_file(log_file)
                return Response(
                    {
                        'message': 'File uploaded and processed successfully', 
                        'log_file_id': log_file.id,
                        'status': log_file.status,
                        'processed_lines': log_file.processed_lines,
                        'suspicious_activities_count': log_file.suspicious_activities_count,
                        'risk_score': log_file.risk_score
                    },
                    status=status.HTTP_201_CREATED
                )
            except Exception as e:
                log_file.status = 'failed'
                log_file.save()
                return Response(
                    {'error': f'Failed to process file: {str(e)}'},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def process_log_file(self, log_file):
        """Process uploaded log file"""
        log_file.status = 'processing'
        log_file.save()
        
        # Read file content
        with open(log_file.file.path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # Save file content to database
        log_file.file_content = content
        log_file.save()
        
        # Auto-detect log type if not specified
        if log_file.log_type == 'unknown':
            parser_factory = LogParserFactory()
            detected_type = parser_factory.detect_log_type(content)
            log_file.log_type = detected_type
            log_file.save()
        
        # Parse log entries
        parser_factory = LogParserFactory()
        parser = parser_factory.get_parser(log_file.log_type)
        
        if not parser:
            log_file.status = 'failed'
            log_file.save()
            raise Exception(f"Unsupported log type: {log_file.log_type}")
        
        # Parse all lines
        lines = content.split('\n')
        log_file.total_lines = len(lines)
        log_file.save()
        
        processed_count = 0
        error_count = 0
        
        # Process lines
        for line in lines:
            if line.strip():
                try:
                    parsed_entry = parser.parse_line(line)
                    if parsed_entry:
                        # Create LogEntry
                        LogEntry.objects.create(
                            log_file=log_file,
                            timestamp=parsed_entry.timestamp,
                            ip_address=parsed_entry.ip_address,
                            method=parsed_entry.method,
                            path=parsed_entry.path,
                            status_code=parsed_entry.status_code,
                            response_size=parsed_entry.response_size,
                            user_agent=parsed_entry.user_agent,
                            referer=parsed_entry.referer,
                            raw_log=parsed_entry.raw_log
                        )
                        processed_count += 1
                    else:
                        error_count += 1
                except Exception as e:
                    error_count += 1
                    print(f"Error processing line: {e}")
        
        # Update progress
        log_file.processed_lines = processed_count
        log_file.error_lines = error_count
        log_file.status = 'processed'
        log_file.processed_at = timezone.now()
        log_file.save()
        
        # Analyze the log file
        self.analyze_log_file(log_file)
        
        return True
    
    def analyze_log_file(self, log_file):
        """Analyze log file for suspicious activities"""
        # Get log entries
        entries = log_file.entries.all()
        if not entries.exists():
            return False
        
        # Convert to dict format for analyzer
        entries_data = []
        for entry in entries:
            entries_data.append({
                'ip_address': entry.ip_address,
                'method': entry.method,
                'path': entry.path,
                'status_code': entry.status_code,
                'response_size': entry.response_size,
                'user_agent': entry.user_agent,
                'referer': entry.referer,
                'timestamp': entry.timestamp.isoformat(),
            })
        
        # Analyze logs with SecurityAnalyzer
        try:
            analyzer = SecurityAnalyzer()
            analysis_result = analyzer.analyze_logs(entries_data, str(log_file.id))
        except Exception as e:
            print(f"ML analysis error: {e}")
            # Create empty analysis result
            from dataclasses import dataclass
            @dataclass
            class EmptyAnalysisResult:
                log_id = str(log_file.id)
                generated_at = timezone.now().isoformat()
                summary = "No analysis performed"
                highest_severity = "low"
                requires_immediate_attention = False
                total_requests = 0
                unique_ips = 0
                time_range = {"start": "", "end": ""}
                risk_score = 0.0
                security_events = []
                traffic_patterns = []
                suspicious_activity_log = []
                top_ips = []
                suspicious_ips = []
                geo_distribution = {}
                attack_patterns_detected = []
                vulnerability_indicators = []
                immediate_actions = []
                long_term_recommendations = []
                escalation_reasoning = []
                related_log_entries = []
            
            analysis_result = EmptyAnalysisResult()
        
        # Save analysis result
        AnalysisResult.objects.create(
            log_file=log_file,
            analysis_type='suspicious_activity',
            results={
                'security_events': [
                    {
                        'type': event.type,
                        'description': event.description,
                        'severity': event.severity,
                        'confidence': event.confidence,
                        'evidence': event.evidence
                    } for event in analysis_result.security_events
                ],
                'attack_patterns': analysis_result.attack_patterns_detected,
                'suspicious_ips': analysis_result.suspicious_ips,
                'recommendations': analysis_result.long_term_recommendations
            },
            confidence_score=analysis_result.risk_score,
            model_used='SecurityAnalyzer'
        )
        
        # Update log file stats
        log_file.suspicious_activities_count = len(analysis_result.security_events)
        log_file.risk_score = analysis_result.risk_score
        log_file.save()
        
        return True

    @action(detail=True, methods=['get'])
    def analysis_report(self, request, pk=None):
        """Get detailed analysis report for a log file"""
        try:
            # Get log file by ID directly to avoid queryset issues
            try:
                log_file = LogFile.objects.get(id=pk)
            except LogFile.DoesNotExist:
                return Response(
                    {'error': 'Log file not found'},
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Get log entries
            entries = log_file.entries.all()
            if not entries.exists():
                return Response(
                    {'error': 'No log entries found for this file'},
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Convert to dict format for analyzer
            entries_data = []
            for entry in entries:
                entries_data.append({
                    'ip_address': entry.ip_address,
                    'method': entry.method,
                    'path': entry.path,
                    'status_code': entry.status_code,
                    'response_size': entry.response_size,
                    'user_agent': entry.user_agent,
                    'referer': entry.referer,
                    'timestamp': entry.timestamp.isoformat(),
                })
            
            # Analyze logs with SecurityAnalyzer
            try:
                analyzer = SecurityAnalyzer()
                analysis_result = analyzer.analyze_logs(entries_data, str(log_file.id))
            except Exception as e:
                print(f"ML analysis error: {e}")
                # Create empty analysis result
                from dataclasses import dataclass
                @dataclass
                class EmptyAnalysisResult:
                    log_id = str(log_file.id)
                    generated_at = timezone.now().isoformat()
                    summary = "No analysis performed"
                    highest_severity = "low"
                    requires_immediate_attention = False
                    total_requests = 0
                    unique_ips = 0
                    time_range = {"start": "", "end": ""}
                    risk_score = 0.0
                    security_events = []
                    traffic_patterns = []
                    suspicious_activity_log = []
                    top_ips = []
                    suspicious_ips = []
                    geo_distribution = {}
                    attack_patterns_detected = []
                    vulnerability_indicators = []
                    immediate_actions = []
                    long_term_recommendations = []
                    escalation_reasoning = []
                    related_log_entries = []
                
                analysis_result = EmptyAnalysisResult()
            
            # Convert dataclass objects to dictionaries for JSON serialization
            def convert_dataclass_to_dict(obj):
                if hasattr(obj, '__dict__'):
                    result = {}
                    for key, value in obj.__dict__.items():
                        if hasattr(value, '__dict__'):
                            result[key] = convert_dataclass_to_dict(value)
                        elif isinstance(value, list):
                            result[key] = [convert_dataclass_to_dict(item) if hasattr(item, '__dict__') else item for item in value]
                        else:
                            result[key] = value
                    return result
                return obj
            
            # Prepare response data
            response_data = {
                'log_file_id': log_file.id,
                'filename': log_file.filename,
                'total_entries': len(entries_data),
                'analysis_timestamp': timezone.now().isoformat(),
                'security_events': [convert_dataclass_to_dict(event) for event in analysis_result.security_events],
                'traffic_patterns': [convert_dataclass_to_dict(pattern) for pattern in analysis_result.traffic_patterns],
                'attack_patterns': analysis_result.attack_patterns_detected,
                'suspicious_ips': analysis_result.suspicious_ips,
                'risk_score': analysis_result.risk_score,
                'recommendations': analysis_result.long_term_recommendations,
                'summary': analysis_result.summary,
                'highest_severity': analysis_result.highest_severity,
                'requires_immediate_attention': analysis_result.requires_immediate_attention,
                'immediate_actions': analysis_result.immediate_actions,
                'top_ips': analysis_result.top_ips,
                'geo_distribution': analysis_result.geo_distribution,
                'vulnerability_indicators': analysis_result.vulnerability_indicators,
                'long_term_recommendations': analysis_result.long_term_recommendations,
                'escalation_reasoning': analysis_result.escalation_reasoning,
                'related_log_entries': analysis_result.related_log_entries,
                'total_requests': analysis_result.total_requests,
                'unique_ips': analysis_result.unique_ips,
                'time_range': analysis_result.time_range,
                'suspicious_activity_log': analysis_result.suspicious_activity_log
            }
            
            return Response(response_data, status=status.HTTP_200_OK)
            
        except Exception as e:
            return Response(
                {'error': f'Failed to generate analysis report: {str(e)}'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class LogEntryViewSet(viewsets.ReadOnlyModelViewSet):
    """ViewSet for LogEntry model"""
    serializer_class = LogEntrySerializer
    permission_classes = [AllowAnyPermission]
    
    def get_queryset(self):
        """Filter queryset by user's log files and exclude deleted files"""
        return LogEntry.objects.filter(log_file__user=self.request.user, log_file__status__in=['uploaded', 'processing', 'processed', 'failed'])
    
    @action(detail=False, methods=['get'])
    def search(self, request):
        """Search and filter log entries"""
        serializer = SearchFilterSerializer(data=request.query_params)
        if serializer.is_valid():
            queryset = self.get_queryset()
            
            # Apply filters
            if serializer.validated_data.get('ip_address'):
                queryset = queryset.filter(ip_address__icontains=serializer.validated_data['ip_address'])
            
            if serializer.validated_data.get('status_code'):
                queryset = queryset.filter(status_code__icontains=serializer.validated_data['status_code'])
            
            if serializer.validated_data.get('method'):
                queryset = queryset.filter(method=serializer.validated_data['method'])
            
            if serializer.validated_data.get('path'):
                queryset = queryset.filter(path__icontains=serializer.validated_data['path'])
            
            if serializer.validated_data.get('date_from'):
                queryset = queryset.filter(timestamp__gte=serializer.validated_data['date_from'])
            
            if serializer.validated_data.get('date_to'):
                queryset = queryset.filter(timestamp__lte=serializer.validated_data['date_to'])
            
            if serializer.validated_data.get('is_suspicious') is not None:
                queryset = queryset.filter(is_suspicious=serializer.validated_data['is_suspicious'])
            
            if serializer.validated_data.get('log_file_id'):
                queryset = queryset.filter(log_file_id=serializer.validated_data['log_file_id'])
            
            # Pagination
            page = serializer.validated_data.get('page', 1)
            page_size = serializer.validated_data.get('page_size', 50)
            start = (page - 1) * page_size
            end = start + page_size
            
            entries = queryset[start:end]
            serializer = LogEntrySerializer(entries, many=True)
            
            return Response({
                'results': serializer.data,
                'total': queryset.count(),
                'page': page,
                'page_size': page_size
            })
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class DashboardView(APIView):
    """Dashboard statistics view"""
    permission_classes = [AllowAnyPermission]
    
    def get(self, request):
        """Get dashboard statistics"""
        user = request.user
        
        # Basic stats - exclude deleted files
        total_log_files = LogFile.objects.filter(user=user).exclude(status='deleted').count()
        total_entries = LogEntry.objects.filter(log_file__user=user, log_file__status__in=['uploaded', 'processing', 'processed', 'failed']).count()
        suspicious_activities = SuspiciousActivity.objects.filter(log_file__user=user, log_file__status__in=['uploaded', 'processing', 'processed', 'failed']).count()
        risk_score_avg = LogFile.objects.filter(user=user).exclude(status='deleted').aggregate(Avg('risk_score'))['risk_score__avg'] or 0
        
        # Top IPs - exclude deleted files
        top_ips = LogEntry.objects.filter(log_file__user=user, log_file__status__in=['uploaded', 'processing', 'processed', 'failed'])\
            .values('ip_address')\
            .annotate(count=Count('id'))\
            .order_by('-count')[:10]
        
        # Top paths - exclude deleted files
        top_paths = LogEntry.objects.filter(log_file__user=user, log_file__status__in=['uploaded', 'processing', 'processed', 'failed'])\
            .values('path')\
            .annotate(count=Count('id'))\
            .order_by('-count')[:10]
        
        # Status code distribution - exclude deleted files
        status_distribution = LogEntry.objects.filter(log_file__user=user, log_file__status__in=['uploaded', 'processing', 'processed', 'failed'])\
            .values('status_code')\
            .annotate(count=Count('id'))
        
        # Recent activities - exclude deleted files
        recent_activities = SuspiciousActivity.objects.filter(log_file__user=user, log_file__status__in=['uploaded', 'processing', 'processed', 'failed'])\
            .order_by('-first_detected')[:5]
        
        # Attack types analysis - aggregate from all analysis results
        attack_types_stats = {
            'brute_force_login': 0,
            'sql_injection': 0,
            'xss': 0,
            'directory_traversal': 0,
            'command_injection': 0,
            'high_request_rate': 0,
            'access_hidden_admin': 0,
            'suspicious_http_methods': 0
        }
        
        # Get all analysis results for this user's log files - exclude deleted files
        analysis_results = AnalysisResult.objects.filter(log_file__user=user, log_file__status__in=['uploaded', 'processing', 'processed', 'failed'])
        for result in analysis_results:
            if result.results and 'security_events' in result.results:
                security_events = result.results['security_events']
                if isinstance(security_events, list):
                    for event in security_events:
                        event_type = event.get('type', '').lower()
                        if 'brute_force' in event_type:
                            attack_types_stats['brute_force_login'] += 1
                        elif 'sql' in event_type:
                            attack_types_stats['sql_injection'] += 1
                        elif 'xss' in event_type:
                            attack_types_stats['xss'] += 1
                        elif 'directory' in event_type:
                            attack_types_stats['directory_traversal'] += 1
                        elif 'command' in event_type:
                            attack_types_stats['command_injection'] += 1
                        elif 'high_request' in event_type:
                            attack_types_stats['high_request_rate'] += 1
                        elif 'access_hidden' in event_type:
                            attack_types_stats['access_hidden_admin'] += 1
                        elif 'suspicious_http' in event_type:
                            attack_types_stats['suspicious_http_methods'] += 1
        
        return Response({
            'total_log_files': total_log_files,
            'total_entries': total_entries,
            'suspicious_activities': suspicious_activities,
            'risk_score_avg': round(risk_score_avg, 2),
            'top_ips': list(top_ips),
            'top_paths': list(top_paths),
            'status_code_distribution': {item['status_code']: item['count'] for item in status_distribution},
            'recent_activities': SuspiciousActivitySerializer(recent_activities, many=True).data,
            'attack_types_stats': attack_types_stats
        })


class SuspiciousActivityViewSet(viewsets.ReadOnlyModelViewSet):
    """ViewSet for SuspiciousActivity model"""
    serializer_class = SuspiciousActivitySerializer
    permission_classes = [AllowAnyPermission]
    
    def get_queryset(self):
        """Filter queryset by user's log files and exclude deleted files"""
        return SuspiciousActivity.objects.filter(log_file__user=self.request.user, log_file__status__in=['uploaded', 'processing', 'processed', 'failed'])
    
    @action(detail=True, methods=['post'])
    def resolve(self, request, pk=None):
        """Mark suspicious activity as resolved"""
        try:
            activity = self.get_object()
            activity.is_resolved = True
            activity.resolved_at = timezone.now()
            activity.resolution_notes = request.data.get('notes', '')
            activity.save()
            
            return Response({'message': 'Activity marked as resolved'})
        except SuspiciousActivity.DoesNotExist:
            return Response(
                {'error': 'Suspicious activity not found'},
                status=status.HTTP_404_NOT_FOUND
            )





@method_decorator(csrf_exempt, name='dispatch')
class ReportView(APIView):
    """Report generation view"""
    permission_classes = [AllowAnyPermission]
    
    def dispatch(self, request, *args, **kwargs):
        """Override dispatch to handle CSRF exemption"""
        return super().dispatch(request, *args, **kwargs)
    
    def get(self, request, pk=None):
        """List all reports for the user or get specific report"""
        try:
            if not request.user.is_authenticated:
                admin_user = User.objects.get(username='admin')
                request.user = admin_user
            
            if pk:
                # Get specific report
                report = Report.objects.get(id=pk, user=request.user)
                serializer = ReportSerializer(report)
                return Response(serializer.data)
            else:
                # List all reports
                reports = Report.objects.filter(user=request.user).exclude(status='deleted')
                serializer = ReportSerializer(reports, many=True)
                return Response(serializer.data)
        except Report.DoesNotExist:
            return Response(
                {'error': 'Report not found'},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {'error': f'Failed to fetch reports: {str(e)}'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def post(self, request):
        """Generate report"""
        try:
            if not request.user.is_authenticated:
                admin_user = User.objects.get(username='admin')
                request.user = admin_user
            
            serializer = ReportGenerationSerializer(data=request.data)
            if serializer.is_valid():
                data = serializer.validated_data
                
                # Create report record
                report_name = f"Security Analysis Report - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
                if data.get('log_file_id'):
                    try:
                        log_file = LogFile.objects.get(id=data['log_file_id'], user=request.user)
                        report_name = f"Report for {log_file.filename} - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
                    except LogFile.DoesNotExist:
                        return Response(
                            {'error': 'Log file not found'},
                            status=status.HTTP_404_NOT_FOUND
                        )
                
                report = Report.objects.create(
                    user=request.user,
                    name=report_name,
                    report_type=data['report_type'],
                    log_file_id=data.get('log_file_id'),
                    date_from=None,
                    date_to=None,
                    include_charts=False,
                    include_recommendations=False,
                    status='processing'
                )
                
                # Generate report asynchronously (for now, we'll do it synchronously)
                try:
                    self.generate_report(report)
                    return Response({
                        'message': 'Report generated successfully',
                        'report_id': report.id,
                        'download_url': f'/api/reports/{report.id}/download/'
                    }, status=status.HTTP_201_CREATED)
                except Exception as e:
                    report.status = 'failed'
                    report.save()
                    return Response(
                        {'error': f'Failed to generate report: {str(e)}'},
                        status=status.HTTP_500_INTERNAL_SERVER_ERROR
                    )

            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response(
                {'error': f'Failed to create report: {str(e)}'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def generate_report(self, report):
        """Generate the actual report file"""
        import csv
        import io
        from datetime import datetime
        
        start_time = timezone.now()
        
        try:
            # Get data for the report
            if report.log_file:
                # Single file report
                log_entries = LogEntry.objects.filter(log_file=report.log_file)
                suspicious_activities = SuspiciousActivity.objects.filter(log_file=report.log_file)
                analysis_results = AnalysisResult.objects.filter(log_file=report.log_file)
            else:
                # All files report
                log_entries = LogEntry.objects.filter(log_file__user=report.user)
                suspicious_activities = SuspiciousActivity.objects.filter(log_file__user=report.user)
                analysis_results = AnalysisResult.objects.filter(log_file__user=report.user)
            
            # Apply date filters if provided
            if report.date_from:
                log_entries = log_entries.filter(timestamp__gte=report.date_from)
                suspicious_activities = suspicious_activities.filter(first_detected__gte=report.date_from)
                analysis_results = analysis_results.filter(created_at__gte=report.date_from)
            
            if report.date_to:
                log_entries = log_entries.filter(timestamp__lte=report.date_to)
                suspicious_activities = suspicious_activities.filter(first_detected__lte=report.date_to)
                analysis_results = analysis_results.filter(created_at__lte=report.date_to)
            
            # Calculate summary statistics
            total_entries = log_entries.count()
            suspicious_count = suspicious_activities.count()
            risk_score_avg = log_entries.aggregate(Avg('risk_score'))['risk_score__avg'] or 0.0
            
            # Update report with summary data
            report.total_entries = total_entries
            report.suspicious_activities_count = suspicious_count
            report.risk_score_avg = risk_score_avg
            
            # Generate report based on type
            if report.report_type == 'csv':
                report_file = self.generate_csv_report(log_entries, suspicious_activities, analysis_results)
            elif report.report_type == 'pdf':  # PDF
                report_file = self.generate_pdf_report(log_entries, suspicious_activities, analysis_results)
            else:
                raise ValueError(f"Unsupported report type: {report.report_type}")
            
            # Save the generated file
            report.report_file.save(
                f"report_{report.id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.{report.report_type}",
                report_file
            )
            
            # Update file size
            if report.report_file:
                report.file_size = report.report_file.size
            
            # Calculate processing time
            end_time = timezone.now()
            processing_time = (end_time - start_time).total_seconds()
            
            report.status = 'completed'
            report.completed_at = end_time
            report.processing_time = processing_time
            report.save()
            
        except Exception as e:
            report.status = 'failed'
            report.save()
            raise e
    
    def generate_csv_report(self, log_entries, suspicious_activities, analysis_results):
        """Generate CSV report"""
        import csv
        import io
        
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write header
        writer.writerow(['Log Analysis Report'])
        writer.writerow(['Generated on', datetime.now().strftime('%Y-%m-%d %H:%M:%S')])
        writer.writerow([])
        
        # Summary section
        writer.writerow(['Summary'])
        writer.writerow(['Total Log Entries', log_entries.count()])
        writer.writerow(['Suspicious Activities', suspicious_activities.count()])
        writer.writerow(['Analysis Results', analysis_results.count()])
        writer.writerow([])
        
        # Suspicious activities (without confidence and first detected)
        if suspicious_activities.exists():
            writer.writerow(['Suspicious Activities'])
            writer.writerow(['Type', 'Severity', 'Description'])
            
            for activity in suspicious_activities:
                writer.writerow([
                    activity.activity_type,
                    activity.severity,
                    activity.description[:100]  # Truncate long descriptions
                ])
        
        output.seek(0)
        return io.BytesIO(output.getvalue().encode('utf-8'))
    

    
    def generate_pdf_report(self, log_entries, suspicious_activities, analysis_results):
        """Generate PDF report"""
        import io
        
        # For now, we'll create a simple text-based PDF
        # In a production environment, you'd use a proper PDF library like ReportLab or WeasyPrint
        
        # Create a simple HTML template and convert to PDF
        html_content = f"""
        <html>
        <head>
            <title>Security Analysis Report</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .header {{ text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }}
                .section {{ margin-bottom: 20px; }}
                .section h2 {{ color: #333; border-bottom: 1px solid #ccc; padding-bottom: 5px; }}
                table {{ width: 100%; border-collapse: collapse; margin-top: 10px; }}
                th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                th {{ background-color: #f2f2f2; }}
                .metric {{ font-weight: bold; color: #666; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Security Analysis Report</h1>
                <p>Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            </div>
            
            <div class="section">
                <h2>Executive Summary</h2>
                <p>This report provides a comprehensive analysis of security events detected in the log files.</p>
                <table>
                    <tr><td class="metric">Total Log Entries Analyzed:</td><td>{log_entries.count()}</td></tr>
                    <tr><td class="metric">Suspicious Activities Detected:</td><td>{suspicious_activities.count()}</td></tr>
                    <tr><td class="metric">Analysis Results Generated:</td><td>{analysis_results.count()}</td></tr>
                    <tr><td class="metric">Average Risk Score:</td><td>{round(log_entries.aggregate(Avg('risk_score'))['risk_score__avg'] or 0.0, 2)}</td></tr>
                </table>
            </div>
            
            <div class="section">
                <h2>Top Suspicious Activities</h2>
        """
        
        if suspicious_activities.exists():
            html_content += """
                <table>
                    <tr>
                        <th>Type</th>
                        <th>Severity</th>
                        <th>Description</th>
                    </tr>
            """
            
            for activity in suspicious_activities[:10]:  # Top 10
                html_content += f"""
                    <tr>
                        <td>{activity.activity_type}</td>
                        <td>{activity.severity}</td>
                        <td>{activity.description[:80]}...</td>
                    </tr>
                """
            
            html_content += "</table>"
        else:
            html_content += "<p>No suspicious activities detected.</p>"
        
        html_content += """
            </div>
            
            <div class="section">
                <h2>Recommendations</h2>
                <ul>
                    <li>Monitor high-risk IP addresses regularly</li>
                    <li>Implement rate limiting for suspicious patterns</li>
                    <li>Review and update security rules based on findings</li>
                    <li>Consider implementing additional logging for critical endpoints</li>
                </ul>
            </div>
        </body>
        </html>
        """
        
        # For now, return the HTML content as a text file
        # In production, you'd convert this to PDF using a library like WeasyPrint
        return io.BytesIO(html_content.encode('utf-8'))


@method_decorator(csrf_exempt, name='dispatch')
class ReportDownloadView(APIView):
    """Report download view"""
    permission_classes = [AllowAnyPermission]
    
    def get(self, request, pk):
        """Download a generated report"""
        try:
            if not request.user.is_authenticated:
                admin_user = User.objects.get(username='admin')
                request.user = admin_user
            
            report = Report.objects.get(id=pk, user=request.user)
            
            if report.status != 'completed':
                return Response(
                    {'error': 'Report is not ready for download'},
                    status=status.HTTP_400_BAD_REQUEST
                )
        
            if not report.report_file:
                return Response(
                    {'error': 'Report file not found'},
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Determine content type based on report type
            content_type_map = {
                'pdf': 'application/pdf',
                'csv': 'text/csv'
            }
            
            content_type = content_type_map.get(report.report_type, 'application/octet-stream')
            
            # Create response with file
            from django.http import FileResponse
            response = FileResponse(report.report_file, content_type=content_type)
            response['Content-Disposition'] = f'attachment; filename="{report.report_file.name}"'
            return response
            
        except Report.DoesNotExist:
            return Response(
                {'error': 'Report not found'},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {'error': f'Failed to download report: {str(e)}'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )





class DeleteAllLogsView(APIView):
    """View for deleting all log files"""
    permission_classes = [AllowAnyPermission]
    
    def delete(self, request):
        """Delete all log files from filesystem and optionally from database"""
        try:
            # Check if user wants to delete from database too
            delete_from_db = request.query_params.get('delete_from_db', 'true').lower() == 'true'
            
            # Get all log files to clean up file system
            log_files = LogFile.objects.all()
            deleted_count = 0
            db_deleted_count = 0
            
            # Clean up file system files and mark as deleted
            for log_file in log_files:
                try:
                    if log_file.file and hasattr(log_file.file, 'path'):
                        if os.path.exists(log_file.file.path):
                            os.remove(log_file.file.path)
                            deleted_count += 1
                            print(f"Deleted file from filesystem: {log_file.file.path}")
                except Exception as e:
                    print(f"Warning: Could not delete file {log_file.file.path}: {e}")
                
                # Mark as deleted in database (but keep the record)
                if not delete_from_db:
                    log_file.status = 'deleted'
                    log_file.save()
                    print(f"Marked file as deleted: {log_file.filename}")
            
            # Delete from database if requested
            if delete_from_db:
                db_deleted_count = LogFile.objects.count()
            LogFile.objects.all().delete()
            LogEntry.objects.all().delete()
            AnalysisResult.objects.all().delete()
            SuspiciousActivity.objects.all().delete()
            print(f"Deleted {db_deleted_count} records from database")
            
            message = f'Successfully deleted {deleted_count} log files from filesystem.'
            if delete_from_db:
                message += f' Deleted {db_deleted_count} records from database.'
            else:
                message += ' Database records preserved.'
            
            return Response({
                'message': message,
                'deleted_count': deleted_count,
                'database_records_deleted': delete_from_db,
                'db_deleted_count': db_deleted_count if delete_from_db else 0
            }, status=status.HTTP_200_OK)
            
        except Exception as e:
            return Response({
                'error': f'Failed to delete log files: {str(e)}'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
