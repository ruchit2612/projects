"""
Security-focused log analysis model for identifying potential threats and suspicious patterns.
"""

import re
import json
import ipaddress
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, asdict
from collections import Counter, defaultdict
from datetime import datetime, timezone
import numpy as np
from urllib.parse import unquote, parse_qs
import logging

logger = logging.getLogger(__name__)

@dataclass
class SecurityEvent:
    """Data class for security events"""
    event_id: str
    type: str
    description: str
    severity: str  # low, medium, high, critical
    confidence: float  # 0.0 to 1.0
    source_ips: List[str]
    affected_paths: List[str]
    url_patterns: List[str]
    detection_method: str
    timestamp_first: str
    timestamp_last: str
    evidence: List[str]
    attack_signatures: List[str]
    potential_impact: str
    immediate_actions: List[str]
    escalate: bool

@dataclass
class TrafficPattern:
    """Data class for traffic patterns"""
    method: str
    path: str
    hits: int
    unique_ips: int
    status_codes: Dict[str, int]
    avg_response_size: float
    is_suspicious: bool
    user_agents: List[str]

@dataclass
class AnalysisReport:
    """Comprehensive analysis report"""
    log_id: str
    generated_at: str
    summary: str
    highest_severity: str
    requires_immediate_attention: bool
    total_requests: int
    unique_ips: int
    time_range: Dict[str, str]
    risk_score: float  # Risk score from 0.0 to 1.0
    
    # Key findings
    security_events: List[SecurityEvent]
    traffic_patterns: List[TrafficPattern]
    suspicious_activity_log: List[Dict[str, Any]]
    
    # IP Analysis
    top_ips: List[Dict[str, Any]]
    suspicious_ips: List[Dict[str, Any]]
    geo_distribution: Dict[str, Any]
    
    # Attack analysis
    attack_patterns_detected: List[str]
    vulnerability_indicators: List[str]
    
    # Recommendations
    immediate_actions: List[str]
    long_term_recommendations: List[str]
    escalation_reasoning: List[str]
    
    # Related data
    related_log_entries: List[Dict[str, Any]]


class SecurityAnalyzer:
    """Advanced security-focused log analyzer"""
    
    def __init__(self):
        self.attack_patterns = self._load_attack_patterns()
        self.suspicious_paths = self._load_suspicious_paths()
        self.known_scanners = self._load_known_scanners()
        self.vulnerability_signatures = self._load_vulnerability_signatures()
        
    def _load_attack_patterns(self) -> Dict[str, Dict[str, Any]]:
        """Load attack pattern definitions for the 8 core attack types"""
        return {
            'brute_force_login': {
                'patterns': [
                    # Must have failed status code AND specific login endpoint in same log entry
                    r"(401|403|404).*(/login|/signin|/auth|/wp-login|/wp-admin/login)",
                    r"(/login|/signin|/auth|/wp-login|/wp-admin/login).*(401|403|404)",
                    # Failed authentication messages
                    r"(failed.*password|invalid.*password|incorrect.*password)",
                    r"(failed.*login|invalid.*login|incorrect.*login)",
                    r"(failed.*authentication|invalid.*authentication|incorrect.*authentication)",
                    # Multiple failed attempts indicators
                    r"(multiple.*failed.*attempts|too.*many.*failed.*attempts)",
                    r"(account.*locked|account.*suspended|too.*many.*failures)",
                ],
                'severity': 'high',
                'description': 'Brute force login attempt detected',
                'impact': 'Account compromise, unauthorized access, credential stuffing',
                'context_required': ['status_code', 'path', 'ip_frequency', 'authentication_failures']
            },
            
            'sql_injection': {
                'patterns': [
                    # SQL injection in query parameters - must be in URL or POST data
                    r"(\?.*=.*\b(union|select|insert|update|delete|drop|create|alter|exec|execute)\b)",
                    r"(\?.*=.*\b(and|or)\b\s+\d+\s*=\s*\d+)",
                    r"(\?.*=.*\b(and|or)\b\s+['\"].*['\"])",
                    r"(\?.*=.*\b(union|select)\b.*\bfrom\b)",
                    # Database-specific functions in parameters
                    r"(\?.*=.*benchmark\s*\()",
                    r"(\?.*=.*sleep\s*\()",
                    r"(\?.*=.*waitfor\s+delay)",
                    r"(\?.*=.*\bload_file\s*\()",
                    r"(\?.*=.*\binto\s+outfile\b)",
                    r"(\?.*=.*@@version|\?.*=.*@@datadir|\?.*=.*@@hostname)",
                    r"(\?.*=.*information_schema)",
                    r"(\?.*=.*pg_sleep|\?.*=.*pg_catalog)",
                    # Boolean-based injection in parameters
                    r"(\?.*=.*\'\s*(or|and)\s*\'\s*=\s*\')",
                    r"(\?.*=.*\"\s*(or|and)\s*\"\s*=\s*\")",
                    # Classic SQL injection patterns
                    r"(\?.*=.*\'\s*or\s*1\s*=\s*1)",
                    r"(\?.*=.*\'\s*or\s*\'\w\'\s*=\s*\'\w)",
                    r"(\?.*=.*\'\s*union\s+select)",
                    r"(\?.*=.*\'\s*and\s+1\s*=\s*1)",
                ],
                'severity': 'critical',
                'description': 'SQL injection attempt detected',
                'impact': 'Data breach, unauthorized database access, data manipulation',
                'context_required': ['query_parameters', 'path', 'url_analysis']
            },
            
            'xss': {
                'patterns': [
                    # XSS in query parameters - must be in URL parameters
                    r"(\?.*=.*<script[^>]*>.*?</script>)",
                    r"(\?.*=.*javascript:)",
                    r"(\?.*=.*on\w+\s*=)",
                    r"(\?.*=.*<iframe[^>]*>)",
                    r"(\?.*=.*<object[^>]*>)",
                    r"(\?.*=.*<embed[^>]*>)",
                    r"(\?.*=.*<link[^>]*>)",
                    r"(\?.*=.*<meta[^>]*http-equiv)",
                    # JavaScript functions in parameters
                    r"(\?.*=.*document\.cookie)",
                    r"(\?.*=.*document\.write)",
                    r"(\?.*=.*eval\s*\()",
                    r"(\?.*=.*String\.fromCharCode)",
                    r"(\?.*=.*unescape\s*\()",
                    # Classic XSS payloads
                    r"(\?.*=.*<script>alert\()",
                    r"(\?.*=.*<script>prompt\()",
                    r"(\?.*=.*<script>confirm\()",
                    r"(\?.*=.*<img.*onerror=)",
                    r"(\?.*=.*<svg.*onload=)",
                ],
                'severity': 'high',
                'description': 'Cross-site scripting (XSS) attempt detected',
                'impact': 'Session hijacking, credential theft, defacement',
                'context_required': ['query_parameters', 'path', 'url_analysis']
            },
            
            'directory_traversal': {
                'patterns': [
                    # Path traversal in URL path - must be in actual path
                    r"(/.*\.\./.*\.\./)",
                    r"(/.*\.\.\\\\.*\.\.\\)",
                    r"(/.*%2e%2e%2f.*%2e%2e%2f)",
                    r"(/.*%2e%2e%5c.*%2e%2e%5c)",
                    r"(/.*\.\.%2f.*\.\.%2f)",
                    r"(/.*\.\.%5c.*\.\.%5c)",
                    r"(/.*%252e%252e%252f)",
                    # Specific file types in traversal
                    r"(/.*\.\./.*\.(conf|ini|log|xml|properties|txt|bak))",
                    # Classic directory traversal patterns
                    r"(/.*\.\./.*\.\./.*\.\./)",
                    r"(/.*\.\./.*\.\./.*\.\./.*\.\./)",
                    r"(/.*\.\./.*\.\./.*\.\./.*\.\./.*\.\./)",
                    # Encoded traversal attempts
                    r"(/.*%2e%2e%2f.*%2e%2e%2f.*%2e%2e%2f)",
                    r"(/.*%252e%252e%252f.*%252e%252e%252f)",
                ],
                'severity': 'high',
                'description': 'Directory traversal attempt detected',
                'impact': 'Unauthorized file access, information disclosure',
                'context_required': ['path', 'url_analysis']
            },
            
            'command_injection': {
                'patterns': [
                    # Command injection in parameters - must be in URL parameters
                    r"(\?.*=.*;.*\b(cat|ls|pwd|whoami|id|ps|netstat|ifconfig)\b)",
                    r"(\?.*=.*\b(system|exec|eval|shell_exec|passthru|proc_open)\b)",
                    r"(\?.*=.*\$\(.*\))",
                    r"(\?.*=.*`[^`]+`)",
                    r"(\?.*=.*\|\s*(cat|ls|pwd|whoami|id))",
                    r"(\?.*=.*&&\s*(cat|ls|pwd|whoami|id))",
                    r"(\?.*=.*\b(wget|curl|nc|netcat)\b)",
                    r"(\?.*=.*/bin/(sh|bash|csh|ksh|zsh))",
                    r"(\?.*=.*cmd\.exe|\?.*=.*powershell\.exe)",
                    # Classic command injection patterns
                    r"(\?.*=.*\|\s*whoami)",
                    r"(\?.*=.*\|\s*id)",
                    r"(\?.*=.*\|\s*cat\s+/etc/passwd)",
                    r"(\?.*=.*\|\s*cat\s+/etc/shadow)",
                    r"(\?.*=.*\|\s*uname\s+-a)",
                ],
                'severity': 'critical',
                'description': 'Command injection attempt detected',
                'impact': 'Remote code execution, system compromise',
                'context_required': ['query_parameters', 'path', 'url_analysis']
            },
            
            'high_request_rate': {
                'patterns': [
                    # High request rate indicators - must be in specific context
                    r"(rate.*limit.*exceeded|frequency.*exceeded|burst.*detected)",
                    r"(throttle.*exceeded|throttling.*exceeded|rate.*control.*exceeded)",
                    r"(too.*many.*requests|request.*limit.*reached)",
                    r"(ddos.*detected|denial.*of.*service)",
                    r"(flood.*detected|spam.*detected)",
                ],
                'severity': 'medium',
                'description': 'High request rate (DoS) pattern detected',
                'impact': 'Denial of service, resource exhaustion, service degradation',
                'context_required': ['request_frequency', 'ip_behavior', 'rate_limiting']
            },
            
            'access_hidden_admin': {
                'patterns': [
                    # Admin paths with suspicious context - must have failed access
                    r"(/admin|/administrator|/wp-admin|/phpmyadmin|/cpanel|/webmail).*(401|403|404)",
                    r"(/config|/configuration|/settings|/setup|/install).*(401|403|404)",
                    r"(/\.env|/\.git|/\.svn|/\.htaccess|/\.htpasswd).*(401|403|404)",
                    r"(/backup|/db|/database|/sql|/dump).*(401|403|404)",
                    r"(/shell|/cmd|/backdoor|/webshell|/upload).*(401|403|404)",
                    r"(/api/|/rest/|/graphql|/soap|/console).*(401|403|404)",
                    # Specific admin access attempts
                    r"(/admin.*login|/administrator.*login|/wp-admin.*login)",
                    r"(/phpmyadmin.*login|/cpanel.*login|/webmail.*login)",
                    r"(/config.*access|/configuration.*access|/settings.*access)",
                    # Hidden file access attempts
                    r"(/\.env.*access|/\.git.*access|/\.svn.*access)",
                    r"(/\.htaccess.*access|/\.htpasswd.*access)",
                    # Simple admin path detection (for cases where status code might not be available)
                    r"\b(/admin|/administrator|/wp-admin|/phpmyadmin|/cpanel|/webmail)\b",
                    r"\b(/config|/configuration|/settings|/setup|/install)\b",
                ],
                'severity': 'medium',
                'description': 'Access attempt to hidden/admin areas detected',
                'impact': 'Information disclosure, unauthorized access, reconnaissance',
                'context_required': ['path', 'status_code', 'access_attempts']
            },
            
            'suspicious_http_methods': {
                'patterns': [
                    # Non-standard HTTP methods in actual requests
                    r"\b(PUT|DELETE|TRACE|OPTIONS|HEAD|CONNECT|PATCH)\b",
                    # Specific suspicious method patterns
                    r"\b(PUT|DELETE|TRACE|OPTIONS|HEAD|CONNECT|PATCH)\b.*(/admin|/config|/api)",
                    # Method with suspicious paths
                    r"\b(PUT|DELETE|TRACE|OPTIONS|HEAD|CONNECT|PATCH)\b.*\.(php|asp|jsp|do)",
                ],
                'severity': 'low',
                'description': 'Suspicious HTTP methods detected',
                'impact': 'API exploitation, unauthorized actions, reconnaissance',
                'context_required': ['http_method', 'request_line', 'path_analysis']
            }
        }
    
    def _load_suspicious_paths(self) -> List[str]:
        """Load suspicious path patterns for the 8 core attack types"""
        return [
            # Admin interfaces (for access_hidden_admin detection)
            r"/admin", r"/administrator", r"/wp-admin", r"/phpmyadmin",
            r"/cpanel", r"/webmail", r"/roundcube", r"/squirrelmail",
            
            # Configuration files (for access_hidden_admin detection)
            r"\.env", r"\.git/", r"\.svn/", r"\.htaccess", r"\.htpasswd",
            r"/config", r"/configuration", r"/settings",
            r"web\.config", r"application\.properties",
            
            # Backup files (for access_hidden_admin detection)
            r"\.bak", r"\.backup", r"\.old", r"\.orig", r"\.save",
            r"\.sql", r"\.dump", r"\.tar", r"\.zip",
            
            # Information disclosure (for access_hidden_admin detection)
            r"/robots\.txt", r"/sitemap\.xml", r"/crossdomain\.xml",
            r"/phpinfo", r"/info\.php", r"/test\.php",
            
            # Common vulnerabilities (for access_hidden_admin detection)
            r"/shell", r"/cmd", r"/backdoor", r"/c99", r"/r57",
            r"/webshell", r"/upload", r"/uploader",
            
            # API endpoints
            r"/api/", r"/rest/", r"/graphql", r"/soap",
            
            # Development/Debug
            r"/debug", r"/dev/", r"/test/", r"/staging/",
            r"/console", r"/trace", r"/actuator",
        ]
    
    def _load_known_scanners(self) -> List[str]:
        """Load known scanner user agents for the 8 core attack types"""
        return [
            r"nmap", r"masscan", r"zmap", r"nikto", r"dirb", r"dirbuster",
            r"gobuster", r"wfuzz", r"ffuf", r"sqlmap", r"burp", r"owasp",
            r"nessus", r"openvas", r"acunetix", r"appscan", r"w3af",
            r"skipfish", r"arachni", r"vega", r"grabber", r"paros",
            r"webscarab", r"ratproxy", r"grendel", r"n-stealth",
            r"libwww-perl", r"python-requests", r"curl", r"wget",
        ]
    
    def _load_vulnerability_signatures(self) -> Dict[str, List[str]]:
        """Load vulnerability-specific signatures for the 8 core attack types"""
        return {
            'sql_injection': [
                r"(\b(union|select|insert|update|delete|drop|create|alter|exec|execute)\b)",
                r"(\b(and|or)\b\s+\d+\s*=\s*\d+)",
                r"(\b(and|or)\b\s+['\"].*['\"])",
                r"(\b(union|select)\b.*\bfrom\b)",
                r"(@@version|@@datadir|@@hostname)",
                r"(information_schema)",
            ],
            'xss': [
                r"(<script[^>]*>.*?</script>)",
                r"(javascript:)",
                r"(on\w+\s*=)",
                r"(<iframe[^>]*>)",
                r"(document\.cookie)",
                r"(eval\s*\()",
            ],
            'directory_traversal': [
                r"(\.\./){2,}",
                r"(\.\.\\){2,}",
                r"(%2e%2e%2f){2,}",
                r"(%2e%2e%5c){2,}",
            ],
            'command_injection': [
                r"(;.*\b(cat|ls|pwd|whoami|id|ps|netstat|ifconfig)\b)",
                r"(\b(system|exec|eval|shell_exec|passthru|proc_open)\b)",
                r"(\$\(.*\))",
                r"(`[^`]+`)",
            ]
        }
    
    def analyze_logs(self, log_entries: List[Dict], log_id: str = None) -> AnalysisReport:
        """
        Main analysis method that produces a comprehensive security report
        """
        if not log_entries:
            return self._create_empty_report(log_id)
        
        logger.info(f"Starting security analysis for {len(log_entries)} log entries")
        
        # Extract metadata
        total_requests = len(log_entries)
        unique_ips = len(set(entry.get('ip_address', '') for entry in log_entries))
        time_range = self._get_time_range(log_entries)
        
        # Security event detection
        security_events = self._detect_security_events(log_entries)
        
        # Traffic pattern analysis
        traffic_patterns = self._analyze_traffic_patterns(log_entries)
        
        # IP analysis
        top_ips, suspicious_ips = self._analyze_ips(log_entries)
        geo_distribution = self._analyze_geo_distribution(log_entries)
        
        # Attack pattern detection
        attack_patterns = self._detect_attack_patterns(log_entries)
        vulnerability_indicators = self._check_vulnerability_indicators(log_entries)
        
        # Generate suspicious activity checklist
        suspicious_activity_log = self._generate_activity_checklist(
            security_events, attack_patterns, suspicious_ips
        )
        
        # Determine severity and escalation
        highest_severity = self._determine_highest_severity(security_events)
        requires_immediate_attention = highest_severity in ['high', 'critical']
        
        # Generate recommendations
        immediate_actions, long_term_recommendations = self._generate_recommendations(
            security_events, attack_patterns, suspicious_ips
        )
        
        # Escalation reasoning
        escalation_reasoning = self._generate_escalation_reasoning(
            security_events, attack_patterns, suspicious_ips
        )
        
        # Get related log entries for evidence
        related_log_entries = self._get_related_log_entries(log_entries, security_events)
        
        # Calculate risk score
        risk_score = self._calculate_risk_score(
            security_events, suspicious_ips, attack_patterns, total_requests
        )
        
        # Generate summary
        summary = self._generate_summary(
            total_requests, unique_ips, security_events, highest_severity
        )
        
        return AnalysisReport(
            log_id=log_id or f"LOGID-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            generated_at=datetime.now(timezone.utc).isoformat(),
            summary=summary,
            highest_severity=highest_severity,
            requires_immediate_attention=requires_immediate_attention,
            total_requests=total_requests,
            unique_ips=unique_ips,
            time_range=time_range,
            risk_score=risk_score,
            security_events=security_events,
            traffic_patterns=traffic_patterns,
            suspicious_activity_log=suspicious_activity_log,
            top_ips=top_ips,
            suspicious_ips=suspicious_ips,
            geo_distribution=geo_distribution,
            attack_patterns_detected=attack_patterns,
            vulnerability_indicators=vulnerability_indicators,
            immediate_actions=immediate_actions,
            long_term_recommendations=long_term_recommendations,
            escalation_reasoning=escalation_reasoning,
            related_log_entries=related_log_entries
        )
    
    def _create_empty_report(self, log_id: str) -> AnalysisReport:
        """Create empty report for no log entries"""
        return AnalysisReport(
            log_id=log_id or "EMPTY",
            generated_at=datetime.now(timezone.utc).isoformat(),
            summary="No log entries to analyze",
            highest_severity="none",
            requires_immediate_attention=False,
            total_requests=0,
            unique_ips=0,
            time_range={},
            risk_score=0.0,
            security_events=[],
            traffic_patterns=[],
            suspicious_activity_log=[],
            top_ips=[],
            suspicious_ips=[],
            geo_distribution={},
            attack_patterns_detected=[],
            vulnerability_indicators=[],
            immediate_actions=[],
            long_term_recommendations=[],
            escalation_reasoning=[],
            related_log_entries=[]
        )
    
    def _get_time_range(self, log_entries: List[Dict]) -> Dict[str, str]:
        """Extract time range from log entries"""
        timestamps = []
        for entry in log_entries:
            ts = entry.get('timestamp')
            if ts:
                try:
                    if isinstance(ts, str):
                        # Handle various timestamp formats
                        if ts.endswith('Z'):
                            dt = datetime.fromisoformat(ts.replace('Z', '+00:00'))
                        elif '+' in ts or '-' in ts[-6:]:
                            dt = datetime.fromisoformat(ts)
                        else:
                            dt = datetime.fromisoformat(ts + '+00:00')
                        timestamps.append(dt)
                except:
                    continue
        
        if timestamps:
            timestamps.sort()
            return {
                'start': timestamps[0].isoformat(),
                'end': timestamps[-1].isoformat(),
                'duration_hours': (timestamps[-1] - timestamps[0]).total_seconds() / 3600
            }
        return {}
    
    def _detect_security_events(self, log_entries: List[Dict]) -> List[SecurityEvent]:
        """Detect security events using pattern matching and time-window logic for DoS"""
        events = []
        event_counter = 1
        high_request_rate_detected = self._detect_high_request_rate(log_entries)
        high_request_rate_entries = []
        high_request_rate_ips = set()
        high_request_rate_paths = set()
        high_request_rate_evidence = []

        for attack_type, config in self.attack_patterns.items():
            matching_entries = []
            evidence = []
            source_ips = set()
            affected_paths = set()

            for entry in log_entries:
                path = unquote(entry.get('path', ''))
                user_agent = entry.get('user_agent', '')
                referer = entry.get('referer', '')
                method = entry.get('method', 'GET').upper()
                status_code = str(entry.get('status_code', 200))

                # Extract query string from path if it exists
                query_string = ''
                if '?' in path:
                    query_string = path.split('?', 1)[1]

                # Combine all text fields for pattern matching
                combined_text = f"{path} {user_agent} {referer} {query_string} {method} {status_code}".lower()

                for pattern in config['patterns']:
                    matches = re.findall(pattern, combined_text, re.IGNORECASE | re.MULTILINE)
                    if matches:
                        matching_entries.append(entry)
                        evidence.extend([str(match) for match in matches])
                        source_ips.add(entry.get('ip_address', ''))
                        affected_paths.add(entry.get('path', ''))
                        break

            # Special handling for high_request_rate: if detected by time-window, collect all entries for the top IP
            if attack_type == 'high_request_rate' and high_request_rate_detected:
                # Find the IP with the most requests
                ip_counts = Counter(entry.get('ip_address', '') for entry in log_entries)
                if ip_counts:
                    top_ip, top_count = ip_counts.most_common(1)[0]
                    # Collect all entries for this IP
                    high_request_rate_entries = [entry for entry in log_entries if entry.get('ip_address', '') == top_ip]
                    high_request_rate_ips = {top_ip}
                    high_request_rate_paths = set(entry.get('path', '') for entry in high_request_rate_entries)
                    high_request_rate_evidence = [f"{top_ip} made {top_count} requests"]
                    matching_entries = high_request_rate_entries
                    evidence = high_request_rate_evidence
                    source_ips = high_request_rate_ips
                    affected_paths = high_request_rate_paths

            if matching_entries:
                # Calculate confidence based on match count and pattern strength
                confidence = min(len(matching_entries) * 0.2 + 0.3, 1.0)

                # Determine severity
                base_severity = config['severity']
                if len(matching_entries) > 10:
                    severity = 'critical' if base_severity == 'high' else 'high'
                elif len(matching_entries) > 5:
                    severity = 'high' if base_severity == 'medium' else base_severity
                else:
                    severity = base_severity

                # For high_request_rate, if detected by time-window, severity should be at least 'high' if >100 requests
                if attack_type == 'high_request_rate' and high_request_rate_detected:
                    if len(matching_entries) > 100:
                        severity = 'high'
                    elif len(matching_entries) > 50:
                        severity = 'medium'
                    else:
                        severity = base_severity

                # Generate immediate actions
                immediate_actions = self._generate_event_actions(attack_type, len(matching_entries))

                # Determine escalation
                escalate = severity in ['high', 'critical'] or len(matching_entries) > 5

                event = SecurityEvent(
                    event_id=f"SEC-{event_counter:03d}",
                    type=attack_type,
                    description=f"{config['description']} ({len(matching_entries)} occurrences)",
                    severity=severity,
                    confidence=confidence,
                    source_ips=list(source_ips),
                    affected_paths=list(affected_paths)[:10],  # Limit for readability
                    url_patterns=self._extract_url_patterns(affected_paths),
                    detection_method="Pattern matching" if attack_type != 'high_request_rate' else "Time-window analysis",
                    timestamp_first=matching_entries[0].get('timestamp', '') if matching_entries else '',
                    timestamp_last=matching_entries[-1].get('timestamp', '') if matching_entries else '',
                    evidence=list(set(evidence))[:20],  # Limit evidence
                    attack_signatures=[attack_type],
                    potential_impact=config['impact'],
                    immediate_actions=immediate_actions,
                    escalate=escalate
                )

                events.append(event)
                event_counter += 1

        # If high_request_rate was detected by time-window but not by pattern, ensure event is created
        if high_request_rate_detected and not any(e.type == 'high_request_rate' for e in events):
            ip_counts = Counter(entry.get('ip_address', '') for entry in log_entries)
            if ip_counts:
                top_ip, top_count = ip_counts.most_common(1)[0]
                high_request_rate_entries = [entry for entry in log_entries if entry.get('ip_address', '') == top_ip]
                high_request_rate_ips = {top_ip}
                high_request_rate_paths = set(entry.get('path', '') for entry in high_request_rate_entries)
                high_request_rate_evidence = [f"{top_ip} made {top_count} requests"]
                confidence = min(len(high_request_rate_entries) * 0.2 + 0.3, 1.0)
                severity = 'high' if len(high_request_rate_entries) > 100 else 'medium'
                immediate_actions = self._generate_event_actions('high_request_rate', len(high_request_rate_entries))
                escalate = severity in ['high', 'critical'] or len(high_request_rate_entries) > 5
                event = SecurityEvent(
                    event_id=f"SEC-{event_counter:03d}",
                    type='high_request_rate',
                    description=f"High request rate (DoS) pattern detected ({len(high_request_rate_entries)} occurrences)",
                    severity=severity,
                    confidence=confidence,
                    source_ips=list(high_request_rate_ips),
                    affected_paths=list(high_request_rate_paths)[:10],
                    url_patterns=self._extract_url_patterns(high_request_rate_paths),
                    detection_method="Time-window analysis",
                    timestamp_first=high_request_rate_entries[0].get('timestamp', '') if high_request_rate_entries else '',
                    timestamp_last=high_request_rate_entries[-1].get('timestamp', '') if high_request_rate_entries else '',
                    evidence=list(set(high_request_rate_evidence))[:20],
                    attack_signatures=['high_request_rate'],
                    potential_impact=self.attack_patterns['high_request_rate']['impact'],
                    immediate_actions=immediate_actions,
                    escalate=escalate
                )
                events.append(event)
        return events
    
    def _analyze_traffic_patterns(self, log_entries: List[Dict]) -> List[TrafficPattern]:
        """Analyze traffic patterns for anomalies"""
        patterns = []
        
        # Group by method and path
        path_stats = defaultdict(lambda: {
            'hits': 0,
            'ips': set(),
            'status_codes': Counter(),
            'response_sizes': [],
            'user_agents': set(),
            'methods': set()
        })
        
        for entry in log_entries:
            path = entry.get('path', '')
            method = entry.get('method', 'GET')
            key = f"{method} {path}"
            
            path_stats[key]['hits'] += 1
            path_stats[key]['ips'].add(entry.get('ip_address', ''))
            path_stats[key]['status_codes'][entry.get('status_code', 200)] += 1
            path_stats[key]['response_sizes'].append(entry.get('response_size', 0))
            path_stats[key]['user_agents'].add(entry.get('user_agent', '')[:100])
            path_stats[key]['methods'].add(method)
        
        # Convert to TrafficPattern objects
        for key, stats in path_stats.items():
            method, path = key.split(' ', 1)
            
            # Determine if suspicious
            is_suspicious = self._is_suspicious_traffic_pattern(key, stats)
            
            avg_response_size = np.mean(stats['response_sizes']) if stats['response_sizes'] else 0
            
            pattern = TrafficPattern(
                method=method,
                path=path,
                hits=stats['hits'],
                unique_ips=len(stats['ips']),
                status_codes=dict(stats['status_codes']),
                avg_response_size=avg_response_size,
                is_suspicious=is_suspicious,
                user_agents=list(stats['user_agents'])[:5]  # Limit for readability
            )
            patterns.append(pattern)
        
        # Sort by hits and return top patterns
        patterns.sort(key=lambda x: x.hits, reverse=True)
        return patterns[:20]
    
    def _is_suspicious_traffic_pattern(self, key: str, stats: Dict) -> bool:
        """Determine if a traffic pattern is suspicious"""
        method, path = key.split(' ', 1)
        
        # Check against suspicious paths
        for suspicious_pattern in self.suspicious_paths:
            if re.search(suspicious_pattern, path, re.IGNORECASE):
                return True
        
        # High error rate
        total_requests = stats['hits']
        error_requests = sum(count for code, count in stats['status_codes'].items() if code >= 400)
        if error_requests / total_requests > 0.8:
            return True
        
        # Unusual methods
        if method not in ['GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'OPTIONS']:
            return True
        
        # Single IP with many requests
        if len(stats['ips']) == 1 and total_requests > 50:
            return True
        
        return False
    
    def _analyze_ips(self, log_entries: List[Dict]) -> Tuple[List[Dict], List[Dict]]:
        """Analyze IP addresses for suspicious behavior"""
        ip_stats = defaultdict(lambda: {
            'requests': 0,
            'paths': set(),
            'status_codes': Counter(),
            'user_agents': set(),
            'methods': set(),
            'timestamps': [],
            'response_sizes': []
        })
        
        for entry in log_entries:
            ip = entry.get('ip_address', '')
            if ip:
                ip_stats[ip]['requests'] += 1
                ip_stats[ip]['paths'].add(entry.get('path', ''))
                ip_stats[ip]['status_codes'][entry.get('status_code', 200)] += 1
                ip_stats[ip]['user_agents'].add(entry.get('user_agent', ''))
                ip_stats[ip]['methods'].add(entry.get('method', 'GET'))
                ip_stats[ip]['timestamps'].append(entry.get('timestamp', ''))
                ip_stats[ip]['response_sizes'].append(entry.get('response_size', 0))
        
        # Sort IPs by request count
        sorted_ips = sorted(ip_stats.items(), key=lambda x: x[1]['requests'], reverse=True)
        
        top_ips = []
        suspicious_ips = []
        
        for ip, stats in sorted_ips[:20]:  # Top 20 IPs
            ip_data = {
                'ip': ip,
                'requests': stats['requests'],
                'unique_paths': len(stats['paths']),
                'status_codes': dict(stats['status_codes']),
                'unique_user_agents': len(stats['user_agents']),
                'methods': list(stats['methods']),
                'avg_response_size': np.mean(stats['response_sizes']) if stats['response_sizes'] else 0
            }
            
            top_ips.append(ip_data)
            
            # Check if suspicious
            if self._is_suspicious_ip(ip, stats):
                suspicion_reasons = self._get_ip_suspicion_reasons(ip, stats)
                ip_data['suspicion_reasons'] = suspicion_reasons
                suspicious_ips.append(ip_data)
        
        return top_ips, suspicious_ips
    
    def _is_suspicious_ip(self, ip: str, stats: Dict) -> bool:
        """Determine if an IP is suspicious"""
        # High request volume
        if stats['requests'] > 1000:
            return True
        
        # High error rate
        total_requests = stats['requests']
        error_requests = sum(count for code, count in stats['status_codes'].items() if code >= 400)
        if error_requests / total_requests > 0.7:
            return True
        
        # Scanner-like user agents
        for ua in stats['user_agents']:
            for scanner in self.known_scanners:
                if re.search(scanner, ua.lower()):
                    return True
        
        # Accessing many different paths
        if len(stats['paths']) > 100:
            return True
        
        # Rapid requests (if timestamps available)
        if len(stats['timestamps']) > 10:
            try:
                timestamps = [datetime.fromisoformat(ts.replace('Z', '+00:00')) 
                            for ts in stats['timestamps'] if ts]
                if len(timestamps) > 1:
                    timestamps.sort()
                    time_diffs = [(timestamps[i] - timestamps[i-1]).total_seconds() 
                                for i in range(1, min(11, len(timestamps)))]
                    avg_interval = np.mean(time_diffs)
                    if avg_interval < 0.5:  # Less than 0.5 seconds between requests
                        return True
            except:
                pass
        
        return False
    
    def _get_ip_suspicion_reasons(self, ip: str, stats: Dict) -> List[str]:
        """Get specific reasons why an IP is suspicious"""
        reasons = []
        
        if stats['requests'] > 1000:
            reasons.append(f"High request volume: {stats['requests']} requests")
        
        total_requests = stats['requests']
        error_requests = sum(count for code, count in stats['status_codes'].items() if code >= 400)
        error_rate = error_requests / total_requests
        if error_rate > 0.7:
            reasons.append(f"High error rate: {error_rate:.1%}")
        
        for ua in stats['user_agents']:
            for scanner in self.known_scanners:
                if re.search(scanner, ua.lower()):
                    reasons.append(f"Scanner-like user agent: {ua[:50]}")
                    break
        
        if len(stats['paths']) > 100:
            reasons.append(f"Accessing many paths: {len(stats['paths'])} unique paths")
        
        return reasons
    
    def _analyze_geo_distribution(self, log_entries: List[Dict]) -> Dict[str, Any]:
        """Analyze geographic distribution of requests"""
        country_counts = Counter()
        city_counts = Counter()
        
        for entry in log_entries:
            country = entry.get('country', '')
            city = entry.get('city', '')
            
            if country:
                country_counts[country] += 1
            if city:
                city_counts[city] += 1
        
        return {
            'countries': dict(country_counts.most_common(10)),
            'cities': dict(city_counts.most_common(10)),
            'total_countries': len(country_counts),
            'total_cities': len(city_counts)
        }
    
    def _detect_attack_patterns(self, log_entries: List[Dict]) -> List[str]:
        """Detect the 8 core attack patterns"""
        patterns = []
        
        # 1. Brute Force Login detection
        if self._detect_brute_force(log_entries):
            patterns.append('brute_force_login')
        
        # 2. SQL Injection detection
        if self._detect_sql_injection(log_entries):
            patterns.append('sql_injection')
        
        # 3. XSS detection
        if self._detect_xss(log_entries):
            patterns.append('xss')
        
        # 4. Directory Traversal detection
        if self._detect_directory_traversal(log_entries):
            patterns.append('directory_traversal')
        
        # 5. Command Injection detection
        if self._detect_command_injection(log_entries):
            patterns.append('command_injection')
        
        # 6. High Request Rate (DoS) detection
        if self._detect_high_request_rate(log_entries):
            patterns.append('high_request_rate')
        
        # 7. Access to Hidden/Admin Areas detection
        if self._detect_access_hidden_admin(log_entries):
            patterns.append('access_hidden_admin')
        
        # 8. Suspicious HTTP Methods detection
        if self._detect_suspicious_http_methods(log_entries):
            patterns.append('suspicious_http_methods')
        
        return patterns
    
    def _detect_brute_force(self, log_entries: List[Dict]) -> bool:
        """Detect brute force login attempts using refined patterns"""
        # Check for specific login paths with errors
        login_paths = ['/login', '/admin', '/wp-login', '/auth', '/signin']
        login_attempts = []
        
        for entry in log_entries:
            path = entry.get('path', '').lower()
            if any(login_path in path for login_path in login_paths):
                if entry.get('status_code', 200) in [401, 403, 404]:
                    login_attempts.append(entry)
        
        # Group by IP
        ip_attempts = defaultdict(int)
        for attempt in login_attempts:
            ip_attempts[attempt.get('ip_address', '')] += 1
        
        # Check for IPs with many failed attempts
        return any(count > 20 for count in ip_attempts.values())
    

    
    def _detect_high_request_rate(self, log_entries: List[Dict]) -> bool:
        """Detect high request rate patterns (DoS) using refined patterns and time window analysis"""
        # Use the refined patterns from _load_attack_patterns
        high_request_patterns = self._load_attack_patterns()['high_request_rate']['patterns']

        if len(log_entries) < 10:
            return False

        # Group requests by IP and by minute
        ip_time_buckets = defaultdict(lambda: defaultdict(int))  # ip -> minute_bucket -> count
        for entry in log_entries:
            ip = entry.get('ip_address', '')
            ts = entry.get('timestamp')
            if isinstance(ts, str):
                try:
                    # Try parsing ISO or Apache timestamp
                    if 'T' in ts:
                        dt = datetime.fromisoformat(ts.replace('Z', '+00:00'))
                    elif '/' in ts and ':' in ts:
                        # Apache format: 01/Jun/2024:12:00:00 +0000
                        dt = datetime.strptime(ts.split()[0], '%d/%b/%Y:%H:%M:%S')
                    else:
                        dt = datetime.fromisoformat(ts)
                except Exception:
                    continue
            elif isinstance(ts, datetime):
                dt = ts
            else:
                continue
            minute_bucket = dt.replace(second=0, microsecond=0)
            ip_time_buckets[ip][minute_bucket] += 1

        # Check for any IP with >50 requests in any 5-minute window
        for ip, buckets in ip_time_buckets.items():
            sorted_minutes = sorted(buckets.keys())
            for i in range(len(sorted_minutes)):
                total = 0
                for j in range(i, len(sorted_minutes)):
                    if (sorted_minutes[j] - sorted_minutes[i]).total_seconds() > 300:
                        break
                    total += buckets[sorted_minutes[j]]
                if total > 50:
                    return True

        # Fallback: original logic (for compatibility)
        ip_counts = Counter(entry.get('ip_address', '') for entry in log_entries)
        max_requests = max(ip_counts.values()) if ip_counts else 0
        return max_requests > max(len(log_entries) * 0.2, 50)
    

    

    
    def _detect_access_hidden_admin(self, log_entries: List[Dict]) -> bool:
        """Detect attempts to access hidden/admin areas using refined patterns"""
        admin_paths = ['/admin', '/administrator', '/wp-admin', '/phpmyadmin', '/cpanel', '/webmail', '/config', '/configuration', '/settings', '/setup', '/install']
        
        for entry in log_entries:
            path = entry.get('path', '').lower()
            for admin_path in admin_paths:
                if admin_path in path:
                    return True
        return False
    
    def _detect_suspicious_http_methods(self, log_entries: List[Dict]) -> bool:
        """Detect suspicious HTTP methods using refined patterns"""
        suspicious_methods = ['PUT', 'DELETE', 'TRACE', 'OPTIONS', 'HEAD', 'CONNECT', 'PATCH']
        
        for entry in log_entries:
            method = entry.get('method', 'GET').upper()
            if method in suspicious_methods:
                return True
        return False
    
    def _detect_sql_injection(self, log_entries: List[Dict]) -> bool:
        """Detect SQL injection attempts using refined patterns"""
        # Use the refined patterns from _load_attack_patterns
        sql_patterns = self._load_attack_patterns()['sql_injection']['patterns']
        
        for entry in log_entries:
            path = unquote(entry.get('path', ''))
            query_string = entry.get('query_string', '')
            combined_text = f"{path} {query_string}".lower()
            
            for pattern in sql_patterns:
                if re.search(pattern, combined_text, re.IGNORECASE):
                    return True
        return False
    
    def _detect_xss(self, log_entries: List[Dict]) -> bool:
        """Detect XSS attempts using refined patterns"""
        # Use the refined patterns from _load_attack_patterns
        xss_patterns = self._load_attack_patterns()['xss']['patterns']
        
        for entry in log_entries:
            path = unquote(entry.get('path', ''))
            query_string = entry.get('query_string', '')
            combined_text = f"{path} {query_string}".lower()
            
            for pattern in xss_patterns:
                if re.search(pattern, combined_text, re.IGNORECASE):
                    return True
        return False
    
    def _detect_directory_traversal(self, log_entries: List[Dict]) -> bool:
        """Detect directory traversal attempts using refined patterns"""
        # Use the refined patterns from _load_attack_patterns
        traversal_patterns = self._load_attack_patterns()['directory_traversal']['patterns']
        
        for entry in log_entries:
            path = unquote(entry.get('path', ''))
            if any(re.search(pattern, path, re.IGNORECASE) for pattern in traversal_patterns):
                return True
        return False
    
    def _detect_command_injection(self, log_entries: List[Dict]) -> bool:
        """Detect command injection attempts using refined patterns"""
        # Use the refined patterns from _load_attack_patterns
        command_patterns = self._load_attack_patterns()['command_injection']['patterns']
        
        for entry in log_entries:
            path = unquote(entry.get('path', ''))
            query_string = entry.get('query_string', '')
            combined_text = f"{path} {query_string}".lower()
            
            for pattern in command_patterns:
                if re.search(pattern, combined_text, re.IGNORECASE):
                    return True
        return False
    
    def _check_vulnerability_indicators(self, log_entries: List[Dict]) -> List[str]:
        """Check for specific vulnerability exploitation attempts"""
        indicators = []
        
        for vuln_name, patterns in self.vulnerability_signatures.items():
            for entry in log_entries:
                combined_text = f"{entry.get('path', '')} {entry.get('user_agent', '')}".lower()
                for pattern in patterns:
                    if re.search(pattern, combined_text, re.IGNORECASE):
                        indicators.append(vuln_name)
                        break
        
        return list(set(indicators))
    
    def _generate_activity_checklist(self, security_events: List[SecurityEvent], 
                                   attack_patterns: List[str], suspicious_ips: List[Dict]) -> List[Dict]:
        """Generate suspicious activity checklist for the 8 core attack types"""
        checklist_items = [
            {'index': 'A1', 'label': 'Brute Force Login attempts', 'detected': False},
            {'index': 'A2', 'label': 'SQL Injection (SQLi) attempts', 'detected': False},
            {'index': 'A3', 'label': 'Cross-site scripting (XSS) attempts', 'detected': False},
            {'index': 'A4', 'label': 'Directory Traversal attempts', 'detected': False},
            {'index': 'A5', 'label': 'Command Injection attempts', 'detected': False},
            {'index': 'B1', 'label': 'High Request Rate (DoS) patterns', 'detected': False},
            {'index': 'B2', 'label': 'Access to Hidden/Admin Areas', 'detected': False},
            {'index': 'B3', 'label': 'Suspicious HTTP Methods', 'detected': False},
        ]
        
        # Map security events to checklist items
        event_mapping = {
            'brute_force_login': 'A1',
            'sql_injection': 'A2',
            'xss': 'A3',
            'directory_traversal': 'A4',
            'command_injection': 'A5',
            'high_request_rate': 'B1',
            'access_hidden_admin': 'B2',
            'suspicious_http_methods': 'B3',
        }
        
        # Map attack patterns to checklist items
        pattern_mapping = {
            'brute_force_login': 'A1',
            'sql_injection': 'A2',
            'xss': 'A3',
            'directory_traversal': 'A4',
            'command_injection': 'A5',
            'high_request_rate': 'B1',
            'access_hidden_admin': 'B2',
            'suspicious_http_methods': 'B3',
        }
        
        for event in security_events:
            if event.type in event_mapping:
                item_index = event_mapping[event.type]
                for item in checklist_items:
                    if item['index'] == item_index:
                        item['detected'] = True
                        break
        
        # Map attack patterns to checklist items
        for pattern in attack_patterns:
            if pattern in pattern_mapping:
                item_index = pattern_mapping[pattern]
                for item in checklist_items:
                    if item['index'] == item_index:
                        item['detected'] = True
                        break
        
        # Check for suspicious IPs (high-volume requests)
        if suspicious_ips:
            for item in checklist_items:
                if item['index'] == 'B1': # High Request Rate (DoS)
                    item['detected'] = True
                    break
        
        return checklist_items
    
    def _determine_highest_severity(self, security_events: List[SecurityEvent]) -> str:
        """Determine the highest severity level"""
        if not security_events:
            return 'none'
        
        severity_order = ['critical', 'high', 'medium', 'low']
        for severity in severity_order:
            if any(event.severity == severity for event in security_events):
                return severity
        
        return 'low'
    
    def _generate_event_actions(self, attack_type: str, occurrence_count: int) -> List[str]:
        """Generate immediate actions for the 8 core attack types"""
        actions = []
        
        if attack_type == 'brute_force_login':
            actions.extend([
                "Implement account lockout policies",
                "Enable multi-factor authentication",
                "Review failed login attempts",
                "Consider blocking source IPs"
            ])
        elif attack_type == 'sql_injection':
            actions.extend([
                "Review and implement parameterized queries",
                "Check database access logs",
                "Consider blocking source IPs",
                "Audit database permissions"
            ])
        elif attack_type == 'xss':
            actions.extend([
                "Implement output encoding",
                "Review input validation",
                "Check for stored XSS",
                "Implement Content Security Policy"
            ])
        elif attack_type == 'directory_traversal':
            actions.extend([
                "Check file system access",
                "Review directory permissions",
                "Audit sensitive file access",
                "Implement path validation"
            ])
        elif attack_type == 'command_injection':
            actions.extend([
                "Immediately investigate system integrity",
                "Check for unauthorized access",
                "Review system logs",
                "Audit command execution permissions"
            ])
        elif attack_type == 'high_request_rate':
            actions.extend([
                "Implement rate limiting",
                "Check for DDoS protection",
                "Monitor service availability",
                "Consider blocking source IPs"
            ])
        elif attack_type == 'access_hidden_admin':
            actions.extend([
                "Review admin area access logs",
                "Check authentication mechanisms",
                "Audit admin user accounts",
                "Implement IP whitelisting if needed"
            ])
        elif attack_type == 'suspicious_http_methods':
            actions.extend([
                "Review allowed HTTP methods",
                "Check server configuration",
                "Audit method usage patterns",
                "Consider method restrictions"
            ])
        
        if occurrence_count > 50:
            actions.append("Consider implementing rate limiting")
        
        return actions
    
    def _generate_recommendations(self, security_events: List[SecurityEvent], 
                                attack_patterns: List[str], suspicious_ips: List[Dict]) -> Tuple[List[str], List[str]]:
        """Generate immediate actions and long-term recommendations"""
        immediate_actions = []
        long_term_recommendations = []
        
        # Immediate actions based on security events
        if any(event.severity == 'critical' for event in security_events):
            immediate_actions.extend([
                "Conduct immediate security incident response",
                "Check system integrity and unauthorized access",
                "Review all admin account activity"
            ])
        
        if suspicious_ips:
            immediate_actions.extend([
                "Consider blocking suspicious IP addresses",
                "Implement enhanced monitoring for flagged IPs"
            ])
        
        if 'brute_force_login' in attack_patterns:
            immediate_actions.extend([
                "Implement account lockout policies",
                "Enable multi-factor authentication",
                "Review authentication logs"
            ])
        
        if 'sql_injection' in attack_patterns:
            immediate_actions.extend([
                "Audit database access patterns",
                "Review input validation mechanisms"
            ])
        
        if 'xss' in attack_patterns:
            immediate_actions.extend([
                "Implement Content Security Policy",
                "Review output encoding mechanisms"
            ])
        
        if 'directory_traversal' in attack_patterns:
            immediate_actions.extend([
                "Audit file system permissions",
                "Implement path validation"
            ])
        
        if 'command_injection' in attack_patterns:
            immediate_actions.extend([
                "Audit system command execution",
                "Review input sanitization"
            ])
        
        if 'high_request_rate' in attack_patterns:
            immediate_actions.extend([
                "Implement DDoS protection",
                "Review rate limiting policies"
            ])
        
        if 'access_hidden_admin' in attack_patterns:
            immediate_actions.extend([
                "Review admin area security",
                "Implement access controls"
            ])
        
        if 'suspicious_http_methods' in attack_patterns:
            immediate_actions.extend([
                "Review HTTP method policies",
                "Implement method restrictions"
            ])
        
        # Long-term recommendations
        long_term_recommendations.extend([
            "Implement Web Application Firewall (WAF)",
            "Regular security audits and penetration testing",
            "Enhanced logging and monitoring",
            "Security awareness training for development team",
            "Implement SIEM solution for real-time threat detection"
        ])
        
        if security_events:
            long_term_recommendations.extend([
                "Code security review and static analysis",
                "Input validation and output encoding improvements",
                "Regular security updates and patch management"
            ])
        
        return immediate_actions, long_term_recommendations
    
    def _generate_escalation_reasoning(self, security_events: List[SecurityEvent], 
                                     attack_patterns: List[str], suspicious_ips: List[Dict]) -> List[str]:
        """Generate reasoning for escalation decisions"""
        reasoning = []
        
        # Check for high-severity events
        critical_events = [e for e in security_events if e.severity == 'critical']
        if critical_events:
            reasoning.append(f"Critical security events detected: {len(critical_events)} events require immediate attention")
        
        high_events = [e for e in security_events if e.severity == 'high']
        if high_events:
            reasoning.append(f"High-severity events detected: {len(high_events)} events indicate potential compromise")
        
        # Check for attack patterns
        if 'brute_force_login' in attack_patterns:
            reasoning.append("Brute force login attack detected - credential security at risk")
        
        if 'sql_injection' in attack_patterns:
            reasoning.append("SQL injection attack detected - database security at risk")
        
        if 'xss' in attack_patterns:
            reasoning.append("Cross-site scripting attack detected - user security at risk")
        
        if 'directory_traversal' in attack_patterns:
            reasoning.append("Directory traversal attack detected - file system security at risk")
        
        if 'command_injection' in attack_patterns:
            reasoning.append("Command injection attack detected - system security at risk")
        
        if 'high_request_rate' in attack_patterns:
            reasoning.append("High request rate (DoS) pattern detected - service availability at risk")
        
        if 'access_hidden_admin' in attack_patterns:
            reasoning.append("Access to hidden/admin areas detected - administrative security at risk")
        
        if 'suspicious_http_methods' in attack_patterns:
            reasoning.append("Suspicious HTTP methods detected - server configuration at risk")
        
        # Check for suspicious IP activity
        if len(suspicious_ips) > 5:
            reasoning.append(f"Multiple suspicious IPs detected: {len(suspicious_ips)} IPs showing malicious behavior")
        
        # Default reasoning if no major issues
        if not reasoning:
            if security_events or suspicious_ips:
                reasoning.append("Security events detected warrant review for potential threats")
            else:
                reasoning.append("No significant security threats detected in current log analysis")
        
        return reasoning
    
    def _extract_url_patterns(self, paths: set) -> List[str]:
        """Extract common URL patterns from paths"""
        patterns = []
        path_list = list(paths)[:10]  # Limit to first 10
        
        for path in path_list:
            # Remove query parameters and fragments
            clean_path = path.split('?')[0].split('#')[0]
            patterns.append(clean_path)
        
        return patterns
    
    def _get_related_log_entries(self, log_entries: List[Dict], 
                               security_events: List[SecurityEvent]) -> List[Dict]:
        """Get log entries related to security events for evidence"""
        related_entries = []
        
        # Get IPs from security events
        event_ips = set()
        for event in security_events:
            event_ips.update(event.source_ips)
        
        # Find entries from these IPs
        for entry in log_entries:
            if entry.get('ip_address') in event_ips:
                related_entries.append({
                    'timestamp': entry.get('timestamp', ''),
                    'ip_address': entry.get('ip_address', ''),
                    'method': entry.get('method', ''),
                    'path': entry.get('path', ''),
                    'status_code': entry.get('status_code', ''),
                    'user_agent': entry.get('user_agent', '')[:100],
                    'raw_log': entry.get('raw_log', '')[:200]
                })
        
        # Limit to most relevant entries
        return related_entries[:20]
    
    def _calculate_risk_score(self, security_events: List[SecurityEvent], 
                             suspicious_ips: List[Dict], attack_patterns: List[str],
                             total_requests: int) -> float:
        """Calculate overall risk score based on security events and patterns"""
        if not security_events and not suspicious_ips and not attack_patterns:
            return 0.0
        
        # Base risk from security events
        event_risk = 0.0
        severity_weights = {
            'critical': 1.0,
            'high': 0.8,
            'medium': 0.5,
            'low': 0.2
        }
        
        for event in security_events:
            weight = severity_weights.get(event.severity, 0.1)
            event_risk += weight * event.confidence
        
        # Normalize event risk (max 0.6 from events)
        event_risk = min(event_risk * 0.6, 0.6)
        
        # Risk from suspicious IPs (max 0.2)
        ip_risk = min(len(suspicious_ips) * 0.05, 0.2)
        
        # Risk from attack patterns (max 0.2)
        pattern_risk = min(len(attack_patterns) * 0.04, 0.2)
        
        # Calculate total risk score (0.0 to 1.0)
        total_risk = event_risk + ip_risk + pattern_risk
        
        return min(total_risk, 1.0)

    def _generate_summary(self, total_requests: int, unique_ips: int, 
                         security_events: List[SecurityEvent], highest_severity: str) -> str:
        """Generate analysis summary focused on the 8 core attack types"""
        if not security_events:
            return f"Analyzed {total_requests} requests from {unique_ips} unique IPs. No significant security threats detected."
        
        event_count = len(security_events)
        severity_text = "critical security threats" if highest_severity == 'critical' else f"{highest_severity}-severity security events"
        
        return f"Analyzed {total_requests} requests from {unique_ips} unique IPs. Detected {event_count} {severity_text} requiring attention."
     