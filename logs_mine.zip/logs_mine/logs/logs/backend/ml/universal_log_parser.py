"""
Universal log parser for enhanced security analysis across all log types
"""

import re
import json
from datetime import datetime
from typing import Dict, List, Optional, Any
from urllib.parse import unquote, parse_qs, urlparse


class UniversalLogParser:
    """Enhanced parser that can handle multiple log formats for security analysis"""
    
    def __init__(self):
        self.log_patterns = self._load_log_patterns()
    
    def _load_log_patterns(self) -> Dict[str, Dict[str, Any]]:
        """Load patterns for different log formats"""
        return {
            'apache_common': {
                'pattern': r'^(\S+) (\S+) (\S+) \[([^\]]+)\] "([^"]*)" (\d+) (\S+)(?:\s+"([^"]*)")?(?:\s+"([^"]*)")?',
                'fields': ['ip_address', 'identity', 'user', 'timestamp', 'request', 'status_code', 'response_size', 'referer', 'user_agent']
            },
            'apache_combined': {
                'pattern': r'^(\S+) (\S+) (\S+) \[([^\]]+)\] "([^"]*)" (\d+) (\S+) "([^"]*)" "([^"]*)"',
                'fields': ['ip_address', 'identity', 'user', 'timestamp', 'request', 'status_code', 'response_size', 'referer', 'user_agent']
            },
            'nginx': {
                'pattern': r'^(\S+) - (\S+) \[([^\]]+)\] "([^"]*)" (\d+) (\S+) "([^"]*)" "([^"]*)"',
                'fields': ['ip_address', 'user', 'timestamp', 'request', 'status_code', 'response_size', 'referer', 'user_agent']
            },
            'iis': {
                'pattern': r'^(\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+)',
                'fields': ['date', 'time', 'server_ip', 'method', 'uri_stem', 'uri_query', 'port', 'username', 'client_ip', 'user_agent', 'referer', 'status_code', 'substatus', 'win32_status']
            },
            'json': {
                'pattern': r'^\{.*\}$',
                'fields': ['json_data']
            },
            'syslog': {
                'pattern': r'^(\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+(\S+)\s+(\S+):\s*(.*)',
                'fields': ['timestamp', 'hostname', 'process', 'message']
            },
            'clf': {  # Common Log Format
                'pattern': r'^(\S+) (\S+) (\S+) \[([^\]]+)\] "([^"]*)" (\d+) (\S+)',
                'fields': ['ip_address', 'identity', 'user', 'timestamp', 'request', 'status_code', 'response_size']
            }
        }
    
    def parse_log_entry(self, log_line: str, log_type: str = 'auto') -> Optional[Dict[str, Any]]:
        """Parse a log entry with enhanced security-focused extraction"""
        if not log_line or not log_line.strip():
            return None
        
        # Auto-detect log type if not specified
        if log_type == 'auto':
            log_type = self._detect_log_type(log_line)
        
        # Parse based on detected/specified type
        parsed_data = self._parse_by_type(log_line, log_type)
        
        if parsed_data:
            # Enhance with security-focused fields
            enhanced_data = self._enhance_for_security_analysis(parsed_data, log_line)
            return enhanced_data
        
        return None
    
    def _detect_log_type(self, log_line: str) -> str:
        """Auto-detect log format"""
        log_line = log_line.strip()
        
        # JSON detection
        if log_line.startswith('{') and log_line.endswith('}'):
            return 'json'
        
        # Apache/Nginx combined log format
        if re.search(r'\[.*?\].*?".*?".*?\d+.*?\d+.*?".*?".*?".*?"', log_line):
            return 'apache_combined'
        
        # Apache common log format
        if re.search(r'\[.*?\].*?".*?".*?\d+.*?\d+', log_line):
            return 'apache_common'
        
        # IIS log format
        if re.search(r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}', log_line):
            return 'iis'
        
        # Syslog format
        if re.search(r'^\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}', log_line):
            return 'syslog'
        
        # Default to common log format
        return 'clf'
    
    def _parse_by_type(self, log_line: str, log_type: str) -> Optional[Dict[str, Any]]:
        """Parse log line based on type"""
        if log_type not in self.log_patterns:
            return None
        
        pattern_info = self.log_patterns[log_type]
        pattern = re.compile(pattern_info['pattern'])
        match = pattern.match(log_line.strip())
        
        if not match:
            return None
        
        # Extract fields based on pattern
        fields = pattern_info['fields']
        values = match.groups()
        
        # Create data dictionary
        data = {}
        for i, field in enumerate(fields):
            if i < len(values):
                data[field] = values[i]
        
        # Handle special cases
        if log_type == 'json':
            return self._parse_json_log(log_line)
        elif log_type == 'iis':
            return self._parse_iis_log(log_line)
        else:
            return self._parse_regex_log(log_line, pattern_info)
    
    def _parse_json_log(self, log_line: str) -> Optional[Dict[str, Any]]:
        """Parse JSON log entry"""
        try:
            json_data = json.loads(log_line)
            return {
                'timestamp': json_data.get('timestamp', ''),
                'ip_address': json_data.get('ip', json_data.get('client_ip', '')),
                'method': json_data.get('method', 'GET'),
                'path': json_data.get('path', json_data.get('uri', '')),
                'status_code': json_data.get('status_code', 200),
                'response_size': json_data.get('response_size', 0),
                'user_agent': json_data.get('user_agent', ''),
                'referer': json_data.get('referer', ''),
                'raw_log': log_line
            }
        except json.JSONDecodeError:
            return None
    
    def _parse_iis_log(self, log_line: str) -> Optional[Dict[str, Any]]:
        """Parse IIS log entry"""
        parts = log_line.split()
        if len(parts) < 14:
            return None
        
        return {
            'timestamp': f"{parts[0]} {parts[1]}",
            'ip_address': parts[8],  # client_ip
            'method': parts[3],
            'path': parts[4],
            'status_code': int(parts[11]) if parts[11].isdigit() else 200,
            'response_size': int(parts[12]) if parts[12].isdigit() else 0,
            'user_agent': parts[9],
            'referer': parts[10],
            'raw_log': log_line
        }
    
    def _parse_regex_log(self, log_line: str, pattern_info: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Parse log entry using regex pattern"""
        pattern = re.compile(pattern_info['pattern'])
        match = pattern.match(log_line.strip())
        
        if not match:
            return None
        
        fields = pattern_info['fields']
        values = match.groups()
        
        data = {}
        for i, field in enumerate(fields):
            if i < len(values):
                data[field] = values[i]
        
        # Normalize common fields
        normalized_data = self._normalize_fields(data)
        normalized_data['raw_log'] = log_line
        
        return normalized_data
    
    def _normalize_fields(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize parsed fields to common format"""
        normalized = {}
        
        # Extract IP address
        normalized['ip_address'] = data.get('ip_address', '0.0.0.0')
        
        # Parse timestamp
        timestamp_str = data.get('timestamp', '')
        normalized['timestamp'] = self._parse_timestamp(timestamp_str)
        
        # Extract method and path from request
        request = data.get('request', '')
        if request:
            parts = request.split()
            if len(parts) >= 2:
                normalized['method'] = parts[0]
                normalized['path'] = parts[1]
            else:
                normalized['method'] = 'GET'
                normalized['path'] = request
        else:
            normalized['method'] = data.get('method', 'GET')
            normalized['path'] = data.get('path', data.get('uri_stem', '/'))
        
        # Parse status code
        try:
            normalized['status_code'] = int(data.get('status_code', 200))
        except (ValueError, TypeError):
            normalized['status_code'] = 200
        
        # Parse response size
        try:
            normalized['response_size'] = int(data.get('response_size', 0))
        except (ValueError, TypeError):
            normalized['response_size'] = 0
        
        # Extract user agent and referer
        normalized['user_agent'] = data.get('user_agent', '')
        normalized['referer'] = data.get('referer', '')
        
        return normalized
    
    def _enhance_for_security_analysis(self, parsed_data: Dict[str, Any], raw_log: str) -> Dict[str, Any]:
        """Enhance parsed data with security-focused fields"""
        enhanced = parsed_data.copy()
        
        # Add security analysis fields
        enhanced['suspicious_path_patterns'] = self._identify_suspicious_path_patterns(enhanced.get('path', ''))
        enhanced['user_agent_analysis'] = self._analyze_user_agent(enhanced.get('user_agent', ''))
        enhanced['status_category'] = self._categorize_status_code(enhanced.get('status_code', 200))
        enhanced['is_suspicious'] = len(enhanced['suspicious_path_patterns']) > 0
        
        return enhanced
    
    def _identify_suspicious_path_patterns(self, path: str) -> List[str]:
        """Identify suspicious patterns in request path"""
        suspicious_patterns = []
        
        # SQL injection patterns
        sql_patterns = [
            r"'.*OR.*'1'='1", r"'.*UNION.*SELECT", r"'.*AND.*1=1",
            r"'.*DROP.*TABLE", r"'.*INSERT.*INTO", r"'.*UPDATE.*SET",
            r"'.*DELETE.*FROM", r"'.*EXEC.*", r"'.*xp_cmdshell"
        ]
        
        for pattern in sql_patterns:
            if re.search(pattern, path, re.IGNORECASE):
                suspicious_patterns.append('sql_injection')
                break
        
        # Path traversal patterns
        if re.search(r'\.\./', path) or re.search(r'%2e%2e%2f', path):
            suspicious_patterns.append('path_traversal')
        
        # Command injection patterns
        if re.search(r'[;&|`]', path):
            suspicious_patterns.append('command_injection')
        
        # XSS patterns
        if re.search(r'<script', path, re.IGNORECASE) or re.search(r'javascript:', path, re.IGNORECASE):
            suspicious_patterns.append('xss')
        
        return suspicious_patterns
    
    def _analyze_user_agent(self, user_agent: str) -> Dict[str, Any]:
        """Analyze user agent for suspicious patterns"""
        analysis = {
            'is_bot': False,
            'is_scanner': False,
            'is_suspicious': False,
            'bot_type': None
        }
        
        user_agent_lower = user_agent.lower()
        
        # Bot detection
        bot_indicators = ['bot', 'crawler', 'spider', 'scraper']
        for indicator in bot_indicators:
            if indicator in user_agent_lower:
                analysis['is_bot'] = True
                analysis['bot_type'] = indicator
                break
        
        # Scanner detection
        scanner_indicators = ['nmap', 'nikto', 'sqlmap', 'burp', 'zap']
        for indicator in scanner_indicators:
            if indicator in user_agent_lower:
                analysis['is_scanner'] = True
                analysis['is_suspicious'] = True
                break
        
        # Suspicious patterns
        suspicious_patterns = ['curl', 'wget', 'python-requests']
        for pattern in suspicious_patterns:
            if pattern in user_agent_lower:
                analysis['is_suspicious'] = True
                break
        
        return analysis
    
    def _categorize_status_code(self, status_code: int) -> str:
        """Categorize HTTP status code"""
        if 200 <= status_code < 300:
            return 'success'
        elif 300 <= status_code < 400:
            return 'redirect'
        elif 400 <= status_code < 500:
            return 'client_error'
        elif 500 <= status_code < 600:
            return 'server_error'
        else:
            return 'unknown'
    
    def _parse_timestamp(self, timestamp_str: str) -> Optional[datetime]:
        """Parse timestamp string to datetime object"""
        if not timestamp_str:
            return None
        
        # Common timestamp formats
        formats = [
            '%d/%b/%Y:%H:%M:%S %z',
            '%d/%b/%Y:%H:%M:%S',
            '%Y-%m-%d %H:%M:%S',
            '%b %d %H:%M:%S',
            '%Y-%m-%dT%H:%M:%S',
            '%Y-%m-%dT%H:%M:%SZ'
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(timestamp_str, fmt)
            except ValueError:
                continue
        
        return None
    
    def batch_parse(self, log_lines: List[str], log_type: str = 'auto') -> List[Dict[str, Any]]:
        """Parse multiple log lines"""
        parsed_entries = []
        
        for line in log_lines:
            parsed_entry = self.parse_log_entry(line, log_type)
            if parsed_entry:
                parsed_entries.append(parsed_entry)
        
        return parsed_entries
