from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
import json


class LogFile(models.Model):
    """Model for uploaded log files"""
    
    LOG_TYPES = [
        ('apache', 'Apache'),
        ('nginx', 'Nginx'),
        ('django', 'Django'),
        ('apache_access', 'Apache Access Logs'),
        ('sql_injection_attack', 'SQL Injection Attack Logs'),
        ('linux_syslog', 'Linux System Logs'),
        ('unknown', 'Unknown'),
    ]
    
    STATUS_CHOICES = [
        ('uploaded', 'Uploaded'),
        ('processing', 'Processing'),
        ('processed', 'Processed'),
        ('failed', 'Failed'),
        ('deleted', 'Deleted'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='log_files')
    file = models.FileField(upload_to='logs/')
    filename = models.CharField(max_length=255)
    file_size = models.BigIntegerField()
    log_type = models.CharField(max_length=20, choices=LOG_TYPES, default='unknown')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='uploaded')
    
    # Processing metadata
    total_lines = models.IntegerField(default=0)
    processed_lines = models.IntegerField(default=0)
    error_lines = models.IntegerField(default=0)
    
    # Timestamps
    uploaded_at = models.DateTimeField(auto_now_add=True)
    processed_at = models.DateTimeField(null=True, blank=True)
    
    # Analysis metadata
    suspicious_activities_count = models.IntegerField(default=0)
    risk_score = models.FloatField(default=0.0)
    
    # File content stored in database
    file_content = models.TextField(blank=True, null=True, help_text="Raw file content stored in database")
    
    class Meta:
        ordering = ['-uploaded_at']
    
    def __str__(self):
        return f"{self.filename} ({self.log_type})"
    
    def get_file_size_mb(self):
        """Return file size in MB"""
        return round(self.file_size / (1024 * 1024), 2)


class LogEntry(models.Model):
    """Model for individual log entries"""
    
    log_file = models.ForeignKey(LogFile, on_delete=models.CASCADE, related_name='entries')
    
    # Basic log data
    timestamp = models.DateTimeField()
    ip_address = models.GenericIPAddressField()
    method = models.CharField(max_length=10)
    path = models.TextField()
    status_code = models.IntegerField()
    response_size = models.BigIntegerField(default=0)
    user_agent = models.TextField(blank=True)
    referer = models.TextField(blank=True)
    
    # GeoIP data
    country = models.CharField(max_length=2, blank=True)
    city = models.CharField(max_length=100, blank=True)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    
    # Analysis data
    is_suspicious = models.BooleanField(default=False)
    risk_score = models.FloatField(default=0.0)
    suspicious_patterns = models.JSONField(default=list)
    
    # Raw log line
    raw_log = models.TextField()
    
    class Meta:
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['timestamp']),
            models.Index(fields=['ip_address']),
            models.Index(fields=['status_code']),
            models.Index(fields=['is_suspicious']),
        ]
    
    def __str__(self):
        return f"{self.ip_address} - {self.method} {self.path} ({self.status_code})"


class AnalysisResult(models.Model):
    """Model for ML analysis results"""
    
    ANALYSIS_TYPES = [
        ('suspicious_activity', 'Suspicious Activity'),
        ('attack_pattern', 'Attack Pattern'),
        ('anomaly', 'Anomaly Detection'),
        ('geo_analysis', 'Geographic Analysis'),
    ]
    
    log_file = models.ForeignKey(LogFile, on_delete=models.CASCADE, related_name='analysis_results')
    analysis_type = models.CharField(max_length=50, choices=ANALYSIS_TYPES)
    
    # Analysis data
    results = models.JSONField()
    confidence_score = models.FloatField()
    model_used = models.CharField(max_length=100)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    processing_time = models.FloatField(default=0.0)  # in seconds
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.analysis_type} - {self.log_file.filename}"


class SuspiciousActivity(models.Model):
    """Model for flagged suspicious activities"""
    
    SEVERITY_CHOICES = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('critical', 'Critical'),
    ]
    
    ACTIVITY_TYPES = [
        ('brute_force', 'Brute Force Attack'),
        ('sql_injection', 'SQL Injection'),
        ('xss', 'Cross-Site Scripting'),
        ('path_traversal', 'Path Traversal'),
        ('ddos', 'DDoS Attack'),
        ('suspicious_ip', 'Suspicious IP'),
        ('unusual_pattern', 'Unusual Pattern'),
    ]
    
    log_file = models.ForeignKey(LogFile, on_delete=models.CASCADE, related_name='suspicious_activities')
    log_entries = models.ManyToManyField(LogEntry, related_name='suspicious_activities')
    
    activity_type = models.CharField(max_length=50, choices=ACTIVITY_TYPES)
    severity = models.CharField(max_length=20, choices=SEVERITY_CHOICES)
    description = models.TextField()
    
    # Detection data
    confidence_score = models.FloatField()
    detection_method = models.CharField(max_length=100)
    patterns_found = models.JSONField(default=list)
    
    # Location data
    affected_ips = models.JSONField(default=list)
    affected_paths = models.JSONField(default=list)
    
    # Timestamps
    first_detected = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True)
    
    # Status
    is_resolved = models.BooleanField(default=False)
    resolved_at = models.DateTimeField(null=True, blank=True)
    resolution_notes = models.TextField(blank=True)
    
    class Meta:
        ordering = ['-first_detected']
        indexes = [
            models.Index(fields=['activity_type']),
            models.Index(fields=['severity']),
            models.Index(fields=['is_resolved']),
        ]
    
    def __str__(self):
        return f"{self.activity_type} - {self.severity} ({self.confidence_score}%)"


class Report(models.Model):
    """Model for generated reports"""
    
    REPORT_TYPES = [
        ('pdf', 'PDF'),
        ('csv', 'CSV'),
        ('excel', 'Excel'),
    ]
    
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('processing', 'Processing'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reports')
    name = models.CharField(max_length=255)
    report_type = models.CharField(max_length=10, choices=REPORT_TYPES, default='pdf')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    
    # Report configuration
    log_file = models.ForeignKey(LogFile, on_delete=models.CASCADE, null=True, blank=True, related_name='reports')
    date_from = models.DateTimeField(null=True, blank=True)
    date_to = models.DateTimeField(null=True, blank=True)
    include_charts = models.BooleanField(default=True)
    include_recommendations = models.BooleanField(default=True)
    
    # Generated file
    report_file = models.FileField(upload_to='reports/', null=True, blank=True)
    file_size = models.BigIntegerField(default=0)
    
    # Metadata
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    processing_time = models.FloatField(null=True, blank=True)  # in seconds
    
    # Report content summary
    total_entries = models.IntegerField(default=0)
    suspicious_activities_count = models.IntegerField(default=0)
    risk_score_avg = models.FloatField(default=0.0)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.name} ({self.report_type})"
    
    def get_file_size_mb(self):
        """Return file size in MB"""
        if self.file_size:
            return round(self.file_size / (1024 * 1024), 2)
        return 0
    
    def get_processing_time_formatted(self):
        """Return processing time in human readable format"""
        if self.processing_time:
            if self.processing_time < 60:
                return f"{self.processing_time:.1f}s"
            else:
                minutes = int(self.processing_time // 60)
                seconds = self.processing_time % 60
                return f"{minutes}m {seconds:.1f}s"
        return "N/A"



