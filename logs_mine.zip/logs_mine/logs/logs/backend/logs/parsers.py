import re
import datetime
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import ipaddress


@dataclass
class ParsedLogEntry:
    """Data class for parsed log entry"""
    timestamp: datetime.datetime
    ip_address: str
    method: str
    path: str
    status_code: int
    response_size: int
    user_agent: str = ""
    referer: str = ""
    raw_log: str = ""


class BaseLogParser:
    """Base class for log parsers"""
    
    def __init__(self):
        self.name = "base"
    
    def can_parse(self, log_line: str) -> bool:
        """Check if this parser can handle the log line"""
        raise NotImplementedError
    
    def parse_line(self, log_line: str) -> Optional[ParsedLogEntry]:
        """Parse a single log line"""
        raise NotImplementedError
    
    def validate_ip(self, ip_str: str) -> bool:
        """Validate IP address format"""
        try:
            ipaddress.ip_address(ip_str)
            return True
        except ValueError:
            return False

class ApacheLogParser(BaseLogParser):
    """Parser for Apache access logs"""
    
    def __init__(self):
        self.name = "apache"
        # Common Apache log format patterns
        self.patterns = [
            # Combined Log Format - handles URLs with query parameters
            re.compile(r'^(\S+) \S+ \S+ \[([^\]]+)\] "(\S+) ([^"]*) \S+" (\d+) (\d+) "([^"]*)" "([^"]*)"'),
            # Common Log Format - handles URLs with query parameters
            re.compile(r'^(\S+) \S+ \S+ \[([^\]]+)\] "(\S+) ([^"]*) \S+" (\d+) (\d+)'),
            # Custom formats - handles URLs with query parameters
            re.compile(r'^(\S+) \[([^\]]+)\] "(\S+) ([^"]*) \S+" (\d+) (\d+) "([^"]*)" "([^"]*)"'),
        ]
    
    def can_parse(self, log_line: str) -> bool:
        """Check if line matches Apache format"""
        for pattern in self.patterns:
            if pattern.match(log_line.strip()):
                return True
        return False
    
    def parse_line(self, log_line: str) -> Optional[ParsedLogEntry]:
        """Parse Apache log line"""
        log_line = log_line.strip()
        
        for pattern in self.patterns:
            match = pattern.match(log_line)
            if match:
                try:
                    groups = match.groups()
                    
                    # Extract IP address
                    ip_address = groups[0]
                    if not self.validate_ip(ip_address):
                        return None
                    
                    # Parse timestamp
                    timestamp_str = groups[1]
                    timestamp = self._parse_apache_timestamp(timestamp_str)
                    
                    # Extract method and path
                    method = groups[2]
                    path = groups[3]
                    
                    # Extract status code and response size
                    status_code = int(groups[4])
                    response_size = int(groups[5])
                    
                    # Extract referer and user agent (if available)
                    referer = groups[6] if len(groups) > 6 else ""
                    user_agent = groups[7] if len(groups) > 7 else ""
                    
                    return ParsedLogEntry(
                        timestamp=timestamp,
                        ip_address=ip_address,
                        method=method,
                        path=path,
                        status_code=status_code,
                        response_size=response_size,
                        user_agent=user_agent,
                        referer=referer,
                        raw_log=log_line
                    )
                    
                except (ValueError, IndexError) as e:
                    print(f"Error parsing Apache log line: {e}")
                    return None
        
        return None
    
    def _parse_apache_timestamp(self, timestamp_str: str) -> datetime.datetime:
        """Parse Apache timestamp format"""
        # Common Apache timestamp formats
        formats = [
            '%d/%b/%Y:%H:%M:%S %z',
            '%d/%b/%Y:%H:%M:%S',
            '%Y-%m-%d %H:%M:%S',
        ]
        
        for fmt in formats:
            try:
                return datetime.datetime.strptime(timestamp_str, fmt)
            except ValueError:
                continue
        
        # If no format matches, return current time
        return datetime.datetime.now()


class NginxLogParser(BaseLogParser):
    """Parser for Nginx access logs"""
    
    def __init__(self):
        self.name = "nginx"
        # Nginx log format patterns
        self.patterns = [
            # Combined format
            re.compile(r'^(\S+) - (\S+) \[([^\]]+)\] "(\S+) (\S+) \S+" (\d+) (\d+) "([^"]*)" "([^"]*)"'),
            # Simple format
            re.compile(r'^(\S+) - (\S+) \[([^\]]+)\] "(\S+) (\S+) \S+" (\d+) (\d+)'),
        ]
    
    def can_parse(self, log_line: str) -> bool:
        """Check if line matches Nginx format"""
        for pattern in self.patterns:
            if pattern.match(log_line.strip()):
                return True
        return False
    
    def parse_line(self, log_line: str) -> Optional[ParsedLogEntry]:
        """Parse Nginx log line"""
        log_line = log_line.strip()
        
        for pattern in self.patterns:
            match = pattern.match(log_line)
            if match:
                try:
                    groups = match.groups()
                    
                    # Extract IP address
                    ip_address = groups[0]
                    if not self.validate_ip(ip_address):
                        return None
                    
                    # Parse timestamp
                    timestamp_str = groups[2]
                    timestamp = self._parse_nginx_timestamp(timestamp_str)
                    
                    # Extract method and path
                    method = groups[3]
                    path = groups[4]
                    
                    # Extract status code and response size
                    status_code = int(groups[5])
                    response_size = int(groups[6])
                    
                    # Extract referer and user agent (if available)
                    referer = groups[7] if len(groups) > 7 else ""
                    user_agent = groups[8] if len(groups) > 8 else ""
                    
                    return ParsedLogEntry(
                        timestamp=timestamp,
                        ip_address=ip_address,
                        method=method,
                        path=path,
                        status_code=status_code,
                        response_size=response_size,
                        user_agent=user_agent,
                        referer=referer,
                        raw_log=log_line
                    )
                    
                except (ValueError, IndexError) as e:
                    print(f"Error parsing Nginx log line: {e}")
                    return None
        
        return None
    
    def _parse_nginx_timestamp(self, timestamp_str: str) -> datetime.datetime:
        """Parse Nginx timestamp format"""
        # Nginx timestamp format
        format_str = '%d/%b/%Y:%H:%M:%S %z'
        try:
            return datetime.datetime.strptime(timestamp_str, format_str)
        except ValueError:
            return datetime.datetime.now()


class DjangoLogParser(BaseLogParser):
    """Parser for Django logs"""
    
    def __init__(self):
        self.name = "django"
        # Django log patterns
        self.patterns = [
            # Django development server format
            re.compile(r'^\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\] (\S+) "(\S+) (\S+) \S+" (\d+) (\d+)'),
            # Custom Django format
            re.compile(r'^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) (\S+) (\S+) (\S+) (\d+) (\d+)'),
        ]
    
    def can_parse(self, log_line: str) -> bool:
        """Check if line matches Django format"""
        for pattern in self.patterns:
            if pattern.match(log_line.strip()):
                return True
        return False
    
    def parse_line(self, log_line: str) -> Optional[ParsedLogEntry]:
        """Parse Django log line"""
        log_line = log_line.strip()
        
        for pattern in self.patterns:
            match = pattern.match(log_line)
            if match:
                try:
                    groups = match.groups()
                    
                    # Parse timestamp
                    timestamp_str = groups[0]
                    timestamp = self._parse_django_timestamp(timestamp_str)
                    
                    # Extract IP address
                    ip_address = groups[1]
                    if not self.validate_ip(ip_address):
                        return None
                    
                    # Extract method and path
                    method = groups[2]
                    path = groups[3]
                    
                    # Extract status code and response size
                    status_code = int(groups[4])
                    response_size = int(groups[5])
                    
                    return ParsedLogEntry(
                        timestamp=timestamp,
                        ip_address=ip_address,
                        method=method,
                        path=path,
                        status_code=status_code,
                        response_size=response_size,
                        user_agent="",
                        referer="",
                        raw_log=log_line
                    )
                    
                except (ValueError, IndexError) as e:
                    print(f"Error parsing Django log line: {e}")
                    return None
        
        return None
    
    def _parse_django_timestamp(self, timestamp_str: str) -> datetime.datetime:
        """Parse Django timestamp format"""
        format_str = '%Y-%m-%d %H:%M:%S'
        try:
            return datetime.datetime.strptime(timestamp_str, format_str)
        except ValueError:
            return datetime.datetime.now()


class ApacheErrorLogParser(BaseLogParser):
    """Parser for Apache error logs"""
    
    def __init__(self):
        self.name = "apache_error"
        # Apache error log patterns
        self.patterns = [
            # Standard Apache error log format: [timestamp] [level] message
            re.compile(r'^\[([^\]]+)\] \[([^\]]+)\] (.+)'),
        ]
    
    def can_parse(self, log_line: str) -> bool:
        """Check if line matches Apache error format"""
        for pattern in self.patterns:
            if pattern.match(log_line.strip()):
                return True
        return False
    
    def parse_line(self, log_line: str) -> Optional[ParsedLogEntry]:
        """Parse Apache error log line"""
        log_line = log_line.strip()
        
        for pattern in self.patterns:
            match = pattern.match(log_line)
            if match:
                try:
                    timestamp_str, level, message = match.groups()
                    
                    # Parse timestamp
                    timestamp = self._parse_apache_error_timestamp(timestamp_str)
                    
                    # Apache error logs don't have IP, method, path in standard format
                    # So we'll use dummy values and put the real info in message
                    return ParsedLogEntry(
                        timestamp=timestamp,
                        ip_address="0.0.0.0",  # No IP in error logs
                        method="ERROR",
                        path=f"/{level}",
                        status_code=500 if level == "error" else 200,
                        response_size=0,
                        user_agent=level,
                        referer=message,
                        raw_log=log_line
                    )
                    
                except (ValueError, IndexError) as e:
                    print(f"Error parsing Apache error log line: {e}")
                    return None
        
        return None
    
    def _parse_apache_error_timestamp(self, timestamp_str: str) -> datetime.datetime:
        """Parse Apache error timestamp format"""
        # Apache error log timestamp format: "Thu Jun 09 06:07:04 2005"
        formats = [
            '%a %b %d %H:%M:%S %Y',
            '%Y-%m-%d %H:%M:%S',
            '%d/%b/%Y:%H:%M:%S',
        ]
        
        for fmt in formats:
            try:
                return datetime.datetime.strptime(timestamp_str, fmt)
            except ValueError:
                continue
        
        return datetime.datetime.now()


class LinuxSyslogParser(BaseLogParser):
    """Parser for Linux syslog files"""
    
    def __init__(self):
        self.name = "linux_syslog"
        # Linux syslog patterns
        self.patterns = [
            # Standard syslog format: "Jun 14 15:16:01 combo sshd(pam_unix)[19939]: message"
            re.compile(r'^(\w+\s+\d+\s+\d+:\d+:\d+)\s+(\S+)\s+([^:]+):\s*(.+)'),
        ]
    
    def can_parse(self, log_line: str) -> bool:
        """Check if line matches Linux syslog format"""
        for pattern in self.patterns:
            if pattern.match(log_line.strip()):
                return True
        return False
    
    def parse_line(self, log_line: str) -> Optional[ParsedLogEntry]:
        """Parse Linux syslog line"""
        log_line = log_line.strip()
        
        for pattern in self.patterns:
            match = pattern.match(log_line)
            if match:
                try:
                    timestamp_str, hostname, process, message = match.groups()
                    
                    # Parse timestamp
                    timestamp = self._parse_syslog_timestamp(timestamp_str)
                    
                    # Extract IP address from message if available (common in SSH logs)
                    ip_address = self._extract_ip_from_message(message)
                    
                    # Extract user from message if available
                    user = self._extract_user_from_message(message)
                    
                    return ParsedLogEntry(
                        timestamp=timestamp,
                        ip_address=ip_address,
                        method="SYSLOG",
                        path=f"/{process}",
                        status_code=401 if "authentication failure" in message else 200,
                        response_size=0,
                        user_agent=hostname,
                        referer=user,
                        raw_log=log_line
                    )
                    
                except (ValueError, IndexError) as e:
                    print(f"Error parsing Linux syslog line: {e}")
                    return None
        
        return None
    
    def _parse_syslog_timestamp(self, timestamp_str: str) -> datetime.datetime:
        """Parse syslog timestamp format"""
        # Syslog doesn't include year, so we add current year
        current_year = datetime.datetime.now().year
        try:
            return datetime.datetime.strptime(f"{current_year} {timestamp_str}", '%Y %b %d %H:%M:%S')
        except ValueError:
            return datetime.datetime.now()
    
    def _extract_ip_from_message(self, message: str) -> str:
        """Extract IP address from syslog message. Only return valid IPv4/IPv6 to satisfy DB field."""
        # Look for rhost= pattern (common in SSH logs) which may be hostname or IP
        ip_or_host_pattern = r'rhost=([0-9\.a-zA-Z\-]+)'
        match = re.search(ip_or_host_pattern, message)
        if match:
            candidate = match.group(1)
            if self.validate_ip(candidate):
                return candidate
            # If it's a hostname, do not return it because ip_address field requires a valid IP
            return "0.0.0.0"

        # Look for any IPv4-like pattern in the message
        ipv4_pattern = r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
        match = re.search(ipv4_pattern, message)
        if match and self.validate_ip(match.group(1)):
            return match.group(1)

        return "0.0.0.0"  # Default if no IP found
    
    def _extract_user_from_message(self, message: str) -> str:
        """Extract username from syslog message"""
        user_pattern = r'user=(\S+)'
        match = re.search(user_pattern, message)
        return match.group(1) if match else ""


class SpecializedLogParser(BaseLogParser):
    """
    Specialized parser that can handle multiple log types:
    1. Apache Access Logs (access-10k.log)
    2. SQL Injection Attack Logs (sql_injection_attack.log)
    3. Linux System Logs (linux-2k.log)
    """
    
    def __init__(self):
        self.name = "specialized"
        
        # Apache access log pattern (handles both normal and SQL injection logs)
        self.apache_pattern = re.compile(
            r'^(\S+) \S+ \S+ \[([^\]]+)\] "(\S+) ([^"]*) \S+" (\d+) (\d+) "([^"]*)" "([^"]*)"'
        )

        # Linux syslog pattern
        self.syslog_pattern = re.compile(
            r'^(\w+\s+\d+\s+\d+:\d+:\d+)\s+(\S+)\s+([^:]+):\s*(.+)'
        )

        # SQL injection detection patterns
        self.sql_injection_patterns = [
            r"'.*OR.*'1'='1",
            r"'.*UNION.*SELECT",
            r"'.*AND.*1=1",
            r"'.*OR.*1=1",
            r"'.*UNION.*SELECT.*FROM",
            r"'.*DROP.*TABLE",
            r"'.*INSERT.*INTO",
            r"'.*UPDATE.*SET",
            r"'.*DELETE.*FROM",
            r"'.*EXEC.*",
            r"'.*EXECUTE.*",
            r"'.*xp_cmdshell",
            r"'.*sp_",
            r"'.*@@version",
            r"'.*@@hostname",
            r"'.*@@datadir",
            r"'.*information_schema",
            r"'.*sys\.tables",
            r"'.*sys\.columns",
            r"'.*database\(",
            r"'.*user\(",
        ]
        
        # Compile SQL injection patterns for efficiency
        self.sql_patterns = [re.compile(pattern, re.IGNORECASE) for pattern in self.sql_injection_patterns]
    
    def can_parse(self, log_line: str) -> bool:
        """Check if this parser can handle the log line"""
        log_line = log_line.strip()
        
        # Check if it's an Apache access log
        if self.apache_pattern.match(log_line):
            return True

        # Check if it's a Linux syslog
        if self.syslog_pattern.match(log_line):
            return True

        return False
    
    def parse_line(self, log_line: str) -> Optional[ParsedLogEntry]:
        """Parse a single log line"""
        log_line = log_line.strip()
        
        # Try Apache access log format first
        apache_match = self.apache_pattern.match(log_line)
        if apache_match:
            return self._parse_apache_line(log_line, apache_match)

        # Try Linux syslog format
        syslog_match = self.syslog_pattern.match(log_line)
        if syslog_match:
            return self._parse_syslog_line(log_line, syslog_match)

        return None
    
    def _parse_apache_line(self, log_line: str, match) -> Optional[ParsedLogEntry]:
        """Parse Apache access log line"""
        try:
            groups = match.groups()
            
            # Extract basic fields
            ip_address = groups[0]
            timestamp_str = groups[1]
            method = groups[2]
            path = groups[3]
            status_code = int(groups[4])
            response_size = int(groups[5])
            referer = groups[6]
            user_agent = groups[7]
            
            # Validate IP address
            if not self.validate_ip(ip_address):
                return None
            
            # Parse timestamp
            timestamp = self._parse_apache_timestamp(timestamp_str)
            
            # Check for SQL injection patterns
            is_sql_injection = self._detect_sql_injection(path)
            
            # Adjust status code for SQL injection attempts
            if is_sql_injection and status_code == 200:
                # SQL injection attempts that return 200 might be successful
                adjusted_status = 200
            elif is_sql_injection and status_code == 500:
                # SQL injection attempts that return 500 are likely blocked
                adjusted_status = 500
            else:
                adjusted_status = status_code
            
            return ParsedLogEntry(
                timestamp=timestamp,
                ip_address=ip_address,
                method=method,
                path=path,
                status_code=adjusted_status,
                response_size=response_size,
                user_agent=user_agent,
                referer=referer,
                raw_log=log_line
            )
            
        except (ValueError, IndexError) as e:
            print(f"Error parsing Apache log line: {e}")
            return None
    

    
    def _parse_apache_timestamp(self, timestamp_str: str) -> datetime.datetime:
        """Parse Apache timestamp format"""
        formats = [
            '%d/%b/%Y:%H:%M:%S %z',
            '%d/%b/%Y:%H:%M:%S',
            '%Y-%m-%d %H:%M:%S',
        ]
        
        for fmt in formats:
            try:
                return datetime.datetime.strptime(timestamp_str, fmt)
            except ValueError:
                continue
        
        return datetime.datetime.now()

    def _parse_syslog_line(self, log_line: str, match) -> Optional[ParsedLogEntry]:
        """Parse Linux syslog line"""
        try:
            timestamp_str, hostname, process, message = match.groups()
            
            # Parse timestamp
            timestamp = self._parse_syslog_timestamp(timestamp_str)
            
            # Extract IP address from message if available
            ip_address = self._extract_ip_from_syslog(message)
            
            # Extract user from message if available
            user = self._extract_user_from_syslog(message)
            
            # Determine status code based on message content
            if "authentication failure" in message.lower():
                status_code = 401
            elif "session opened" in message.lower():
                status_code = 200
            elif "session closed" in message.lower():
                status_code = 200
            elif "connection from" in message.lower():
                status_code = 200
            else:
                status_code = 200
            
            return ParsedLogEntry(
                timestamp=timestamp,
                ip_address=ip_address,
                method="SYSLOG",
                path=f"/{process}",
                status_code=status_code,
                response_size=0,
                user_agent=hostname,
                referer=user,
                raw_log=log_line
            )
            
        except (ValueError, IndexError) as e:
            print(f"Error parsing syslog line: {e}")
            return None

    def _parse_syslog_timestamp(self, timestamp_str: str) -> datetime.datetime:
        """Parse syslog timestamp format"""
        current_year = datetime.datetime.now().year
        try:
            return datetime.datetime.strptime(f"{current_year} {timestamp_str}", '%Y %b %d %H:%M:%S')
        except ValueError:
            return datetime.datetime.now()

    def _extract_ip_from_syslog(self, message: str) -> str:
        """Extract IP address from syslog message"""
        # Look for rhost= pattern (common in SSH logs)
        ip_or_host_pattern = r'rhost=([0-9\.a-zA-Z\-]+)'
        match = re.search(ip_or_host_pattern, message)
        if match:
            candidate = match.group(1)
            if self.validate_ip(candidate):
                return candidate
        
        # Look for IPv4 pattern in the message
        ipv4_pattern = r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
        match = re.search(ipv4_pattern, message)
        if match and self.validate_ip(match.group(1)):
            return match.group(1)
        
        return "0.0.0.0"

    def _extract_user_from_syslog(self, message: str) -> str:
        """Extract username from syslog message"""
        user_pattern = r'user=(\S+)'
        match = re.search(user_pattern, message)
        return match.group(1) if match else ""

    def _detect_sql_injection(self, path: str) -> bool:
        """Detect SQL injection patterns in the path"""
        for pattern in self.sql_patterns:
            if pattern.search(path):
                return True
        return False
    
    def parse_log_content(self, log_content: str) -> List[ParsedLogEntry]:
        """Parse entire log content"""
        parsed_entries = []
        lines = log_content.split('\n')
        
        for line in lines:
            if line.strip():
                entry = self.parse_line(line)
                if entry:
                    parsed_entries.append(entry)
        
        return parsed_entries
    
    def get_log_type(self, log_content: str) -> str:
        """Determine the specific log type from content"""
        lines = log_content.split('\n')[:10]
        
        apache_count = 0
        sql_injection_count = 0
        syslog_count = 0
        
        for line in lines:
            if line.strip():
                if self.apache_pattern.match(line):
                    apache_count += 1
                    # Check if it contains SQL injection patterns
                    if self._detect_sql_injection(line):
                        sql_injection_count += 1
                elif self.syslog_pattern.match(line):
                    syslog_count += 1
        
        total_lines = len([line for line in lines if line.strip()])
        
        if total_lines == 0:
            return "unknown"
        
        # Determine the log type
        if sql_injection_count > 0 and sql_injection_count / total_lines > 0.3:
            return "sql_injection_attack"
        elif apache_count / total_lines > 0.5:
            return "apache_access"
        elif syslog_count / total_lines > 0.5:
            return "linux_syslog"
        else:
            return "unknown"


class LogParserFactory:
    """Factory class for log parsers"""
    
    def __init__(self):
        self.parsers = {
            'apache': ApacheLogParser(),
            'nginx': NginxLogParser(),
            'django': DjangoLogParser(),
            'apache_access': SpecializedLogParser(),
            'sql_injection_attack': SpecializedLogParser(),
            'linux_syslog': SpecializedLogParser(),
            'specialized': SpecializedLogParser(),
        }
    
    def detect_log_type(self, log_content: str) -> str:
        """Auto-detect log format from content"""
        # Sample first few lines for detection
        lines = log_content.split('\n')[:10]
        
        # Count matches for each parser
        parser_scores = {}
        
        for parser_name, parser in self.parsers.items():
            matches = 0
            for line in lines:
                if line.strip() and parser.can_parse(line):
                    matches += 1
            
            if matches > 0:
                parser_scores[parser_name] = matches / len(lines)
        
        # Return the parser with highest score
        if parser_scores:
            best_parser = max(parser_scores.items(), key=lambda x: x[1])
            if best_parser[1] > 0.5:  # At least 50% match
                return best_parser[0]
        
        return 'unknown'
    
    def get_parser(self, log_type: str) -> Optional[BaseLogParser]:
        """Get parser by type"""
        return self.parsers.get(log_type)
    
    def parse_log_content(self, log_content: str, log_type: str = None) -> List[ParsedLogEntry]:
        """Parse entire log content"""
        if not log_type:
            log_type = self.detect_log_type(log_content)
        
        parser = self.get_parser(log_type)
        if not parser:
            return []
        
        parsed_entries = []
        lines = log_content.split('\n')
        
        for line in lines:
            if line.strip():
                entry = parser.parse_line(line)
                if entry:
                    parsed_entries.append(entry)
        
        return parsed_entries
