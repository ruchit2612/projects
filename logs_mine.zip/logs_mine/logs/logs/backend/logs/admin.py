from django.contrib import admin
from .models import LogFile, LogEntry, AnalysisResult, SuspiciousActivity, Report


@admin.register(LogFile)
class LogFileAdmin(admin.ModelAdmin):
    list_display = [
        'id', 'filename', 'user', 'log_type', 'status', 'file_size_mb', 
        'total_lines', 'processed_lines', 'suspicious_activities_count', 
        'risk_score', 'uploaded_at'
    ]
    list_filter = ['log_type', 'status', 'uploaded_at', 'processed_at']
    search_fields = ['filename', 'user__username']
    readonly_fields = [
        'id', 'uploaded_at', 'processed_at', 'file_size_mb', 
        'total_lines', 'processed_lines', 'error_lines',
        'suspicious_activities_count', 'risk_score', 'file_content'
    ]
    ordering = ['-uploaded_at']
    
    def file_size_mb(self, obj):
        return obj.get_file_size_mb()
    file_size_mb.short_description = 'File Size (MB)'
    
    def has_add_permission(self, request):
        return False  # Files should only be uploaded via the API


@admin.register(LogEntry)
class LogEntryAdmin(admin.ModelAdmin):
    list_display = [
        'id', 'log_file', 'timestamp', 'ip_address', 'method', 
        'path', 'status_code', 'is_suspicious', 'risk_score'
    ]
    list_filter = [
        'method', 'status_code', 'is_suspicious', 'timestamp',
        'log_file__log_type'
    ]
    search_fields = ['ip_address', 'path', 'user_agent', 'raw_log']
    readonly_fields = [
        'id', 'timestamp', 'ip_address', 'method', 'path', 
        'status_code', 'response_size', 'user_agent', 'referer',
        'country', 'city', 'latitude', 'longitude', 'is_suspicious',
        'risk_score', 'suspicious_patterns', 'raw_log'
    ]
    ordering = ['-timestamp']
    
    def has_add_permission(self, request):
        return False  # Entries should only be created via file processing


@admin.register(AnalysisResult)
class AnalysisResultAdmin(admin.ModelAdmin):
    list_display = [
        'id', 'log_file', 'analysis_type', 'confidence_score', 
        'model_used', 'created_at', 'processing_time'
    ]
    list_filter = ['analysis_type', 'model_used', 'created_at']
    search_fields = ['log_file__filename', 'model_used']
    readonly_fields = [
        'id', 'log_file', 'analysis_type', 'results', 'confidence_score',
        'model_used', 'created_at', 'processing_time'
    ]
    ordering = ['-created_at']
    
    def has_add_permission(self, request):
        return False  # Results should only be created via analysis


@admin.register(SuspiciousActivity)
class SuspiciousActivityAdmin(admin.ModelAdmin):
    list_display = [
        'id', 'log_file', 'activity_type', 'severity', 'confidence_score',
        'is_resolved', 'first_detected', 'last_updated'
    ]
    list_filter = [
        'activity_type', 'severity', 'is_resolved', 'first_detected',
        'log_file__log_type'
    ]
    search_fields = [
        'description', 'detection_method', 'affected_ips', 
        'affected_paths', 'log_file__filename'
    ]
    readonly_fields = [
        'id', 'log_file', 'activity_type', 'severity', 'description',
        'confidence_score', 'detection_method', 'patterns_found',
        'affected_ips', 'affected_paths', 'first_detected', 'last_updated',
        'log_entries'
    ]
    ordering = ['-first_detected']
    
    def has_add_permission(self, request):
        return False  # Activities should only be created via analysis


@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    list_display = [
        'id', 'name', 'user', 'report_type', 'status', 'log_file',
        'file_size_mb', 'processing_time_formatted', 'created_at', 'completed_at'
    ]
    list_filter = ['report_type', 'status', 'include_charts', 'include_recommendations', 'created_at']
    search_fields = ['name', 'user__username', 'log_file__filename']
    readonly_fields = [
        'id', 'created_at', 'completed_at', 'processing_time', 'file_size_mb',
        'total_entries', 'suspicious_activities_count', 'risk_score_avg'
    ]
    ordering = ['-created_at']
    
    def file_size_mb(self, obj):
        return obj.get_file_size_mb()
    file_size_mb.short_description = 'File Size (MB)'
    
    def processing_time_formatted(self, obj):
        return obj.get_processing_time_formatted()
    processing_time_formatted.short_description = 'Processing Time'
    
    def has_add_permission(self, request):
        return False  # Reports should only be created via the API

# Customize admin site
admin.site.site_header = "Log Analyzer Admin"
admin.site.site_title = "Log Analyzer Admin Portal"
admin.site.index_title = "Welcome to Log Analyzer Administration"
