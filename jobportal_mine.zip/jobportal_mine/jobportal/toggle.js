  const header__icon=document.getElementById("header__icon")
  const header__links=document.getElementById("header__links")

  if(header__icon){
    header__icon.addEventListener("click",()=>{
        header__links.classList.toggle("active")
    })
  }
  const sortItems = document.querySelectorAll(".jobs__container > *")
  const sortbtns = document.querySelectorAll(".jobs__id > *")


  sortbtns.forEach((btn) => {
    btn.addEventListener("click",() =>{
      sortbtns.forEach((btn) => btn.classList.remove("active"));
      btn.classList.add("active")

      const target_data = btn.getAttribute("data-target")

      sortItems.forEach((item) => {  
        item.classList.add("delete")
        if(item.getAttribute("data-item")===
        target_data || target_data==="all"){
        item.classList.remove("delete")
        }     
      });
    }); 
  });

  function validateForm() {
    const email = document.getElementById('email').value;
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;

    if (!emailRegex.test(email)) {
        alert("Please enter a valid email address.");
        return false;
    }
    return true;
}
